# Edvora photo and logo asset checklist

Use images Edvora owns or has written permission to publish. Do not send passport or visa scans for this checklist. University photos should be official campus images approved for reuse; logos should come from the institution's official press/media kit. Files should be JPEG photos (campus/city) or transparent PNG logos, with filenames below. The 96 logo files already present were found through institution-domain favicons and are provisional; verify they match the current official mark and are suitable to publish, or replace them.

## Destination cards / hero carousel

| Country | Required file | Status |
|---|---|---|
| United Kingdom | `public/images/countries/uk.jpg` | Needed |
| Sweden | `public/images/countries/sweden.jpg` | Needed |
| Turkey | `public/images/countries/turkey.jpg` | Needed |
| South Cyprus | `public/images/countries/south-cyprus.jpg` | Needed |
| Romania | `public/images/countries/romania.jpg` | Needed |
| Germany | `public/images/countries/germany.jpg` | Needed |
| Italy | `public/images/countries/italy.jpg` | Needed |

## Destination city showcase

| Country | City | Required file | Status |
|---|---|---|
| uk | london | `public/images/countries/cities/uk-london.jpg` | Needed |
| uk | edinburgh | `public/images/countries/cities/uk-edinburgh.jpg` | Needed |
| uk | birmingham | `public/images/countries/cities/uk-birmingham.jpg` | Needed |
| uk | manchester | `public/images/countries/cities/uk-manchester.jpg` | Needed |
| south-cyprus | nicosia | `public/images/countries/cities/south-cyprus-nicosia.jpg` | Needed |
| south-cyprus | limassol | `public/images/countries/cities/south-cyprus-limassol.jpg` | Needed |
| south-cyprus | paphos | `public/images/countries/cities/south-cyprus-paphos.jpg` | Needed |
| sweden | stockholm | `public/images/countries/cities/sweden-stockholm.jpg` | Needed |
| sweden | gothenburg | `public/images/countries/cities/sweden-gothenburg.jpg` | Needed |
| sweden | lund | `public/images/countries/cities/sweden-lund.jpg` | Needed |
| turkey | istanbul | `public/images/countries/cities/turkey-istanbul.jpg` | Needed |
| turkey | ankara | `public/images/countries/cities/turkey-ankara.jpg` | Needed |
| turkey | izmir | `public/images/countries/cities/turkey-izmir.jpg` | Needed |
| romania | bucharest | `public/images/countries/cities/romania-bucharest.jpg` | Needed |
| romania | cluj-napoca | `public/images/countries/cities/romania-cluj-napoca.jpg` | Needed |
| romania | timisoara | `public/images/countries/cities/romania-timisoara.jpg` | Needed |
| germany | berlin | `public/images/countries/cities/germany-berlin.jpg` | Needed |
| germany | munich | `public/images/countries/cities/germany-munich.jpg` | Needed |
| germany | hamburg | `public/images/countries/cities/germany-hamburg.jpg` | Needed |
| italy | rome | `public/images/countries/cities/italy-rome.jpg` | Needed |
| italy | milan | `public/images/countries/cities/italy-milan.jpg` | Needed |
| italy | florence | `public/images/countries/cities/italy-florence.jpg` | Needed |

## University directory (281 entries)

All campus image paths are listed individually. Logos are local files collected from official university domains where available; missing entries should be supplied from official brand resources.

| University | Country | Campus photo | Photo status | Logo file | Logo status |
|---|---|---|---|---|---|
| University of Cambridge | United Kingdom | `public/images/universities/cambridge.jpg` | Needed | `public/images/university-logos/cambridge.png` | Present |
| University of Oxford | United Kingdom | `public/images/universities/oxford.jpg` | Needed | `public/images/university-logos/oxford.png` | Present |
| Imperial College London | United Kingdom | `public/images/universities/imperial-college-london.jpg` | Needed | `public/images/university-logos/imperial-college-london.png` | Present |
| Lund University | Sweden | `public/images/universities/lund.jpg` | Needed | `public/images/university-logos/lund.png` | Present |
| Uppsala University | Sweden | `public/images/universities/uppsala.jpg` | Needed | `public/images/university-logos/uppsala.png` | Present |
| KTH Royal Institute of Technology | Sweden | `public/images/universities/kth.jpg` | Needed | `public/images/university-logos/kth.png` | Present |
| Linköping University | Sweden | `public/images/universities/linkoping.jpg` | Needed | `public/images/university-logos/linkoping.png` | Present |
| Umeå University | Sweden | `public/images/universities/umea.jpg` | Needed | `public/images/university-logos/umea.png` | Present |
| University of Nicosia | Cyprus | `public/images/universities/university-of-nicosia.jpg` | Needed | `public/images/university-logos/university-of-nicosia.png` | Present |
| Cyprus School of Molecular Medicine | Cyprus | `public/images/universities/cyprus-school-molecular-medicine.jpg` | Needed | `public/images/university-logos/cyprus-school-molecular-medicine.png` | Present |
| European University Cyprus | Cyprus | `public/images/universities/european-university-cyprus.jpg` | Needed | `public/images/university-logos/european-university-cyprus.png` | Present |
| Koç University | Turkey | `public/images/universities/koc-university.jpg` | Needed | `public/images/university-logos/koc-university.png` | Present |
| Middle East Technical University | Turkey | `public/images/universities/middle-east-technical-university.jpg` | Needed | `public/images/university-logos/middle-east-technical-university.png` | Present |
| Sabancı University | Turkey | `public/images/universities/sabanci-university.jpg` | Needed | `public/images/university-logos/sabanci-university.png` | Present |
| Boğaziçi University | Turkey | `public/images/universities/bogazici-university.jpg` | Needed | `public/images/university-logos/bogazici-university.png` | Present |
| Istanbul Technical University | Turkey | `public/images/universities/istanbul-technical-university.jpg` | Needed | `public/images/university-logos/istanbul-technical-university.png` | Present |
| Bilkent University | Turkey | `public/images/universities/bilkent-university.jpg` | Needed | `public/images/university-logos/bilkent-university.png` | Present |
| Kadir Has University | Turkey | `public/images/universities/kadir-has-university.jpg` | Needed | `public/images/university-logos/kadir-has-university.png` | Present |
| Yıldız Technical University | Turkey | `public/images/universities/yildiz-technical-university.jpg` | Needed | `public/images/university-logos/yildiz-technical-university.png` | Present |
| Abdullah Gül University | Turkey | `public/images/universities/abdullah-gul-university.jpg` | Needed | `public/images/university-logos/abdullah-gul-university.png` | Present |
| Atatürk University | Turkey | `public/images/universities/ataturk-university.jpg` | Needed | `public/images/university-logos/ataturk-university.png` | Present |
| Bahçeşehir University | Turkey | `public/images/universities/bahcesehir-university.jpg` | Needed | `public/images/university-logos/bahcesehir-university.png` | Present |
| Çankaya University | Turkey | `public/images/universities/cankaya-university.jpg` | Needed | `public/images/university-logos/cankaya-university.png` | Present |
| Hacettepe University | Turkey | `public/images/universities/hacettepe-university.jpg` | Needed | `public/images/university-logos/hacettepe-university.png` | Present |
| Istanbul Medipol University | Turkey | `public/images/universities/istanbul-medipol-university.jpg` | Needed | `public/images/university-logos/istanbul-medipol-university.png` | Present |
| Özyeğin University | Turkey | `public/images/universities/ozyegin-university.jpg` | Needed | `public/images/university-logos/ozyegin-university.png` | Needed |
| Berlin School of Business and Innovation | Germany | `public/images/universities/berlin.jpg` | Needed | `public/images/university-logos/berlin.png` | Present |
| University of Bologna | Italy | `public/images/universities/bologna.jpg` | Needed | `public/images/university-logos/bologna.png` | Needed |
| Anadolu University | Turkey | `public/images/universities/anadolu-university.jpg` | Needed | `public/images/university-logos/anadolu-university.png` | Present |
| Bartın University | Turkey | `public/images/universities/bart-n-university.jpg` | Needed | `public/images/university-logos/bart-n-university.png` | Needed |
| Fırat University | Turkey | `public/images/universities/f-rat-university.jpg` | Needed | `public/images/university-logos/f-rat-university.png` | Needed |
| Istanbul Gelişim University | Turkey | `public/images/universities/istanbul-gelisim-university.jpg` | Needed | `public/images/university-logos/istanbul-gelisim-university.png` | Needed |
| Izmir Institute of Technology | Turkey | `public/images/universities/izmir-institute-of-technology.jpg` | Needed | `public/images/university-logos/izmir-institute-of-technology.png` | Needed |
| Selçuk University | Turkey | `public/images/universities/selcuk-university.jpg` | Needed | `public/images/university-logos/selcuk-university.png` | Needed |
| İstinye University | Turkey | `public/images/universities/istinye-university.jpg` | Needed | `public/images/university-logos/istinye-university.png` | Needed |
| Akdeniz University | Turkey | `public/images/universities/akdeniz-university.jpg` | Needed | `public/images/university-logos/akdeniz-university.png` | Needed |
| Ankara University | Turkey | `public/images/universities/ankara-university.jpg` | Needed | `public/images/university-logos/ankara-university.png` | Needed |
| Biruni University | Turkey | `public/images/universities/biruni-university.jpg` | Needed | `public/images/university-logos/biruni-university.png` | Needed |
| Düzce University | Turkey | `public/images/universities/duzce-university.jpg` | Needed | `public/images/university-logos/duzce-university.png` | Needed |
| Ege University | Turkey | `public/images/universities/ege-university.jpg` | Needed | `public/images/university-logos/ege-university.png` | Present |
| Erciyes University | Turkey | `public/images/universities/erciyes-university.jpg` | Needed | `public/images/university-logos/erciyes-university.png` | Needed |
| Gazi University | Turkey | `public/images/universities/gazi-university.jpg` | Needed | `public/images/university-logos/gazi-university.png` | Needed |
| Gebze Technical University | Turkey | `public/images/universities/gebze-technical-university.jpg` | Needed | `public/images/university-logos/gebze-technical-university.png` | Needed |
| İnönü University | Turkey | `public/images/universities/inonu-university.jpg` | Needed | `public/images/university-logos/inonu-university.png` | Needed |
| Istanbul Medeniyet University | Turkey | `public/images/universities/istanbul-medeniyet-university.jpg` | Needed | `public/images/university-logos/istanbul-medeniyet-university.png` | Needed |
| Istanbul University | Turkey | `public/images/universities/istanbul-university.jpg` | Needed | `public/images/university-logos/istanbul-university.png` | Present |
| Istanbul University-Cerrahpaşa | Turkey | `public/images/universities/istanbul-university-cerrahpasa.jpg` | Needed | `public/images/university-logos/istanbul-university-cerrahpasa.png` | Present |
| Necmettin Erbakan University | Turkey | `public/images/universities/necmettin-erbakan-university.jpg` | Needed | `public/images/university-logos/necmettin-erbakan-university.png` | Needed |
| Sakarya University | Turkey | `public/images/universities/sakarya-university.jpg` | Needed | `public/images/university-logos/sakarya-university.png` | Needed |
| Süleyman Demirel University | Turkey | `public/images/universities/suleyman-demirel-university.jpg` | Needed | `public/images/university-logos/suleyman-demirel-university.png` | Needed |
| TOBB University of Economics and Technology | Turkey | `public/images/universities/tobb-university-of-economics-and-technology.jpg` | Needed | `public/images/university-logos/tobb-university-of-economics-and-technology.png` | Needed |
| University of Health Sciences, Türkiye | Turkey | `public/images/universities/university-of-health-sciences-turkiye.jpg` | Needed | `public/images/university-logos/university-of-health-sciences-turkiye.png` | Needed |
| Yaşar University | Turkey | `public/images/universities/yasar-university.jpg` | Needed | `public/images/university-logos/yasar-university.png` | Needed |
| Acıbadem University | Turkey | `public/images/universities/ac-badem-university.jpg` | Needed | `public/images/university-logos/ac-badem-university.png` | Needed |
| Adana Alparslan Türkeş Science and Technology University | Turkey | `public/images/universities/adana-alparslan-turkes-science-and-technology-university.jpg` | Needed | `public/images/university-logos/adana-alparslan-turkes-science-and-technology-university.png` | Needed |
| Adıyaman University | Turkey | `public/images/universities/ad-yaman-university.jpg` | Needed | `public/images/university-logos/ad-yaman-university.png` | Needed |
| Afyon Kocatepe University | Turkey | `public/images/universities/afyon-kocatepe-university.jpg` | Needed | `public/images/university-logos/afyon-kocatepe-university.png` | Present |
| Afyonkarahisar Health Sciences University | Turkey | `public/images/universities/afyonkarahisar-health-sciences-university.jpg` | Needed | `public/images/university-logos/afyonkarahisar-health-sciences-university.png` | Needed |
| Aksaray University | Turkey | `public/images/universities/aksaray-university.jpg` | Needed | `public/images/university-logos/aksaray-university.png` | Needed |
| Alanya Alaaddin Keykubat University | Turkey | `public/images/universities/alanya-alaaddin-keykubat-university.jpg` | Needed | `public/images/university-logos/alanya-alaaddin-keykubat-university.png` | Needed |
| Altınbaş University | Turkey | `public/images/universities/alt-nbas-university.jpg` | Needed | `public/images/university-logos/alt-nbas-university.png` | Needed |
| Ankara Yıldırım Beyazıt University | Turkey | `public/images/universities/ankara-y-ld-r-m-beyaz-t-university.jpg` | Needed | `public/images/university-logos/ankara-y-ld-r-m-beyaz-t-university.png` | Needed |
| Atılım University | Turkey | `public/images/universities/at-l-m-university.jpg` | Needed | `public/images/university-logos/at-l-m-university.png` | Needed |
| Aydın Adnan Menderes University | Turkey | `public/images/universities/ayd-n-adnan-menderes-university.jpg` | Needed | `public/images/university-logos/ayd-n-adnan-menderes-university.png` | Needed |
| Balıkesir University | Turkey | `public/images/universities/bal-kesir-university.jpg` | Needed | `public/images/university-logos/bal-kesir-university.png` | Needed |
| Başkent University | Turkey | `public/images/universities/baskent-university.jpg` | Needed | `public/images/university-logos/baskent-university.png` | Needed |
| Beykent University | Turkey | `public/images/universities/beykent-university.jpg` | Needed | `public/images/university-logos/beykent-university.png` | Needed |
| Bezmiâlem Vakıf University | Turkey | `public/images/universities/bezmialem-vak-f-university.jpg` | Needed | `public/images/university-logos/bezmialem-vak-f-university.png` | Needed |
| Bilecik Şeyh Edebali University | Turkey | `public/images/universities/bilecik-seyh-edebali-university.jpg` | Needed | `public/images/university-logos/bilecik-seyh-edebali-university.png` | Needed |
| Bolu Abant İzzet Baysal University | Turkey | `public/images/universities/bolu-abant-izzet-baysal-university.jpg` | Needed | `public/images/university-logos/bolu-abant-izzet-baysal-university.png` | Needed |
| Bozok University | Turkey | `public/images/universities/bozok-university.jpg` | Needed | `public/images/university-logos/bozok-university.png` | Needed |
| Burdur Mehmet Akif Ersoy University | Turkey | `public/images/universities/burdur-mehmet-akif-ersoy-university.jpg` | Needed | `public/images/university-logos/burdur-mehmet-akif-ersoy-university.png` | Needed |
| Bursa Technical University | Turkey | `public/images/universities/bursa-technical-university.jpg` | Needed | `public/images/university-logos/bursa-technical-university.png` | Needed |
| Bursa Uludağ University | Turkey | `public/images/universities/bursa-uludag-university.jpg` | Needed | `public/images/university-logos/bursa-uludag-university.png` | Needed |
| Çukurova University | Turkey | `public/images/universities/cukurova-university.jpg` | Needed | `public/images/university-logos/cukurova-university.png` | Needed |
| Dicle University | Turkey | `public/images/universities/dicle-university.jpg` | Needed | `public/images/university-logos/dicle-university.png` | Needed |
| Dokuz Eylül University | Turkey | `public/images/universities/dokuz-eylul-university.jpg` | Needed | `public/images/university-logos/dokuz-eylul-university.png` | Needed |
| Dumlupınar University | Turkey | `public/images/universities/dumlup-nar-university.jpg` | Needed | `public/images/university-logos/dumlup-nar-university.png` | Needed |
| Erzincan Binali Yıldırım University | Turkey | `public/images/universities/erzincan-binali-y-ld-r-m-university.jpg` | Needed | `public/images/university-logos/erzincan-binali-y-ld-r-m-university.png` | Needed |
| Eskişehir Osmangazi University | Turkey | `public/images/universities/eskisehir-osmangazi-university.jpg` | Needed | `public/images/university-logos/eskisehir-osmangazi-university.png` | Needed |
| Eskişehir Technical University | Turkey | `public/images/universities/eskisehir-technical-university.jpg` | Needed | `public/images/university-logos/eskisehir-technical-university.png` | Needed |
| Gaziantep University | Turkey | `public/images/universities/gaziantep-university.jpg` | Needed | `public/images/university-logos/gaziantep-university.png` | Needed |
| Giresun University | Turkey | `public/images/universities/giresun-university.jpg` | Needed | `public/images/university-logos/giresun-university.png` | Needed |
| Harran University | Turkey | `public/images/universities/harran-university.jpg` | Needed | `public/images/university-logos/harran-university.png` | Needed |
| Hatay Mustafa Kemal University | Turkey | `public/images/universities/hatay-mustafa-kemal-university.jpg` | Needed | `public/images/university-logos/hatay-mustafa-kemal-university.png` | Needed |
| Hitit University | Turkey | `public/images/universities/hitit-university.jpg` | Needed | `public/images/university-logos/hitit-university.png` | Needed |
| Istanbul Aydın University | Turkey | `public/images/universities/istanbul-ayd-n-university.jpg` | Needed | `public/images/university-logos/istanbul-ayd-n-university.png` | Needed |
| Istanbul Bilgi University | Turkey | `public/images/universities/istanbul-bilgi-university.jpg` | Needed | `public/images/university-logos/istanbul-bilgi-university.png` | Needed |
| Istanbul Okan University | Turkey | `public/images/universities/istanbul-okan-university.jpg` | Needed | `public/images/university-logos/istanbul-okan-university.png` | Needed |
| Izmir University of Economics | Turkey | `public/images/universities/izmir-university-of-economics.jpg` | Needed | `public/images/university-logos/izmir-university-of-economics.png` | Needed |
| Karabük University | Turkey | `public/images/universities/karabuk-university.jpg` | Needed | `public/images/university-logos/karabuk-university.png` | Needed |
| Karadeniz Technical University | Turkey | `public/images/universities/karadeniz-technical-university.jpg` | Needed | `public/images/university-logos/karadeniz-technical-university.png` | Needed |
| Karamanoğlu Mehmetbey University | Turkey | `public/images/universities/karamanoglu-mehmetbey-university.jpg` | Needed | `public/images/university-logos/karamanoglu-mehmetbey-university.png` | Needed |
| Kastamonu University | Turkey | `public/images/universities/kastamonu-university.jpg` | Needed | `public/images/university-logos/kastamonu-university.png` | Needed |
| Kırıkkale University | Turkey | `public/images/universities/k-r-kkale-university.jpg` | Needed | `public/images/university-logos/k-r-kkale-university.png` | Needed |
| Kocaeli University | Turkey | `public/images/universities/kocaeli-university.jpg` | Needed | `public/images/university-logos/kocaeli-university.png` | Present |
| Konya Technical University | Turkey | `public/images/universities/konya-technical-university.jpg` | Needed | `public/images/university-logos/konya-technical-university.png` | Needed |
| Kırşehir Ahi Evran University | Turkey | `public/images/universities/k-rsehir-ahi-evran-university.jpg` | Needed | `public/images/university-logos/k-rsehir-ahi-evran-university.png` | Needed |
| Manisa Celal Bayar University | Turkey | `public/images/universities/manisa-celal-bayar-university.jpg` | Needed | `public/images/university-logos/manisa-celal-bayar-university.png` | Needed |
| Marmara University | Turkey | `public/images/universities/marmara-university.jpg` | Needed | `public/images/university-logos/marmara-university.png` | Needed |
| Mersin University | Turkey | `public/images/universities/mersin-university.jpg` | Needed | `public/images/university-logos/mersin-university.png` | Needed |
| Muğla Sıtkı Koçman University | Turkey | `public/images/universities/mugla-s-tk-kocman-university.jpg` | Needed | `public/images/university-logos/mugla-s-tk-kocman-university.png` | Present |
| Muş Alparslan University | Turkey | `public/images/universities/mus-alparslan-university.jpg` | Needed | `public/images/university-logos/mus-alparslan-university.png` | Needed |
| Niğde Ömer Halisdemir University | Turkey | `public/images/universities/nigde-omer-halisdemir-university.jpg` | Needed | `public/images/university-logos/nigde-omer-halisdemir-university.png` | Needed |
| Ondokuz Mayıs University | Turkey | `public/images/universities/ondokuz-may-s-university.jpg` | Needed | `public/images/university-logos/ondokuz-may-s-university.png` | Needed |
| Ordu University | Turkey | `public/images/universities/ordu-university.jpg` | Needed | `public/images/university-logos/ordu-university.png` | Needed |
| Pamukkale University | Turkey | `public/images/universities/pamukkale-university.jpg` | Needed | `public/images/university-logos/pamukkale-university.png` | Needed |
| Recep Tayyip Erdoğan University | Turkey | `public/images/universities/recep-tayyip-erdogan-university.jpg` | Needed | `public/images/university-logos/recep-tayyip-erdogan-university.png` | Needed |
| Sakarya University of Applied Sciences | Turkey | `public/images/universities/sakarya-university-of-applied-sciences.jpg` | Needed | `public/images/university-logos/sakarya-university-of-applied-sciences.png` | Needed |
| Sinop University | Turkey | `public/images/universities/sinop-university.jpg` | Needed | `public/images/university-logos/sinop-university.png` | Needed |
| Sivas Cumhuriyet University | Turkey | `public/images/universities/sivas-cumhuriyet-university.jpg` | Needed | `public/images/university-logos/sivas-cumhuriyet-university.png` | Needed |
| Tekirdağ Namık Kemal University | Turkey | `public/images/universities/tekirdag-nam-k-kemal-university.jpg` | Needed | `public/images/university-logos/tekirdag-nam-k-kemal-university.png` | Needed |
| Tokat Gaziosmanpaşa University | Turkey | `public/images/universities/tokat-gaziosmanpasa-university.jpg` | Needed | `public/images/university-logos/tokat-gaziosmanpasa-university.png` | Needed |
| Trakya University | Turkey | `public/images/universities/trakya-university.jpg` | Needed | `public/images/university-logos/trakya-university.png` | Needed |
| Uşak University | Turkey | `public/images/universities/usak-university.jpg` | Needed | `public/images/university-logos/usak-university.png` | Needed |
| Van Yüzüncü Yıl University | Turkey | `public/images/universities/van-yuzuncu-y-l-university.jpg` | Needed | `public/images/university-logos/van-yuzuncu-y-l-university.png` | Needed |
| Yeditepe University | Turkey | `public/images/universities/yeditepe-university.jpg` | Needed | `public/images/university-logos/yeditepe-university.png` | Present |
| Zonguldak Bülent Ecevit University | Turkey | `public/images/universities/zonguldak-bulent-ecevit-university.jpg` | Needed | `public/images/university-logos/zonguldak-bulent-ecevit-university.png` | Needed |
| Çanakkale Onsekiz Mart University | Turkey | `public/images/universities/canakkale-onsekiz-mart-university.jpg` | Needed | `public/images/university-logos/canakkale-onsekiz-mart-university.png` | Needed |
| Çankırı Karatekin University | Turkey | `public/images/universities/cank-r-karatekin-university.jpg` | Needed | `public/images/university-logos/cank-r-karatekin-university.png` | Needed |
| Üsküdar University | Turkey | `public/images/universities/uskudar-university.jpg` | Needed | `public/images/university-logos/uskudar-university.png` | Needed |
| İzmir Kâtip Çelebi University | Turkey | `public/images/universities/izmir-katip-celebi-university.jpg` | Needed | `public/images/university-logos/izmir-katip-celebi-university.png` | Needed |
| Abertay University | United Kingdom | `public/images/universities/abertay-university.jpg` | Needed | `public/images/university-logos/abertay-university.png` | Needed |
| Aberystwyth University | United Kingdom | `public/images/universities/aberystwyth-university.jpg` | Needed | `public/images/university-logos/aberystwyth-university.png` | Needed |
| Anglia Ruskin University | United Kingdom | `public/images/universities/anglia-ruskin-university.jpg` | Needed | `public/images/university-logos/anglia-ruskin-university.png` | Needed |
| Aston University | United Kingdom | `public/images/universities/aston-university.jpg` | Needed | `public/images/university-logos/aston-university.png` | Present |
| Bangor University | United Kingdom | `public/images/universities/bangor-university.jpg` | Needed | `public/images/university-logos/bangor-university.png` | Needed |
| Bath Spa University | United Kingdom | `public/images/universities/bath-spa-university.jpg` | Needed | `public/images/university-logos/bath-spa-university.png` | Needed |
| Birkbeck, University of London | United Kingdom | `public/images/universities/birkbeck-university-of-london.jpg` | Needed | `public/images/university-logos/birkbeck-university-of-london.png` | Needed |
| Birmingham City University | United Kingdom | `public/images/universities/birmingham-city-university.jpg` | Needed | `public/images/university-logos/birmingham-city-university.png` | Needed |
| Bournemouth University | United Kingdom | `public/images/universities/bournemouth-university.jpg` | Needed | `public/images/university-logos/bournemouth-university.png` | Needed |
| Brunel University London | United Kingdom | `public/images/universities/brunel-university-london.jpg` | Needed | `public/images/university-logos/brunel-university-london.png` | Present |
| Canterbury Christ Church University | United Kingdom | `public/images/universities/canterbury-christ-church-university.jpg` | Needed | `public/images/university-logos/canterbury-christ-church-university.png` | Needed |
| Cardiff Metropolitan University | United Kingdom | `public/images/universities/cardiff-metropolitan-university.jpg` | Needed | `public/images/university-logos/cardiff-metropolitan-university.png` | Needed |
| Cardiff University | United Kingdom | `public/images/universities/cardiff-university.jpg` | Needed | `public/images/university-logos/cardiff-university.png` | Present |
| City St George’s, University of London | United Kingdom | `public/images/universities/city-st-george-s-university-of-london.jpg` | Needed | `public/images/university-logos/city-st-george-s-university-of-london.png` | Present |
| Coventry University | United Kingdom | `public/images/universities/coventry-university.jpg` | Needed | `public/images/university-logos/coventry-university.png` | Needed |
| Cranfield University | United Kingdom | `public/images/universities/cranfield-university.jpg` | Needed | `public/images/university-logos/cranfield-university.png` | Needed |
| De Montfort University | United Kingdom | `public/images/universities/de-montfort-university.jpg` | Needed | `public/images/university-logos/de-montfort-university.png` | Present |
| Durham University | United Kingdom | `public/images/universities/durham-university.jpg` | Needed | `public/images/university-logos/durham-university.png` | Present |
| Edge Hill University | United Kingdom | `public/images/universities/edge-hill-university.jpg` | Needed | `public/images/university-logos/edge-hill-university.png` | Needed |
| University of Edinburgh | United Kingdom | `public/images/universities/university-of-edinburgh.jpg` | Needed | `public/images/university-logos/university-of-edinburgh.png` | Needed |
| University of Exeter | United Kingdom | `public/images/universities/university-of-exeter.jpg` | Needed | `public/images/university-logos/university-of-exeter.png` | Present |
| Falmouth University | United Kingdom | `public/images/universities/falmouth-university.jpg` | Needed | `public/images/university-logos/falmouth-university.png` | Needed |
| University of Glasgow | United Kingdom | `public/images/universities/university-of-glasgow.jpg` | Needed | `public/images/university-logos/university-of-glasgow.png` | Present |
| Goldsmiths, University of London | United Kingdom | `public/images/universities/goldsmiths-university-of-london.jpg` | Needed | `public/images/university-logos/goldsmiths-university-of-london.png` | Needed |
| Harper Adams University | United Kingdom | `public/images/universities/harper-adams-university.jpg` | Needed | `public/images/university-logos/harper-adams-university.png` | Needed |
| Heriot-Watt University | United Kingdom | `public/images/universities/heriot-watt-university.jpg` | Needed | `public/images/university-logos/heriot-watt-university.png` | Needed |
| University of Hertfordshire | United Kingdom | `public/images/universities/university-of-hertfordshire.jpg` | Needed | `public/images/university-logos/university-of-hertfordshire.png` | Needed |
| University of Huddersfield | United Kingdom | `public/images/universities/university-of-huddersfield.jpg` | Needed | `public/images/university-logos/university-of-huddersfield.png` | Needed |
| University of Hull | United Kingdom | `public/images/universities/university-of-hull.jpg` | Needed | `public/images/university-logos/university-of-hull.png` | Needed |
| Keele University | United Kingdom | `public/images/universities/keele-university.jpg` | Needed | `public/images/university-logos/keele-university.png` | Needed |
| King’s College London | United Kingdom | `public/images/universities/king-s-college-london.jpg` | Needed | `public/images/university-logos/king-s-college-london.png` | Needed |
| Kingston University | United Kingdom | `public/images/universities/kingston-university.jpg` | Needed | `public/images/university-logos/kingston-university.png` | Present |
| Lancaster University | United Kingdom | `public/images/universities/lancaster-university.jpg` | Needed | `public/images/university-logos/lancaster-university.png` | Present |
| University of Leeds | United Kingdom | `public/images/universities/university-of-leeds.jpg` | Needed | `public/images/university-logos/university-of-leeds.png` | Present |
| Leeds Beckett University | United Kingdom | `public/images/universities/leeds-beckett-university.jpg` | Needed | `public/images/university-logos/leeds-beckett-university.png` | Present |
| Leeds Trinity University | United Kingdom | `public/images/universities/leeds-trinity-university.jpg` | Needed | `public/images/university-logos/leeds-trinity-university.png` | Present |
| University of Leicester | United Kingdom | `public/images/universities/university-of-leicester.jpg` | Needed | `public/images/university-logos/university-of-leicester.png` | Present |
| University of Lincoln | United Kingdom | `public/images/universities/university-of-lincoln.jpg` | Needed | `public/images/university-logos/university-of-lincoln.png` | Needed |
| University of Liverpool | United Kingdom | `public/images/universities/university-of-liverpool.jpg` | Needed | `public/images/university-logos/university-of-liverpool.png` | Present |
| Liverpool John Moores University | United Kingdom | `public/images/universities/liverpool-john-moores-university.jpg` | Needed | `public/images/university-logos/liverpool-john-moores-university.png` | Needed |
| London Metropolitan University | United Kingdom | `public/images/universities/london-metropolitan-university.jpg` | Needed | `public/images/university-logos/london-metropolitan-university.png` | Needed |
| London School of Economics and Political Science | United Kingdom | `public/images/universities/london-school-of-economics-and-political-science.jpg` | Needed | `public/images/university-logos/london-school-of-economics-and-political-science.png` | Needed |
| London South Bank University | United Kingdom | `public/images/universities/london-south-bank-university.jpg` | Needed | `public/images/university-logos/london-south-bank-university.png` | Needed |
| Loughborough University | United Kingdom | `public/images/universities/loughborough-university.jpg` | Needed | `public/images/university-logos/loughborough-university.png` | Needed |
| University of Manchester | United Kingdom | `public/images/universities/university-of-manchester.jpg` | Needed | `public/images/university-logos/university-of-manchester.png` | Present |
| Manchester Metropolitan University | United Kingdom | `public/images/universities/manchester-metropolitan-university.jpg` | Needed | `public/images/university-logos/manchester-metropolitan-university.png` | Present |
| Middlesex University | United Kingdom | `public/images/universities/middlesex-university.jpg` | Needed | `public/images/university-logos/middlesex-university.png` | Needed |
| Newcastle University | United Kingdom | `public/images/universities/newcastle-university.jpg` | Needed | `public/images/university-logos/newcastle-university.png` | Present |
| Northumbria University | United Kingdom | `public/images/universities/northumbria-university.jpg` | Needed | `public/images/university-logos/northumbria-university.png` | Needed |
| University of Nottingham | United Kingdom | `public/images/universities/university-of-nottingham.jpg` | Needed | `public/images/university-logos/university-of-nottingham.png` | Needed |
| Nottingham Trent University | United Kingdom | `public/images/universities/nottingham-trent-university.jpg` | Needed | `public/images/university-logos/nottingham-trent-university.png` | Needed |
| The Open University | United Kingdom | `public/images/universities/the-open-university.jpg` | Needed | `public/images/university-logos/the-open-university.png` | Needed |
| Oxford Brookes University | United Kingdom | `public/images/universities/oxford-brookes-university.jpg` | Needed | `public/images/university-logos/oxford-brookes-university.png` | Present |
| University of Plymouth | United Kingdom | `public/images/universities/university-of-plymouth.jpg` | Needed | `public/images/university-logos/university-of-plymouth.png` | Needed |
| University of Portsmouth | United Kingdom | `public/images/universities/university-of-portsmouth.jpg` | Needed | `public/images/university-logos/university-of-portsmouth.png` | Needed |
| Queen Mary University of London | United Kingdom | `public/images/universities/queen-mary-university-of-london.jpg` | Needed | `public/images/university-logos/queen-mary-university-of-london.png` | Present |
| Queen’s University Belfast | United Kingdom | `public/images/universities/queen-s-university-belfast.jpg` | Needed | `public/images/university-logos/queen-s-university-belfast.png` | Present |
| University of Reading | United Kingdom | `public/images/universities/university-of-reading.jpg` | Needed | `public/images/university-logos/university-of-reading.png` | Present |
| University of Roehampton | United Kingdom | `public/images/universities/university-of-roehampton.jpg` | Needed | `public/images/university-logos/university-of-roehampton.png` | Needed |
| University of Salford | United Kingdom | `public/images/universities/university-of-salford.jpg` | Needed | `public/images/university-logos/university-of-salford.png` | Needed |
| University of Sheffield | United Kingdom | `public/images/universities/university-of-sheffield.jpg` | Needed | `public/images/university-logos/university-of-sheffield.png` | Present |
| Sheffield Hallam University | United Kingdom | `public/images/universities/sheffield-hallam-university.jpg` | Needed | `public/images/university-logos/sheffield-hallam-university.png` | Present |
| University of Southampton | United Kingdom | `public/images/universities/university-of-southampton.jpg` | Needed | `public/images/university-logos/university-of-southampton.png` | Needed |
| University of St Andrews | United Kingdom | `public/images/universities/university-of-st-andrews.jpg` | Needed | `public/images/university-logos/university-of-st-andrews.png` | Present |
| University of Stirling | United Kingdom | `public/images/universities/university-of-stirling.jpg` | Needed | `public/images/university-logos/university-of-stirling.png` | Needed |
| University of Strathclyde | United Kingdom | `public/images/universities/university-of-strathclyde.jpg` | Needed | `public/images/university-logos/university-of-strathclyde.png` | Needed |
| University of Surrey | United Kingdom | `public/images/universities/university-of-surrey.jpg` | Needed | `public/images/university-logos/university-of-surrey.png` | Present |
| University of Sussex | United Kingdom | `public/images/universities/university-of-sussex.jpg` | Needed | `public/images/university-logos/university-of-sussex.png` | Present |
| Swansea University | United Kingdom | `public/images/universities/swansea-university.jpg` | Needed | `public/images/university-logos/swansea-university.png` | Needed |
| Teesside University | United Kingdom | `public/images/universities/teesside-university.jpg` | Needed | `public/images/university-logos/teesside-university.png` | Needed |
| University of the Arts London | United Kingdom | `public/images/universities/university-of-the-arts-london.jpg` | Needed | `public/images/university-logos/university-of-the-arts-london.png` | Needed |
| University of Bath | United Kingdom | `public/images/universities/university-of-bath.jpg` | Needed | `public/images/university-logos/university-of-bath.png` | Present |
| University of Bedfordshire | United Kingdom | `public/images/universities/university-of-bedfordshire.jpg` | Needed | `public/images/university-logos/university-of-bedfordshire.png` | Needed |
| University of Birmingham | United Kingdom | `public/images/universities/university-of-birmingham.jpg` | Needed | `public/images/university-logos/university-of-birmingham.png` | Needed |
| University of Bradford | United Kingdom | `public/images/universities/university-of-bradford.jpg` | Needed | `public/images/university-logos/university-of-bradford.png` | Needed |
| University of Brighton | United Kingdom | `public/images/universities/university-of-brighton.jpg` | Needed | `public/images/university-logos/university-of-brighton.png` | Needed |
| University of Bristol | United Kingdom | `public/images/universities/university-of-bristol.jpg` | Needed | `public/images/university-logos/university-of-bristol.png` | Present |
| University of Chester | United Kingdom | `public/images/universities/university-of-chester.jpg` | Needed | `public/images/university-logos/university-of-chester.png` | Needed |
| University of Dundee | United Kingdom | `public/images/universities/university-of-dundee.jpg` | Needed | `public/images/university-logos/university-of-dundee.png` | Present |
| University of East Anglia | United Kingdom | `public/images/universities/university-of-east-anglia.jpg` | Needed | `public/images/university-logos/university-of-east-anglia.png` | Needed |
| University of East London | United Kingdom | `public/images/universities/university-of-east-london.jpg` | Needed | `public/images/university-logos/university-of-east-london.png` | Needed |
| University of Essex | United Kingdom | `public/images/universities/university-of-essex.jpg` | Needed | `public/images/university-logos/university-of-essex.png` | Needed |
| University of Greenwich | United Kingdom | `public/images/universities/university-of-greenwich.jpg` | Needed | `public/images/university-logos/university-of-greenwich.png` | Needed |
| University of Kent | United Kingdom | `public/images/universities/university-of-kent.jpg` | Needed | `public/images/university-logos/university-of-kent.png` | Needed |
| University of Northumbria at Newcastle | United Kingdom | `public/images/universities/university-of-northumbria-at-newcastle.jpg` | Needed | `public/images/university-logos/university-of-northumbria-at-newcastle.png` | Needed |
| University of Warwick | United Kingdom | `public/images/universities/university-of-warwick.jpg` | Needed | `public/images/university-logos/university-of-warwick.png` | Present |
| University of Westminster | United Kingdom | `public/images/universities/university-of-westminster.jpg` | Needed | `public/images/university-logos/university-of-westminster.png` | Present |
| University of Wolverhampton | United Kingdom | `public/images/universities/university-of-wolverhampton.jpg` | Needed | `public/images/university-logos/university-of-wolverhampton.png` | Needed |
| University of York | United Kingdom | `public/images/universities/university-of-york.jpg` | Needed | `public/images/university-logos/university-of-york.png` | Present |
| University of York St John | United Kingdom | `public/images/universities/university-of-york-st-john.jpg` | Needed | `public/images/university-logos/university-of-york-st-john.png` | Present |
| Scuola Normale Superiore di Pisa | Italy | `public/images/universities/scuola-normale-superiore-di-pisa.jpg` | Needed | `public/images/university-logos/scuola-normale-superiore-di-pisa.png` | Needed |
| Sapienza University of Rome | Italy | `public/images/universities/sapienza-university-of-rome.jpg` | Needed | `public/images/university-logos/sapienza-university-of-rome.png` | Present |
| Politecnico di Milano | Italy | `public/images/universities/politecnico-di-milano.jpg` | Needed | `public/images/university-logos/politecnico-di-milano.png` | Present |
| Sant’Anna School of Advanced Studies | Italy | `public/images/universities/sant-anna-school-of-advanced-studies.jpg` | Needed | `public/images/university-logos/sant-anna-school-of-advanced-studies.png` | Needed |
| University of Padua | Italy | `public/images/universities/university-of-padua.jpg` | Needed | `public/images/university-logos/university-of-padua.png` | Present |
| Humanitas University | Italy | `public/images/universities/humanitas-university.jpg` | Needed | `public/images/university-logos/humanitas-university.png` | Needed |
| Università Cattolica del Sacro Cuore | Italy | `public/images/universities/universita-cattolica-del-sacro-cuore.jpg` | Needed | `public/images/university-logos/universita-cattolica-del-sacro-cuore.png` | Present |
| Vita-Salute San Raffaele University | Italy | `public/images/universities/vita-salute-san-raffaele-university.jpg` | Needed | `public/images/university-logos/vita-salute-san-raffaele-university.png` | Needed |
| University of Milan | Italy | `public/images/universities/university-of-milan.jpg` | Needed | `public/images/university-logos/university-of-milan.png` | Present |
| University of Naples Federico II | Italy | `public/images/universities/university-of-naples-federico-ii.jpg` | Needed | `public/images/university-logos/university-of-naples-federico-ii.png` | Needed |
| University of Rome Tor Vergata | Italy | `public/images/universities/university-of-rome-tor-vergata.jpg` | Needed | `public/images/university-logos/university-of-rome-tor-vergata.png` | Present |
| University of Brescia | Italy | `public/images/universities/university-of-brescia.jpg` | Needed | `public/images/university-logos/university-of-brescia.png` | Needed |
| University of Florence | Italy | `public/images/universities/university-of-florence.jpg` | Needed | `public/images/university-logos/university-of-florence.png` | Present |
| University of Pavia | Italy | `public/images/universities/university-of-pavia.jpg` | Needed | `public/images/university-logos/university-of-pavia.png` | Needed |
| University of Pisa | Italy | `public/images/universities/university-of-pisa.jpg` | Needed | `public/images/university-logos/university-of-pisa.png` | Present |
| University of Siena | Italy | `public/images/universities/university-of-siena.jpg` | Needed | `public/images/university-logos/university-of-siena.png` | Present |
| University of Trento | Italy | `public/images/universities/university-of-trento.jpg` | Needed | `public/images/university-logos/university-of-trento.png` | Present |
| University of Verona | Italy | `public/images/universities/university-of-verona.jpg` | Needed | `public/images/university-logos/university-of-verona.png` | Needed |
| Free University of Bozen-Bolzano | Italy | `public/images/universities/free-university-of-bozen-bolzano.jpg` | Needed | `public/images/university-logos/free-university-of-bozen-bolzano.png` | Needed |
| Marche Polytechnic University | Italy | `public/images/universities/marche-polytechnic-university.jpg` | Needed | `public/images/university-logos/marche-polytechnic-university.png` | Needed |
| Polytechnic University of Turin | Italy | `public/images/universities/polytechnic-university-of-turin.jpg` | Needed | `public/images/university-logos/polytechnic-university-of-turin.png` | Needed |
| University of Genoa | Italy | `public/images/universities/university-of-genoa.jpg` | Needed | `public/images/university-logos/university-of-genoa.png` | Needed |
| University of Milan-Bicocca | Italy | `public/images/universities/university-of-milan-bicocca.jpg` | Needed | `public/images/university-logos/university-of-milan-bicocca.png` | Present |
| University of Turin | Italy | `public/images/universities/university-of-turin.jpg` | Needed | `public/images/university-logos/university-of-turin.png` | Needed |
| Ca’ Foscari University of Venice | Italy | `public/images/universities/ca-foscari-university-of-venice.jpg` | Needed | `public/images/university-logos/ca-foscari-university-of-venice.png` | Present |
| Campus Bio-Medico University of Rome | Italy | `public/images/universities/campus-bio-medico-university-of-rome.jpg` | Needed | `public/images/university-logos/campus-bio-medico-university-of-rome.png` | Needed |
| Polytechnic University of Bari | Italy | `public/images/universities/polytechnic-university-of-bari.jpg` | Needed | `public/images/university-logos/polytechnic-university-of-bari.png` | Needed |
| University of Catania | Italy | `public/images/universities/university-of-catania.jpg` | Needed | `public/images/university-logos/university-of-catania.png` | Needed |
| University of Ferrara | Italy | `public/images/universities/university-of-ferrara.jpg` | Needed | `public/images/university-logos/university-of-ferrara.png` | Needed |
| University of Messina | Italy | `public/images/universities/university-of-messina.jpg` | Needed | `public/images/university-logos/university-of-messina.png` | Needed |
| University of Modena and Reggio Emilia | Italy | `public/images/universities/university-of-modena-and-reggio-emilia.jpg` | Needed | `public/images/university-logos/university-of-modena-and-reggio-emilia.png` | Needed |
| University of Palermo | Italy | `public/images/universities/university-of-palermo.jpg` | Needed | `public/images/university-logos/university-of-palermo.png` | Needed |
| University of Salerno | Italy | `public/images/universities/university-of-salerno.jpg` | Needed | `public/images/university-logos/university-of-salerno.png` | Needed |
| University of Trieste | Italy | `public/images/universities/university-of-trieste.jpg` | Needed | `public/images/university-logos/university-of-trieste.png` | Needed |
| University of Eastern Piedmont | Italy | `public/images/universities/university-of-eastern-piedmont.jpg` | Needed | `public/images/university-logos/university-of-eastern-piedmont.png` | Needed |
| Parthenope University of Naples | Italy | `public/images/universities/parthenope-university-of-naples.jpg` | Needed | `public/images/university-logos/parthenope-university-of-naples.png` | Needed |
| University of Bari Aldo Moro | Italy | `public/images/universities/university-of-bari-aldo-moro.jpg` | Needed | `public/images/university-logos/university-of-bari-aldo-moro.png` | Needed |
| University of Cagliari | Italy | `public/images/universities/university-of-cagliari.jpg` | Needed | `public/images/university-logos/university-of-cagliari.png` | Needed |
| University of Calabria | Italy | `public/images/universities/university-of-calabria.jpg` | Needed | `public/images/university-logos/university-of-calabria.png` | Needed |
| University of Insubria | Italy | `public/images/universities/university-of-insubria.jpg` | Needed | `public/images/university-logos/university-of-insubria.png` | Needed |
| University of L’Aquila | Italy | `public/images/universities/university-of-l-aquila.jpg` | Needed | `public/images/university-logos/university-of-l-aquila.png` | Needed |
| University of Parma | Italy | `public/images/universities/university-of-parma.jpg` | Needed | `public/images/university-logos/university-of-parma.png` | Needed |
| University of Tuscia | Italy | `public/images/universities/university-of-tuscia.jpg` | Needed | `public/images/university-logos/university-of-tuscia.png` | Needed |
| University of Udine | Italy | `public/images/universities/university-of-udine.jpg` | Needed | `public/images/university-logos/university-of-udine.png` | Needed |
| Gabriele d’Annunzio University | Italy | `public/images/universities/gabriele-d-annunzio-university.jpg` | Needed | `public/images/university-logos/gabriele-d-annunzio-university.png` | Needed |
| University of Foggia | Italy | `public/images/universities/university-of-foggia.jpg` | Needed | `public/images/university-logos/university-of-foggia.png` | Needed |
| Roma Tre University | Italy | `public/images/universities/roma-tre-university.jpg` | Needed | `public/images/university-logos/roma-tre-university.png` | Needed |
| University of Salento | Italy | `public/images/universities/university-of-salento.jpg` | Needed | `public/images/university-logos/university-of-salento.png` | Needed |
| Kore University of Enna | Italy | `public/images/universities/kore-university-of-enna.jpg` | Needed | `public/images/university-logos/kore-university-of-enna.png` | Needed |
| University of Camerino | Italy | `public/images/universities/university-of-camerino.jpg` | Needed | `public/images/university-logos/university-of-camerino.png` | Needed |
| University of Campania Luigi Vanvitelli | Italy | `public/images/universities/university-of-campania-luigi-vanvitelli.jpg` | Needed | `public/images/university-logos/university-of-campania-luigi-vanvitelli.png` | Needed |
| University of Sannio | Italy | `public/images/universities/university-of-sannio.jpg` | Needed | `public/images/university-logos/university-of-sannio.png` | Needed |
| University of Urbino Carlo Bo | Italy | `public/images/universities/university-of-urbino-carlo-bo.jpg` | Needed | `public/images/university-logos/university-of-urbino-carlo-bo.png` | Needed |
| Cyprus University of Technology | Cyprus | `public/images/universities/cyprus-university-of-technology.jpg` | Needed | `public/images/university-logos/cyprus-university-of-technology.png` | Present |
| Frederick University | Cyprus | `public/images/universities/frederick-university.jpg` | Needed | `public/images/university-logos/frederick-university.png` | Present |
| Neapolis University Pafos | Cyprus | `public/images/universities/neapolis-university-pafos.jpg` | Needed | `public/images/university-logos/neapolis-university-pafos.png` | Present |
| Open University of Cyprus | Cyprus | `public/images/universities/open-university-of-cyprus.jpg` | Needed | `public/images/university-logos/open-university-of-cyprus.png` | Present |
| University of Cyprus | Cyprus | `public/images/universities/university-of-cyprus.jpg` | Needed | `public/images/university-logos/university-of-cyprus.png` | Present |
| UCLan Cyprus | Cyprus | `public/images/universities/uclan-cyprus.jpg` | Needed | `public/images/university-logos/uclan-cyprus.png` | Present |
| University of Bucharest | Romania | `public/images/universities/university-of-bucharest.jpg` | Needed | `public/images/university-logos/university-of-bucharest.png` | Needed |
| Babeș-Bolyai University | Romania | `public/images/universities/babes-bolyai-university.jpg` | Needed | `public/images/university-logos/babes-bolyai-university.png` | Needed |
| Politehnica University of Bucharest | Romania | `public/images/universities/politehnica-university-of-bucharest.jpg` | Needed | `public/images/university-logos/politehnica-university-of-bucharest.png` | Needed |
| Alexandru Ioan Cuza University of Iași | Romania | `public/images/universities/alexandru-ioan-cuza-university-of-iasi.jpg` | Needed | `public/images/university-logos/alexandru-ioan-cuza-university-of-iasi.png` | Needed |
| West University of Timișoara | Romania | `public/images/universities/west-university-of-timisoara.jpg` | Needed | `public/images/university-logos/west-university-of-timisoara.png` | Needed |
| Transilvania University of Brașov | Romania | `public/images/universities/transilvania-university-of-brasov.jpg` | Needed | `public/images/university-logos/transilvania-university-of-brasov.png` | Needed |
| University of Craiova | Romania | `public/images/universities/university-of-craiova.jpg` | Needed | `public/images/university-logos/university-of-craiova.png` | Needed |
| Technical University of Cluj-Napoca | Romania | `public/images/universities/technical-university-of-cluj-napoca.jpg` | Needed | `public/images/university-logos/technical-university-of-cluj-napoca.png` | Needed |
| Gheorghe Asachi Technical University of Iași | Romania | `public/images/universities/gheorghe-asachi-technical-university-of-iasi.jpg` | Needed | `public/images/university-logos/gheorghe-asachi-technical-university-of-iasi.png` | Needed |
| Ovidius University of Constanța | Romania | `public/images/universities/ovidius-university-of-constanta.jpg` | Needed | `public/images/university-logos/ovidius-university-of-constanta.png` | Needed |
