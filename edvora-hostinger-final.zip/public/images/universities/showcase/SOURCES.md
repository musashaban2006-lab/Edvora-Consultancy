# University hero image sources

These decorative hero images were downloaded locally from Pexels. They are not intended to identify or imply a partnership with a particular institution. Pexels says its license allows free personal and commercial website use without mandatory attribution; photographer credits are included here as a courtesy.

- `edinburgh-university.jpg` — “The University of Edinburgh,” Adrien Olichon: https://www.pexels.com/photo/the-university-of-edinburgh-13415005/
- `birmingham-university-campus.jpg` — “White Concrete Building Near Green Grass Field,” Turag Photography: https://www.pexels.com/photo/white-concrete-building-near-green-grass-field-10466439/
- `manchester-university.jpg` — “The University of Manchester in England,” Szymon Shields: https://www.pexels.com/photo/the-university-of-manchester-in-england-11210300/
- `../university-of-cambridge.jpg` — “Historic Architecture at Cambridge University,” Gamze Yalçınkaya: https://www.pexels.com/photo/historic-architecture-at-cambridge-university-34115522/
- `../university-of-oxford.jpg` — “Historic University Building in Oxford,” Adam Lalam: https://www.pexels.com/photo/historic-university-building-in-oxford-32570526/
- `../imperial-college-london.jpg` — “Aerial View of London with Imperial College and Royal Albert Hall,” Chengxin Zhao: https://www.pexels.com/photo/imperial-collage-london-28288873/
- `../lund-university.jpg` — “The Frontage of the Lund University Building in Sweden,” Isaac Cedercrantz: https://www.pexels.com/photo/the-frontage-of-the-lund-university-building-in-sweden-5759538/
- `../istanbul-university.jpg` — “Historic Entrance of Istanbul University,” Muhammed Fatih Beki: https://www.pexels.com/photo/historic-entrance-of-istanbul-university-33315305/
- `../koc-university.jpg` — “Clock Tower at University Campus in Spring” (Koç University), Murat Ak: https://www.pexels.com/photo/clock-tower-at-university-campus-in-spring-31830340/
- `illustrative-campus-lakeside.jpg` — “Modern University Building by Lakeside” (Coral Gables, Florida), DΛVΞ GΛRCIΛ: https://www.pexels.com/photo/modern-university-building-by-lakeside-31085766/
- `illustrative-campus-students.jpg` — “Students Walking by an University Building,” George Pak: https://www.pexels.com/photo/students-walking-by-an-university-building-7972502/

The university directory uses institution-specific photos only where a Pexels image could be matched to that institution. Other entries use one of the clearly badged illustrative campus photos; they are not presented as that university's own campus.

License information: https://www.pexels.com/license/
