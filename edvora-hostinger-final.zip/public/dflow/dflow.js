(() => {
  const countries = [
    { name: "United Kingdom", src: "/assets/countries/uk.webp", alt: "Edinburgh cityscape in the United Kingdom" },
    { name: "Sweden", src: "/assets/countries/sweden.webp", alt: "Stockholm waterfront in Sweden" },
    { name: "Finland", src: "/assets/countries/finland.webp", alt: "Northern lights above Finland" },
    { name: "China", src: "/assets/countries/china.webp", alt: "Traditional Chinese landmark architecture" },
    { name: "Italy", src: "/assets/countries/italy.webp", alt: "The Colosseum in Rome, Italy" },
    { name: "Turkey", src: "/assets/countries/turkey.webp", alt: "Historic landmark in Istanbul, Turkey" },
    { name: "Romania", src: null, alt: "Landmark destination in Romania" },
  ];
  const frame = document.querySelector(".dflow-frame");
  const left = document.querySelector(".dflow-stream-left");
  const right = document.querySelector(".dflow-stream-right");
  if (!frame || !left || !right) return;

  const cycle = 17.5;
  const step = cycle / countries.length;
  const halfCycle = cycle / 2;
  const buildCard = (country, index, delay) => {
    const card = document.createElement("div");
    card.className = "dflow-card";
    card.style.animationDelay = `${delay}s`;
    card.style.zIndex = String(countries.length - index);
    if (country.src) {
      const image = document.createElement("img");
      image.className = "dflow-card-image";
      image.src = country.src;
      image.alt = country.alt;
      image.loading = "lazy";
      image.decoding = "async";
      image.addEventListener("error", () => {
        const placeholder = document.createElement("span");
        placeholder.className = "dflow-placeholder";
        placeholder.setAttribute("role", "img");
        placeholder.setAttribute("aria-label", country.alt);
        image.replaceWith(placeholder);
      }, { once: true });
      card.append(image);
    } else {
      const placeholder = document.createElement("span");
      placeholder.className = "dflow-placeholder";
      placeholder.setAttribute("role", "img");
      placeholder.setAttribute("aria-label", country.alt);
      card.append(placeholder);
    }
    return card;
  };

  countries.forEach((country, index) => {
    left.append(buildCard(country, index, -index * step));
    right.append(buildCard(country, index, -(index * step + halfCycle)));
  });

  const media = window.matchMedia("(prefers-reduced-motion: reduce)");
  let onScreen = true;
  let tabVisible = document.visibilityState === "visible";
  const updatePlayback = () => {
    frame.classList.toggle("dflow-paused", media.matches || !onScreen || !tabVisible);
  };
  const observer = new IntersectionObserver(([entry]) => {
    onScreen = entry.isIntersecting;
    updatePlayback();
  });
  observer.observe(frame);
  document.addEventListener("visibilitychange", () => {
    tabVisible = document.visibilityState === "visible";
    updatePlayback();
  });
  media.addEventListener("change", updatePlayback);
  updatePlayback();
})();
