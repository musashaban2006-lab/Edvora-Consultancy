#!/usr/bin/env python3
"""
Fetch real Pexels photos for every university listed in universities.json
(United Kingdom, Turkey, South Cyprus, Italy ... add more countries to the JSON file).

SETUP
    1. Free API key:  https://www.pexels.com/api/new/
    2. export PEXELS_API_KEY="your_key_here"        (Windows PowerShell: $env:PEXELS_API_KEY="your_key_here")

RUN
    python3 fetch_university_images.py --limit 3     # quick test on 3 universities
    python3 fetch_university_images.py               # everything (takes hours; resumable)
    python3 fetch_university_images.py --country Turkey      # one country only

OUTPUT (next to this script)
    images/<slug>.jpg      one photo per university  (slug = country + name, e.g. turkey-koc-university)
    manifest.json          credits, country, and MATCH QUALITY ("tier") for every university
    search_cache.json      saved Pexels answers, so re-runs cost no API requests
    images/_shared/        download cache (safe to delete when finished)

MATCH TIERS - be honest about these in your UI
    named    the photo's title/description mentions that university (or a known landmark of it)
    city     a photo of the university's city  - a placeholder, NOT the campus
    generic  a generic "university campus" photo - a placeholder only
    (a "reused": true flag means the same photo is also used by another university)

LIMITS: Pexels allows 200 API requests/hour and 20,000/month. This script stays under 180/hour
by pausing automatically, and it remembers its request history between runs. Do not edit it to
bypass the throttle - Pexels can revoke keys that do.
ATTRIBUTION: Pexels asks for a prominent link back (e.g. "Photos provided by Pexels").
"""
import argparse, json, os, re, shutil, sys, time, unicodedata
import urllib.error, urllib.parse, urllib.request
from collections import deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "universities.json"
OUT = HERE / "images"
SHARED = OUT / "_shared"
MANIFEST = HERE / "manifest.json"
CACHE = HERE / "search_cache.json"
REQLOG = HERE / ".request_log.json"

API = "https://api.pexels.com/v1/search"
UA = "Mozilla/5.0 (university-directory-image-fetcher)"
MAX_REQ_PER_HOUR = 180
# How a country is written in "city + country" search queries (default: the country name itself)
SEARCH_COUNTRY = {"United Kingdom": "UK", "South Cyprus": "Cyprus"}

_TRANSLIT = str.maketrans({"ı": "i", "ß": "ss", "ø": "o", "æ": "ae", "œ": "oe", "ł": "l", "đ": "d", "ð": "d", "þ": "th"})


def norm(s):
    """lowercase, strip accents/apostrophes/punctuation: 'Boğaziçi' -> 'bogazici', 'King’s' -> 'kings'."""
    s = s.replace("’", "'")
    s = unicodedata.normalize("NFKD", s.lower().replace("'", ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).translate(_TRANSLIT)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def load_unis(path=DATA):
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    unis = []
    for r in raw:
        core = r.get("core") or r["name"]
        must = {norm(r["name"]), norm(f"{core} university"), norm(f"university of {core}")}
        must |= {norm(x) for x in r.get("extras", [])}
        must |= {norm(x) for x in r.get("aliases", [])}
        unis.append(dict(r, slug=norm(f"{r['country']} {r['name']}").replace(" ", "-"),
                         must=sorted(m for m in must if m),
                         reject=[norm(x) for x in r.get("reject", [])]))
    slugs = [u["slug"] for u in unis]
    dupes = {s for s in slugs if slugs.count(s) > 1}
    if dupes:
        sys.exit(f"Duplicate slugs in universities.json: {dupes}")
    return unis


# ------------------------------------------------------------------ rate limiting + cache
def _load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


_sent = deque(t for t in _load_json(REQLOG, []) if time.time() - t < 3600)
_cache = _load_json(CACHE, {})


def throttle():
    now = time.time()
    while _sent and now - _sent[0] > 3600:
        _sent.popleft()
    if len(_sent) >= MAX_REQ_PER_HOUR:
        wait = 3600 - (now - _sent[0]) + 5
        print(f"  [rate limit] pausing {int(wait // 60)} min to stay under Pexels' 200/hour...")
        time.sleep(wait)
    _sent.append(time.time())
    REQLOG.write_text(json.dumps(list(_sent)))


def trim(p):
    s = p.get("src", {})
    return dict(id=p["id"], url=p["url"], alt=p.get("alt", ""), photographer=p["photographer"],
                photographer_url=p["photographer_url"], width=p["width"], height=p["height"],
                src={"large2x": s.get("large2x"), "large": s.get("large")})


def search(query, key, retries=1):
    ck = norm(query)
    if ck in _cache:
        return _cache[ck]
    throttle()
    url = f"{API}?{urllib.parse.urlencode({'query': query, 'per_page': 30, 'orientation': 'landscape'})}"
    req = urllib.request.Request(url, headers={"Authorization": key, "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            photos = [trim(p) for p in json.load(r).get("photos", [])]
    except urllib.error.HTTPError as e:
        if e.code == 429 and retries:
            print("  [429] Pexels says slow down - sleeping 10 minutes...")
            time.sleep(600)
            return search(query, key, retries - 1)
        print(f"  [HTTP {e.code}] {query}" + ("  <- check your API key" if e.code in (401, 403) else ""))
        return []
    except Exception as e:
        print(f"  [error] {query}: {e}")
        return []
    _cache[ck] = photos
    CACHE.write_text(json.dumps(_cache, ensure_ascii=False))
    return photos


# ------------------------------------------------------------------ matching
def text_of(p):
    # alt text + the words inside the photo-page URL both carry the photographer's description
    slug = p["url"].split("/photo/")[-1].rsplit("-", 1)[0]
    return norm((p.get("alt") or "") + " " + slug)


def has(text, phrase):
    return re.search(rf"\b{re.escape(phrase)}\b", text) is not None


def pick(photos, uni, tier, used):
    """Return (photo, reused). 'named' photos are never shared; city photos are reused only as a last resort."""
    pats = uni["must"] if tier == "named" else [norm(c) for c in [uni["city"], *uni.get("city_aliases", [])]]
    reuse = None
    for p in photos:
        t = text_of(p)
        if any(has(t, r) for r in uni["reject"]) or not any(has(t, x) for x in pats):
            continue
        if p["id"] not in used:
            return p, False
        reuse = reuse or p
    return (reuse, True) if (tier == "city" and reuse) else (None, False)


def find_photo(uni, key, used):
    """Try, in order: the university's name, its city+'university', then the city alone."""
    queries = [uni["name"].split(",")[0]] + uni.get("aliases", [])[:1]
    for q in queries:
        p, _ = pick(search(q, key), uni, "named", used)
        if p:
            return p, "named", q, False
    q2 = f"{uni['city']} university"
    photos = search(q2, key)
    p, _ = pick(photos, uni, "named", used)
    if p:
        return p, "named", q2, False
    p2, reused2 = pick(photos, uni, "city", used)
    if p2 and not reused2:
        return p2, "city", q2, False
    # no fresh photo yet: try the city-only query before settling for a reused one
    q3 = f"{uni['city']} {SEARCH_COUNTRY.get(uni['country'], uni['country'])}"
    p3, reused3 = pick(search(q3, key), uni, "city", used)
    if p3 and not reused3:
        return p3, "city", q3, False
    if p2:
        return p2, "city", q2, True
    if p3:
        return p3, "city", q3, True
    return None, "none", q3, False


# ------------------------------------------------------------------ files
def fetch_image(photo, dest):
    shared = SHARED / f"{photo['id']}.jpg"
    if not shared.exists():
        SHARED.mkdir(parents=True, exist_ok=True)
        src = photo["src"].get("large2x") or photo["src"]["large"]
        req = urllib.request.Request(src, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            shared.write_bytes(r.read())
    shutil.copyfile(shared, dest)


def record(uni, photo, tier, query, reused):
    rec = dict(country=uni["country"], name=uni["name"], slug=uni["slug"], city=uni["city"],
               tier=tier, file=None, query=query, reused=reused)
    if uni.get("city_inferred"):
        rec["city_inferred"] = True
    if photo:
        rec.update(file=f"images/{uni['slug']}.jpg", photo_id=photo["id"], pexels_page=photo["url"],
                   photographer=photo["photographer"], photographer_url=photo["photographer_url"],
                   alt=photo.get("alt", ""), width=photo["width"], height=photo["height"])
    return rec


def save(manifest):
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")


def run(unis, key, manifest):
    used = {m["photo_id"] for m in manifest.values() if m.get("photo_id")}
    OUT.mkdir(exist_ok=True)
    in_run = {u["slug"] for u in unis}
    deferred = []   # duplicate listings of an institution: copied from the original at the end
    for i, uni in enumerate(unis, 1):
        print(f"[{i}/{len(unis)}] {uni['country']}: {uni['name']}")
        dup = uni.get("dup")
        dup_slug = norm(f"{uni['country']} {dup}").replace(" ", "-") if dup else None
        if dup_slug and (dup_slug in manifest or dup_slug in in_run):
            print(f"  -> duplicate listing of '{dup}', will copy its photo")
            deferred.append((uni, dup_slug))
            continue
        photo, tier, q, reused = find_photo(uni, key, used)
        if photo:
            try:
                fetch_image(photo, OUT / f"{uni['slug']}.jpg")
            except Exception as e:
                print(f"  [download failed] {e}")
                photo, tier = None, "none"
        if photo:
            used.add(photo["id"])
            print(f"  -> {tier}{' (reused)' if reused else ''}: {photo['url']}")
        else:
            print("  -> no suitable photo (will get a generic placeholder)")
        manifest[uni["slug"]] = record(uni, photo, tier, q, reused)
        save(manifest)

    # generic placeholders for anything still without a photo
    missing = [m for m in manifest.values() if m["tier"] == "none"]
    if missing:
        photos = search("university campus building", key)
        for n, m in enumerate(missing):
            if not photos:
                break
            fresh = [p for p in photos if p["id"] not in used]
            p = fresh[0] if fresh else photos[n % len(photos)]
            try:
                fetch_image(p, OUT / f"{m['slug']}.jpg")
            except Exception as e:
                print(f"  [download failed] {e}")
                continue
            m.update(tier="generic", reused=p["id"] in used, file=f"images/{m['slug']}.jpg", photo_id=p["id"],
                     pexels_page=p["url"], photographer=p["photographer"],
                     photographer_url=p["photographer_url"], alt=p.get("alt", ""),
                     width=p["width"], height=p["height"], query="university campus building")
            used.add(p["id"])
        save(manifest)

    for uni, dup_slug in deferred:
        src = manifest.get(dup_slug)
        if src and src.get("file"):
            shutil.copyfile(OUT / f"{dup_slug}.jpg", OUT / f"{uni['slug']}.jpg")
            manifest[uni["slug"]] = {**src, "name": uni["name"], "slug": uni["slug"],
                                     "file": f"images/{uni['slug']}.jpg", "note": f"same institution as '{uni['dup']}'"}
        else:
            print(f"  [warning] original '{uni['dup']}' has no photo yet; re-run to retry '{uni['name']}'")
    save(manifest)


def summary(manifest):
    print("\nSUMMARY (tier counts per country)")
    for c in sorted({m["country"] for m in manifest.values()}):
        tiers = [m["tier"] for m in manifest.values() if m["country"] == c]
        print(f"  {c:15}", {t: tiers.count(t) for t in ("named", "city", "generic", "none") if tiers.count(t)})
    print("Only 'named' photos are confirmed to show that university. See manifest.json.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--country", action="append", help="only this country (repeatable), e.g. --country Turkey")
    ap.add_argument("--limit", type=int, help="process at most N universities (for a quick test)")
    args = ap.parse_args()

    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        sys.exit("Set PEXELS_API_KEY first (free key: https://www.pexels.com/api/new/)")
    unis = load_unis()
    manifest = _load_json(MANIFEST, {})
    pending = [u for u in unis
               if (not args.country or u["country"] in args.country)
               and manifest.get(u["slug"], {}).get("tier") in (None, "none")]
    if args.limit:
        pending = pending[: args.limit]
    print(f"{len(unis)} universities in file, {len(pending)} to process this run.")
    run(pending, key, manifest)
    summary(manifest)


if __name__ == "__main__":
    main()