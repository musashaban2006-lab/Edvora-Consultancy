#!/usr/bin/env python3
"""Fetch reusable university and city photos from Wikimedia Commons.

This is the no-key alternative to fetch_university_images.py. It reads the
same universities.json file and resumes from manifest.json. Requests are sent
serially with a descriptive User-Agent; Wikimedia's Retry-After is respected.

Usage:
    python fetch_commons_university_images.py --limit 3
    python fetch_commons_university_images.py

Photos are saved in images/ and copied to the site's public assets. Credits
remain in manifest.json and are also exported for the site as
lib/university-photo-manifest.json.
"""

import argparse
import json
import re
import shutil
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
DATA = HERE / "universities.json"
OUT = HERE / "images"
PUBLIC = PROJECT / "public" / "images" / "universities" / "commons"
MANIFEST = HERE / "manifest.json"
SITE_MANIFEST = PROJECT / "lib" / "university-photo-manifest.json"
API = "https://commons.wikimedia.org/w/api.php"
USER_AGENT = "EdvoraUniversityImageFetcher/1.0 (mailto:edvorainternationalofficial@gmail.com) Python/3"
MIN_REQUEST_GAP = 0.8


class TextOnly(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(value):
    parser = TextOnly()
    parser.feed(value or "")
    return " ".join("".join(parser.parts).split())


def normalize(value):
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    tokens = re.findall(r"[a-z0-9]+", value.lower())
    return " ".join(token for token in tokens if token not in {"the", "of"})


def slug(value):
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", normalize(value))).strip("-")


def record_key(uni):
    return f"{normalize(uni['country'])}::{normalize(uni['name'])}"


def api_get(params):
    url = API + "?" + urllib.parse.urlencode({**params, "format": "json", "formatversion": 2})
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                payload = json.load(response)
            time.sleep(MIN_REQUEST_GAP)
            return payload
        except urllib.error.HTTPError as error:
            if error.code not in (429, 503) or attempt == 3:
                raise
            delay = error.headers.get("Retry-After", "5")
            try:
                time.sleep(max(1, min(int(delay), 300)))
            except ValueError:
                time.sleep(5)
        except (TimeoutError, urllib.error.URLError):
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)


def image_candidates(query):
    payload = api_get({
        "action": "query",
        "generator": "search",
        "gsrsearch": f"filetype:bitmap {query}",
        "gsrnamespace": 6,
        "gsrlimit": 20,
        "prop": "imageinfo",
        "iiprop": "url|extmetadata",
        "iiurlwidth": 1000,
    })
    return payload.get("query", {}).get("pages", [])


def metadata(page):
    infos = page.get("imageinfo") or []
    if not infos:
        return None
    info = infos[0]
    ext = info.get("extmetadata") or {}
    license_name = plain((ext.get("LicenseShortName") or {}).get("value"))
    license_url = plain((ext.get("LicenseUrl") or {}).get("value"))
    if not license_name:
        return None
    artist = plain((ext.get("Artist") or {}).get("value")) or plain((ext.get("Credit") or {}).get("value"))
    if not artist and "public domain" not in license_name.lower() and "cc0" not in license_name.lower():
        return None
    return {
        "title": page.get("title", "").removeprefix("File:"),
        "page_url": info.get("descriptionurl", ""),
        "image_url": info.get("thumburl") or info.get("url", ""),
        "mime": info.get("thumbmime") or info.get("mime", ""),
        "width": info.get("thumbwidth") or info.get("width"),
        "height": info.get("thumbheight") or info.get("height"),
        "description": plain((ext.get("ImageDescription") or {}).get("value")),
        "artist": artist or "Public domain / CC0",
        "license": license_name,
        "license_url": license_url,
        "page_id": page.get("pageid"),
    }


def classification(info, uni, kind):
    haystack = normalize(" ".join((info["title"], info["description"])))
    university = normalize(uni["name"])
    core = normalize(uni.get("core", ""))
    # A university-specific tier requires its identifying name in the file
    # title or description; a matching city by itself is only illustrative.
    if kind == "university" and university and university in haystack:
        return "named"
    if kind == "university" and core and len(core) >= 5 and core in haystack:
        has_institution_context = any(word in haystack for word in ("university", "college", "campus", "faculty", "school"))
        if has_institution_context:
            return "named"
    city = normalize(uni.get("city", ""))
    if kind == "city" and city and city in haystack:
        return "city"
    if kind == "generic" and any(word in haystack for word in ("university", "college", "campus")):
        return "generic"
    return None


def find_photo(uni):
    name = uni["name"]
    city = uni.get("city", "").strip()
    country = uni["country"]
    searches = [(f'"{name}"', "university")]
    if city:
        searches.append((f'"{city}" "{country}"', "city"))
    searches.append(('"university campus"', "generic"))

    for query, kind in searches:
        try:
            pages = image_candidates(query)
        except Exception as error:
            print(f"  [search failed] {error}")
            continue
        for page in pages:
            info = metadata(page)
            if not info or not info["image_url"] or not info["page_url"] or not image_extension(info["mime"]):
                continue
            tier = classification(info, uni, kind)
            if tier:
                return info, tier, query
    return None, "none", ""


def download(url, destination):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        content_type = response.headers.get_content_type()
        if not content_type.startswith("image/"):
            raise ValueError(f"Expected image content, received {content_type}")
        data = response.read()
    if len(data) < 1500:
        raise ValueError("Downloaded image is unexpectedly small")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)


def image_extension(mime):
    return {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}.get((mime or "").lower())


def load_json(path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


def save_outputs(manifest):
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    site_manifest = {}
    for item in manifest.values():
        if not item.get("site_path"):
            continue
        site_manifest[item["key"]] = {
            "image": item["site_path"],
            "tier": item["tier"],
            "alt": item["alt"],
            "artist": item["artist"],
            "pageUrl": item["page_url"],
            "license": item["license"],
            "licenseUrl": item["license_url"],
        }
    SITE_MANIFEST.write_text(json.dumps(site_manifest, indent=2, ensure_ascii=False), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, help="process at most N not-yet-downloaded entries")
    parser.add_argument("--country", action="append", help="only process this country (repeatable)")
    args = parser.parse_args()

    if not DATA.exists():
        sys.exit(f"Missing input file: {DATA}")
    universities = json.loads(DATA.read_text(encoding="utf-8"))
    manifest = load_json(MANIFEST, {})
    pending = [uni for uni in universities
               if (not args.country or uni["country"] in args.country)
               and (manifest.get(slug(f"{uni['country']} {uni['name']}"), {}).get("tier") in (None, "none"))]
    if args.limit:
        pending = pending[:args.limit]
    print(f"{len(universities)} universities in source list; {len(pending)} to process.")

    for index, uni in enumerate(pending, 1):
        key = record_key(uni)
        source_slug = slug(f"{uni['country']} {uni['name']}")
        print(f"[{index}/{len(pending)}] {uni['country']}: {uni['name']}")
        info, tier, query = find_photo(uni)
        item = {
            "slug": source_slug, "key": key, "name": uni["name"], "country": uni["country"],
            "city": uni.get("city", ""), "city_inferred": bool(uni.get("city_inferred")), "tier": tier, "query": query,
            "image": None, "site_path": None, "page_url": "", "artist": "",
            "license": "", "license_url": "", "alt": "University campus placeholder",
        }
        if info:
            item.update({k: info[k] for k in ("title", "page_url", "artist", "license", "license_url", "width", "height", "description", "page_id")})
            item["alt"] = (f"{uni['name']} campus" if tier == "named" else
                           f"{uni.get('city') or uni['country']} city view" if tier == "city" else
                           "University campus placeholder")
            extension = image_extension(info["mime"])
            local_file = OUT / f"{source_slug}{extension}"
            public_file = PUBLIC / f"{source_slug}{extension}"
            try:
                if not local_file.exists():
                    download(info["image_url"], local_file)
                public_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(local_file, public_file)
                item["image"] = f"images/{source_slug}{extension}"
                item["site_path"] = f"/images/universities/commons/{source_slug}{extension}"
                print(f"  -> {tier}: {info['title']} ({info['license']})")
            except Exception as error:
                item["tier"] = "none"
                item["alt"] = "University campus placeholder"
                print(f"  [download failed] {error}")
        else:
            print("  -> no reusable match; site will show its image fallback")
        manifest[source_slug] = item
        save_outputs(manifest)

    print("\nSUMMARY (tier counts per country)")
    countries = sorted({item["country"] for item in manifest.values()})
    for country in countries:
        tiers = [item["tier"] for item in manifest.values() if item["country"] == country]
        print(f"  {country:16} " + json.dumps({tier: tiers.count(tier) for tier in ("named", "city", "generic", "none") if tiers.count(tier)}))
    print(f"Credits: {MANIFEST}")


if __name__ == "__main__":
    main()
