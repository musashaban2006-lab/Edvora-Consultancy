import { ImageResponse } from "next/og";

export const alt = "Edvora — Study abroad guidance for your next chapter";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    <div style={{ width: "100%", height: "100%", display: "flex", position: "relative", overflow: "hidden", background: "linear-gradient(120deg,#092b53 0%,#0b4862 100%)", color: "#fff", fontFamily: "Arial, sans-serif" }}>
      <div style={{ position: "absolute", width: 590, height: 590, borderRadius: "50%", border: "1px solid rgba(137,222,237,.2)", right: 20, top: 18, display: "flex" }} />
      <div style={{ position: "absolute", width: 470, height: 470, borderRadius: "50%", border: "1px dashed rgba(137,222,237,.28)", right: 80, top: 78, display: "flex" }} />
      <div style={{ position: "absolute", width: 300, height: 300, borderRadius: "50%", background: "rgba(18,169,214,.13)", right: 165, top: 165, display: "flex" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 12, background: "#12a9d6", display: "flex" }} />
      <div style={{ width: 690, padding: "82px 0 70px 78px", display: "flex", flexDirection: "column", justifyContent: "center", position: "relative" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 13, color: "#9ee7f1", fontSize: 22, fontWeight: 700, letterSpacing: 4 }}>EDVORA</div>
        <div style={{ marginTop: 15, color: "rgba(255,255,255,.72)", fontSize: 17, letterSpacing: 3 }}>YOUR GLOBAL EDUCATION PARTNER</div>
        <div style={{ display: "flex", flexDirection: "column", marginTop: 44, fontSize: 62, lineHeight: 1.08, fontWeight: 700, letterSpacing: -2 }}>
          <span>Your next chapter</span><span style={{ color: "#82dfec" }}>starts here.</span>
        </div>
        <div style={{ maxWidth: 570, marginTop: 24, color: "rgba(255,255,255,.78)", fontSize: 22, lineHeight: 1.45 }}>Study abroad guidance for students in Pakistan.</div>
      </div>
      <div style={{ position: "absolute", right: 110, top: 145, width: 300, height: 340, borderRadius: 24, background: "linear-gradient(145deg,#176b58,#0a453d)", border: "2px solid rgba(226,211,138,.74)", transform: "rotate(-8deg)", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", boxShadow: "0 30px 70px rgba(0,0,0,.2)" }}>
        <div style={{ width: 210, height: 250, borderRadius: 16, border: "1px solid rgba(226,211,138,.52)", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
          <div style={{ width: 84, height: 84, borderRadius: "50%", border: "3px solid #e2d38a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 47, color: "#e2d38a" }}>✦</div>
          <div style={{ marginTop: 29, fontSize: 24, fontWeight: 700, letterSpacing: 4, color: "#f5df93" }}>EDVORA</div>
          <div style={{ marginTop: 8, fontSize: 12, letterSpacing: 2, color: "#d8e8db" }}>STUDY ABROAD PLAN</div>
        </div>
      </div>
      <div style={{ position: "absolute", right: 132, bottom: 80, width: 146, height: 92, borderRadius: 14, background: "#fff", transform: "rotate(8deg)", display: "flex", alignItems: "center", justifyContent: "center", color: "#0b4778", fontSize: 14, fontWeight: 700, letterSpacing: 1, boxShadow: "0 18px 32px rgba(0,0,0,.2)" }}>ONE STEP AT A TIME</div>
    </div>,
    { ...size },
  );
}
