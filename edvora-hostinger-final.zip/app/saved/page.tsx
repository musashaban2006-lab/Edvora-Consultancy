import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowUpRight } from "lucide-react";
import { CountryCard, UniversityCard } from "@/components/cards";
import { createClient } from "@/lib/supabase/server";
import { getCountries, getUniversities } from "@/lib/content";
import { AccountActions } from "@/components/account-actions";
export const metadata: Metadata = { title: "Your saved items", robots: { index: false, follow: false } };
export default async function SavedPage() {
  const supabase = await createClient(); if (!supabase) return <section className="account-page shell"><span className="eyebrow">STUDENT SPACE</span><h1>Keep the possibilities <em>close.</em></h1><p>Connect Supabase to sign in and save universities and destinations.</p><Link href="/login" className="button button-dark">Sign in <ArrowUpRight size={16}/></Link></section>;
  const { data: { user } } = await supabase.auth.getUser(); if (!user) redirect("/login?next=/saved");
  const [{ data: profile }, { data: savedUniversities }, { data: savedCountries }, allUniversities, allCountries] = await Promise.all([
    supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle(),
    supabase.from("saved_universities").select("university_id").eq("profile_id", user.id),
    supabase.from("saved_countries").select("country_id").eq("profile_id", user.id),
    getUniversities(), getCountries(),
  ]);
  const universityIds = new Set((savedUniversities ?? []).map((item) => item.university_id));
  const countryIds = new Set((savedCountries ?? []).map((item) => item.country_id));
  const universities = allUniversities.filter((item) => universityIds.has(item.id));
  const countries = allCountries.filter((item) => countryIds.has(item.id));
  return <section className="account-page shell"><div className="account-page-head"><div><span className="eyebrow">YOUR EDVORA SPACE</span><h1>{profile?.display_name ? `Hello, ${profile.display_name.split(" ")[0]}.` : "Your saved items."}</h1><p>Keep universities and destinations you’re considering in one place.</p></div><AccountActions/></div>
    <div className="saved-section"><div className="section-heading"><div><span className="eyebrow">DESTINATIONS</span><h2>Your places to explore</h2></div><Link href="/countries" className="text-arrow">Explore destinations <ArrowUpRight size={15}/></Link></div>{countries.length ? <div className="country-grid">{countries.map((item, index) => <CountryCard key={item.id} country={item} index={index} saved/>)}</div> : <p className="empty-state">No saved destinations yet. <Link href="/countries">Explore destinations</Link> and tap the bookmark.</p>}</div>
    <div className="saved-section"><div className="section-heading"><div><span className="eyebrow">UNIVERSITIES</span><h2>Your shortlist</h2></div><Link href="/countries" className="text-arrow">Explore destinations <ArrowUpRight size={15}/></Link></div>{universities.length ? <div className="university-grid">{universities.map((item) => <UniversityCard key={item.id} university={item} saved/>)}</div> : <p className="empty-state">No saved universities yet. <Link href="/countries">Explore destinations</Link> and browse university profiles.</p>}</div>
  </section>;
}
