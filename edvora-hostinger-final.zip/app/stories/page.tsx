import type { Metadata } from "next";
import Image from "next/image";
import { CountryIntro } from "@/components/page-intro";
import { pageMetadata } from "@/lib/seo";
export const metadata: Metadata = pageMetadata("Student Study Abroad Stories", "See visa milestones shared with Edvora and explore the steps students take as they plan to study abroad.", "/stories");
const visaApprovals = [
  { name: "Muhammad Umair Butt", image: "/images/stories/visa-muhammad-umair-butt.jpg" },
  { name: "Abdul Khaliq", image: "/images/stories/visa-abdul-khaliq.jpg" },
  { name: "Javed Malik Babur", image: "/images/stories/visa-javed-malik-babur.jpg" },
];
export default function StoriesPage() {
  return <><CountryIntro kicker="STUDENT TESTIMONIALS" title={<>Every journey<br/>has a <em>moment.</em></>} text="Offers, visas, and the courage to begin. Celebrate every step toward a new chapter." decoration={false}/><section className="listing-section shell"><div className="stories-feature"><div className="stories-feature-copy"><span className="eyebrow eyebrow-light">A MOMENT WORTH CELEBRATING</span><h2>Every milestone<br/>moves a dream <em>forward.</em></h2><p>Every journey begins with a plan. Keep moving, one thoughtful step at a time.</p><ul><li>Make a plan that fits your goals</li><li>Prepare documents and applications</li><li>Celebrate progress along the way</li></ul></div><div className="stories-feature-image"><Image src="/images/shared/passport-europe.jpg" alt="A passport opened to a miniature European travel scene" fill sizes="(max-width: 760px) 100vw, 55vw"/></div></div><div className="visa-success-intro"><span className="eyebrow">VISA APPROVALS</span><h2>Real milestones.<br/><em>Personal details protected.</em></h2><p>Visa details are blurred for privacy. Student names and approval status are shown with a Schengen area marker.</p></div><div className="visa-proof-grid">{visaApprovals.map(({ name, image }) => <article className="visa-proof-card" key={name}><div className="visa-proof-image"><Image src={image} alt="Visa document with personal information obscured" fill sizes="(max-width: 760px) 90vw, 33vw"/><span className="visa-area-badge" aria-label="Schengen area visa">★ SCHENGEN</span></div><div className="visa-proof-caption"><span className="visa-proof-check" aria-hidden="true">✓</span><span><strong>{name}</strong><small>Visa approved</small></span><span className="visa-name-badge">Schengen</span></div></article>)}</div></section></>;
}
