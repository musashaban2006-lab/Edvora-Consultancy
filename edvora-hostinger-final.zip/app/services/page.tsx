import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Compass, FileCheck2, Globe2 } from "lucide-react";
import { CountryIntro } from "@/components/page-intro";
import { StudyVisualFeature } from "@/components/study-visual-feature";
import { getServices } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";
export const metadata: Metadata = pageMetadata("Study Abroad Support and Guidance", "Explore Edvora's study abroad guidance for Pakistani students, including destination planning, applications, English test preparation, and visa preparation.", "/services");
const icons = [Compass, FileCheck2, Globe2];
export default async function ServicesPage() {
  const services = await getServices();
  return <><CountryIntro kicker="GOOD GUIDANCE, RIGHT WHEN YOU NEED IT" title={<>Thoughtful support<br/>for <em>what’s next.</em></>} text="We help make a big journey feel more manageable—with honest conversations and guidance shaped around your goals."/><StudyVisualFeature/><section className="service-page-section"><div className="shell"><div className="section-heading"><div><span className="eyebrow">SUPPORT THAT MOVES WITH YOU</span><h2>One step at a time.</h2></div><p className="section-side-note">Your plans are personal. Our support should be, too.</p></div><div className="service-grid">{services.map((service, i) => { const Icon = icons[i]; return <article className="service-card service-card-large" key={service.title}><span className="service-card-icon"><Icon size={23}/></span><span className="service-card-number">0{i + 1}</span><h3>{service.title}</h3><p>{service.text}</p><Link href="/contact" className="service-card-link">Talk with us <ArrowUpRight size={16}/></Link></article>; })}</div></div></section><section className="service-promise"><div className="shell service-promise-inner"><span className="eyebrow eyebrow-light">A NOTE ON OUR ROLE</span><h2>We’ll help you prepare.<br/><em>You stay in the driver’s seat.</em></h2><p>We provide guidance and support. Universities make admissions decisions, and immigration authorities make visa decisions. We’ll help you understand the process without promising a particular outcome.</p><Link className="button button-orange" href="/contact">Start with a conversation <ArrowUpRight size={16}/></Link></div></section></>;
}
