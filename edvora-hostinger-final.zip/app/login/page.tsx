import type { Metadata } from "next";
import { AuthForm } from "@/components/auth-form";
export const metadata: Metadata = { title: "Sign in", robots: { index: false, follow: true } };
export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) { const { next } = await searchParams; return <section className="auth-page"><div className="auth-side-photo"><span>Keep the<br/><em>possibilities</em><br/>close.</span></div><AuthForm mode="login" next={next}/></section>; }
