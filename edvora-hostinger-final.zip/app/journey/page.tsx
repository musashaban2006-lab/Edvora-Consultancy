import type { Metadata } from "next";
import { JourneyPlanner } from "@/components/journey-planner";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata(
  "Study Abroad Journey Planner",
  "Build a practical study abroad checklist, compare destination budget guidance, and keep track of your next steps.",
  "/journey",
);

export default function JourneyPage() {
  return <JourneyPlanner />;
}
