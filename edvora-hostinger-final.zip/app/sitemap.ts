import type { MetadataRoute } from "next";
import { getCountries, getUniversities } from "@/lib/content";
import { languageTests } from "@/lib/language-tests";

const siteOrigin = process.env.NEXT_PUBLIC_SITE_URL?.startsWith("https://")
  ? process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, "")
  : process.env.VERCEL_URL
    ? `https://${process.env.VERCEL_URL}`
      : process.env.NODE_ENV === "development"
      ? "http://localhost:3002"
      : undefined;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  if (!siteOrigin) return [];
  const [countries, universities] = await Promise.all([getCountries(), getUniversities()]);
  const pages: MetadataRoute.Sitemap = [
    { url: `${siteOrigin}/`, changeFrequency: "weekly", priority: 1 },
    { url: `${siteOrigin}/countries`, changeFrequency: "weekly", priority: 0.9 },
    { url: `${siteOrigin}/services`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${siteOrigin}/budget`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${siteOrigin}/journey`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${siteOrigin}/courses`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${siteOrigin}/about`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${siteOrigin}/stories`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${siteOrigin}/privacy`, changeFrequency: "yearly", priority: 0.2 },
    { url: `${siteOrigin}/contact`, changeFrequency: "monthly", priority: 0.6 },
    ...countries.map((country) => ({ url: `${siteOrigin}/countries/${country.slug}`, changeFrequency: "monthly" as const, priority: 0.8 })),
    ...universities.map((university) => ({ url: `${siteOrigin}/universities/${university.slug ?? university.id}`, changeFrequency: "monthly" as const, priority: 0.6 })),
    ...languageTests.map((test) => ({ url: `${siteOrigin}/courses/${test.slug}`, changeFrequency: "monthly" as const, priority: 0.6 })),
  ];
  return pages;
}
