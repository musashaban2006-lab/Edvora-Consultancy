import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { CountryIntro } from "@/components/page-intro";
import { languageTests, getLanguageTest } from "@/lib/language-tests";

export async function generateStaticParams() {
  return languageTests.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const test = getLanguageTest(slug);
  return test ? {
    title: `${test.name} Format, Sections and Scoring Guide`,
    description: `${test.summary} Learn about ${test.name} sections, format and scoring, then confirm current requirements with your university.`,
    alternates: { canonical: `/courses/${test.slug}` },
    openGraph: { title: `${test.name} guide | Edvora`, description: test.summary, url: `/courses/${test.slug}`, images: [{ url: test.logo, alt: `${test.name} logo` }] },
    twitter: { card: "summary_large_image", title: `${test.name} guide | Edvora`, description: test.summary, images: [test.logo] },
  } : { title: "Language test guide", robots: { index: false, follow: true } };
}

export default async function LanguageTestPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const test = getLanguageTest(slug);
  if (!test) notFound();

  return <>
    <CountryIntro kicker="LANGUAGE TEST GUIDE" title={<>{test.name}<br/><em>understood.</em></>} text={test.summary} image="/images/countries/cities/helsinki.jpg" imageAlt="Historic university district in Helsinki"/>
    <section className="language-test-overview shell">
      <div className="language-test-brand"><Image src={test.logo} alt={`${test.name} logo`} width={210} height={100} sizes="210px"/><span className="eyebrow">OFFICIAL FORMAT GUIDE</span><h2>Know what to expect.</h2><p>{test.format}</p><a className="text-arrow" href={test.officialUrl} target="_blank" rel="noreferrer">{test.officialLabel}<ArrowUpRight size={16}/></a></div>
      <aside className="language-test-score"><span className="eyebrow">SCORING</span><h3>How results are reported</h3><p>{test.scoring}</p><small>Score requirements vary by institution and programme. Check the latest requirement with your chosen university before booking.</small></aside>
    </section>
    <section className="language-test-sections"><div className="shell"><span className="eyebrow">TEST COMPONENTS</span><h2>Build confidence in <em>each skill.</em></h2><div className="language-test-grid">{test.sections.map((section, index) => <article key={section.title}><span>0{index + 1}</span><h3>{section.title}</h3><p>{section.description}</p></article>)}</div><p className="language-test-note">Test formats and score reporting can change. The test provider’s official page is the final source for current details.</p></div></section>
    <section className="shell language-test-cta"><div><span className="eyebrow">PREPARING FOR {test.name.toUpperCase()}</span><h2>Plan your next step.</h2><p>Ask Edvora about current preparation options and how to choose a test that meets your university’s requirements.</p></div><div><Link className="button button-dark" href="/contact">Ask about preparation <ArrowUpRight size={16}/></Link><Link className="text-arrow" href="/courses"><ArrowLeft size={15}/> All language tests</Link></div></section>
  </>;
}
