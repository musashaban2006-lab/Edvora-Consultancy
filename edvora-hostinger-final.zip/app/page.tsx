import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Compass, FileCheck2, Globe2, Plane, Sparkles } from "lucide-react";
import { getUniversities } from "@/lib/content";
import { UniversityMarquee } from "@/components/university-marquee";
import { StudentBudgetCalculator } from "@/components/student-budget-calculator";
import { HeroVideoBackground } from "@/components/hero-video-background";
import { IntroPhotoFlow } from "@/components/intro-photo-flow";
import { HomePassportFeature } from "@/components/home-passport-feature";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Study Abroad Guidance for Pakistani Students", "Explore study destinations, compare university options, plan your budget, and get personal study abroad guidance with Edvora.", "/");

const journey = [
  { title: "Discover", text: "Explore destinations, universities, and courses that fit your goals.", icon: Compass },
  { title: "Plan", text: "Build a clear plan around your study level, timeline, and budget.", icon: Sparkles },
  { title: "Apply", text: "Get thoughtful support as you prepare and submit applications.", icon: FileCheck2 },
  { title: "Arrive", text: "Get ready for your next chapter abroad with confidence.", icon: Globe2 },
];

export default async function HomePage() {
  const universities = await getUniversities();
  return (
    <>
      <section className="hero-section home-hero">
        <HeroVideoBackground />
        <div className="hero-content shell">
          <div className="hero-copy">
            <span className="hero-kicker">
              <span className="kicker-line" /> STUDY ABROAD, WITH A PLAN
            </span>
            <h1>
              Your next chapter
              <br />
              <em>starts here.</em>
            </h1>
            <p>
              Edvora helps students in Pakistan find the right study destination, choose a university, and plan the steps to get there.
            </p>
            <div className="hero-actions">
              <Link className="button button-orange" href="/contact">
                Book a free consultation <ArrowUpRight size={17} />
              </Link>
              <Link className="hero-secondary" href="/countries">
                Explore destinations <ArrowRight size={15} />
              </Link>
            </div>
            <div className="hero-proof">
              <div className="proof-avatars">
                <span>E</span>
                <span>D</span>
                <span>✦</span>
              </div>
              <span>
                <b>Personal guidance for every step</b>
                <br />
                Discover through arrival
              </span>
            </div>
          </div>
        </div>
      </section>

      <HomePassportFeature />

      <section className="home-journey section shell" aria-labelledby="journey-heading">
        <div className="journey-intro">
          <span className="eyebrow">YOUR STUDY ABROAD JOURNEY</span>
          <h2 id="journey-heading">
            Four steps. One <em>clear plan.</em>
          </h2>
          <p>We make a big decision feel more manageable—with support shaped around you.</p>
        </div>
        <div className="journey-steps">
          {journey.map(({ title, text, icon: Icon }, index) => (
            <article className="journey-step" key={title}>
              <div className="journey-step-top">
                <span className="journey-step-icon">
                  <Icon size={21} />
                </span>
                <span className="journey-step-number">0{index + 1}</span>
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
              {index < journey.length - 1 && (
                <span className="journey-flight" aria-hidden="true">
                  <Plane size={18} />
                </span>
              )}
            </article>
          ))}
        </div>
      </section>

      {/* Floating Animated 3-Row University Marquee with Logos */}
      <UniversityMarquee universities={universities} />

      {/* Student Budget & Paid Expenses Guide */}
      <StudentBudgetCalculator />

      <section className="home-offer shell">
        <div className="home-offer-copy">
          <span className="eyebrow">HOW EDVORA HELPS</span>
          <h2>
            Good guidance makes the next step <em>feel possible.</em>
          </h2>
          <p>
            From finding your fit to understanding applications, visa preparation, and arrival, we help you move forward with clear, personal support.
          </p>
          <Link className="text-arrow" href="/services">
            Explore our support <ArrowRight size={16} />
          </Link>
        </div>
        <div className="home-offer-photo">
          <IntroPhotoFlow
            className="home-country-flow"
            label="Sliding destination photos from the United Kingdom, Sweden, Turkey, South Cyprus, Romania, Germany, and Italy"
            flow="right-to-left"
            photos={[
              { src: "/images/countries/cities/london.jpg", alt: "London, United Kingdom" },
              { src: "/images/countries/cities/stockholm.jpg", alt: "Stockholm, Sweden" },
              { src: "/images/countries/cities/istanbul-hagia-sophia.jpg", alt: "Istanbul, Turkey" },
              { src: "/images/countries/cities/paphos-coast.jpg", alt: "South Cyprus coastline" },
              { src: "/images/countries/romania.jpg", alt: "Bucharest, Romania" },
              { src: "/images/countries/cities/berlin.jpg", alt: "Berlin, Germany" },
              { src: "/images/countries/cities/venice.jpg", alt: "Venice, Italy" },
            ]}
          />
        </div>
      </section>

      <section className="home-consult">
        <div className="shell home-consult-inner">
          <div>
            <span className="eyebrow eyebrow-light">START WITH A CONVERSATION</span>
            <h2>
              Tell us what you’re
              <br />
              <em>working toward.</em>
            </h2>
            <p>Share your study level, budget, and destination. An Edvora advisor will follow up.</p>
          </div>
          <Link className="button button-orange" href="/contact">
            Let’s plan your journey <ArrowUpRight size={17} />
          </Link>
        </div>
      </section>
    </>
  );
}
