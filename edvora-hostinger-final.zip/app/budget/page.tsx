import type { Metadata } from "next";
import { StudentBudgetCalculator } from "@/components/student-budget-calculator";
import { CountryIntro } from "@/components/page-intro";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata("Study Abroad Costs and Student Budget Guide", "Explore tuition, living expenses, visa fees, and other costs to consider when planning to study abroad from Pakistan.", "/budget");

export default function BudgetPage() {
  return (
    <>
      <CountryIntro
        kicker="TRANSPARENT FINANCIAL PLANNING"
        title={
          <>
            Know what it costs.
            <br />
            <em>Plan your budget with clarity.</em>
          </>
        }
        text="A clear, realistic guide to university tuition fees, monthly living costs, mandatory embassy fees, and bank statement proofs for Pakistani students."
        image="/images/countries/cities/frankfurt.jpg"
        imageAlt="Frankfurt city buildings beside the river"
      />
      <StudentBudgetCalculator />
    </>
  );
}
