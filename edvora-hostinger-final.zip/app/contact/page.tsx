import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, MessageCircle, Phone } from "lucide-react";
import { ConsultationForm } from "@/components/consultation-form";
import { edvoraContact } from "@/lib/site-config";
import { getUniversities } from "@/lib/content";
import { StudyIllustration } from "@/components/study-illustration";
import { pageMetadata } from "@/lib/seo";

export const metadata: Metadata = pageMetadata("Book a Study Abroad Consultation", "Contact Edvora to discuss study destinations, university options, English test preparation, and your study abroad plans from Pakistan.", "/contact");

export default async function ContactPage() {
  const universities = await getUniversities();
  const phone = process.env.EDVORA_PHONE || edvoraContact.phoneInternational;
  const wa = process.env.EDVORA_WHATSAPP || `+${edvoraContact.whatsapp}`;

  return (
    <section className="contact-page">
      <div className="shell contact-layout">
        <div className="contact-copy">
          <span className="eyebrow">START WITH A CONVERSATION</span>
          <h1>
            Tell us where
            <br />
            you’d like to <em>go.</em>
          </h1>
          <p>
            Share a little about what you’re looking for. An Edvora advisor will follow up and help you figure out the next step.
          </p>

          <div className="contact-options">
            <a href={`tel:${phone.replace(/\s/g, "")}`}>
              <span className="contact-option-icon">
                <Phone size={17} />
              </span>
              <span>
                <small>Call us</small>
                <strong>{phone}</strong>
              </span>
              <ArrowUpRight size={16} />
            </a>

            <a
              href={`https://wa.me/${wa.replace(/\D/g, "")}?text=Hello%20Edvora,%20I'd%20like%20to%20consult%20about%20studying%20abroad.`}
              target="_blank"
              rel="noreferrer"
            >
              <span className="contact-option-icon">
                <MessageCircle size={17} />
              </span>
              <span>
                <small>WhatsApp</small>
                <strong>Chat directly with an Advisor</strong>
              </span>
              <ArrowUpRight size={16} />
            </a>

            <div>
              <span className="contact-option-icon">
                <span className="tiny-dot" />
              </span>
              <span>
                <small>Prefer email?</small>
                <strong><a href={`mailto:${edvoraContact.email}`}>{edvoraContact.email}</a></strong>
              </span>
            </div>
          </div>

          <p className="contact-privacy">
            We’ll use your details to respond to your enquiry. Read our <Link href="/privacy">privacy notice</Link>.
          </p>
        </div>

        <div className="contact-form-card">
          <div className="form-card-heading">
            <StudyIllustration className="contact-illustration" />
            <span className="eyebrow">YOUR FIRST STEP</span>
            <h2>Let’s make a plan.</h2>
            <p>Fields marked with * are required.</p>
          </div>
          <ConsultationForm universities={universities.map(({ slug, id, name, countrySlug, city }) => ({ slug: slug ?? id, name, countrySlug, city }))} uploadsEnabled={Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY)} />
        </div>
      </div>
    </section>
  );
}
