import type { Metadata } from "next";
import "./globals.css";
import "./directory.css";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { ScrollReveal } from "@/components/scroll-reveal";
import { edvoraContact } from "@/lib/site-config";

const deploymentUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined;
const configuredUrl = process.env.NEXT_PUBLIC_SITE_URL?.startsWith("https://")
  ? process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, "")
  : undefined;
const publicSiteUrl = configuredUrl ?? deploymentUrl;

export const metadata: Metadata = {
  metadataBase: publicSiteUrl ? new URL(publicSiteUrl) : undefined,
  title: { default: "Study Abroad Guidance for Pakistani Students | Edvora", template: "%s | Edvora" },
  description: "Explore study destinations, compare university options and plan your study abroad journey with personal guidance for students in Pakistan.",
  applicationName: "Edvora",
  category: "education",
  openGraph: {
    type: "website",
    locale: "en_PK",
    siteName: "Edvora",
    title: "Study Abroad Guidance for Pakistani Students | Edvora",
    description: "Explore study destinations, compare university options and plan your study abroad journey with personal guidance for students in Pakistan.",
    url: "/",
    images: [{ url: "/opengraph-image", width: 1200, height: 630, alt: "Edvora — Study abroad guidance for your next chapter" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Study Abroad Guidance for Pakistani Students | Edvora",
    description: "Explore study destinations, compare university options and plan your study abroad journey with personal guidance for students in Pakistan.",
    images: ["/opengraph-image"],
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1, "max-video-preview": -1 } },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Edvora",
          description: "Study abroad guidance for students in Pakistan.",
          ...(publicSiteUrl ? { url: publicSiteUrl, logo: `${publicSiteUrl}/edvora-logo-exact.jpeg` } : {}),
          email: edvoraContact.email,
          telephone: edvoraContact.phoneInternational,
          slogan: edvoraContact.tagline,
        }).replace(/</g, "\\u003c") }} />
        <SiteHeader />
        <main>{children}</main>
        <ScrollReveal />
        <SiteFooter />
        <WhatsAppButton />
      </body>
    </html>
  );
}
