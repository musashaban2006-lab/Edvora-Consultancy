import type { Metadata } from "next";
import { PasswordResetForm } from "@/components/password-reset-form";
export const metadata: Metadata = { title: "Reset password", robots: { index: false, follow: true } };
export default function ResetPasswordPage() { return <section className="auth-page"><div className="auth-side-photo"><span>A new start<br/><em>is one step</em><br/>away.</span></div><div className="auth-card"><span className="eyebrow">ACCOUNT SECURITY</span><h1>Choose a new<br/><em>password.</em></h1><p>Use at least eight characters.</p><PasswordResetForm/></div></section>; }
