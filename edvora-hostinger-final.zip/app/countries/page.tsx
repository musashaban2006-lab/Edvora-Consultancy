import type { Metadata } from "next";
import { CountryCard } from "@/components/cards";
import { getCountries, getSavedItemIds } from "@/lib/content";
import { CountryIntro } from "@/components/page-intro";
import { pageMetadata } from "@/lib/seo";
export const metadata: Metadata = pageMetadata("Study Destinations for Pakistani Students", "Explore Edvora study destinations, compare countries and city-based university listings, and find a place that fits your plans.", "/countries");

export default async function CountriesPage() {
  const [countries, savedIds] = await Promise.all([getCountries(), getSavedItemIds("country")]);
  const destinationPhotos = [{ src: "/images/shared/world-landmarks-globe-original.svg", alt: "Original illustration of a blue-green globe with global landmarks and airplanes" }];
  return <><CountryIntro kicker="OUR STUDY DESTINATIONS" title={<>A world of<br/><em>possibility.</em></>} text="Every destination has its own rhythm, opportunities, and way of life. Find the place that feels like a fit for you." photoFlow={{ photos: destinationPhotos, label: "A globe surrounded by landmarks and airplanes", flow: "right-to-left", theme: "destinations" }}/><section className="listing-section"><div className="shell destination-all"><span className="eyebrow">FIND YOUR DESTINATION</span><h2>Explore all the <em>possibilities.</em></h2><div className="country-grid">{countries.map((country, i) => <CountryCard country={country} index={i} saved={savedIds.includes(country.id)} key={country.slug}/>)}</div><p className="content-note">Destination details are a starting point. Course availability, entry requirements, and visa rules can change—confirm current information with the relevant institution and authorities.</p></div></section></>;
}
