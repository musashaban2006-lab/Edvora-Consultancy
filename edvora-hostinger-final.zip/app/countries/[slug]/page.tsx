import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, Check } from "lucide-react";
import { CountryCitySection } from "@/components/country-city-section";
import { countryCities } from "@/lib/country-cities";
import { getCountries, getCountry, getServices, getUniversities } from "@/lib/content";

export async function generateStaticParams() { return (await getCountries()).map((country) => ({ slug: country.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const country = await getCountry(slug);
  if (!country) return { title: "Study destination", robots: { index: false, follow: true } };
  return {
    title: `Study in ${country.name} | Universities and guidance`,
    description: `Explore universities and study options in ${country.name}. Review city listings and plan your next step with Edvora study abroad guidance.`,
    alternates: { canonical: `/countries/${country.slug}` },
    openGraph: { title: `Study in ${country.name} | Edvora`, description: country.tagline, url: `/countries/${country.slug}`, images: [{ url: country.image, alt: `${country.name} destination` }] },
    twitter: { card: "summary_large_image", title: `Study in ${country.name} | Edvora`, description: country.tagline, images: [country.image] },
  };
}
export default async function CountryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const country = await getCountry(slug); if (!country) notFound();
  const [universities, services] = await Promise.all([getUniversities(slug), getServices(slug)]);
  const knownCities = countryCities[slug] ?? [];
  const cities = [...knownCities];
  const knownNames = new Set(knownCities.map((city) => city.name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase()));
  for (const university of universities) {
    const cityName = university.city.trim();
    if (!cityName || cityName.toLowerCase() === "türkiye" || cityName.toLowerCase() === "turkiye") continue;
    const normalized = cityName.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    if (knownNames.has(normalized)) continue;
    knownNames.add(normalized);
    cities.push({ name: cityName, image: country.image, description: `Explore university directory listings located in ${cityName}.` });
  }
  return <>
    <section className="detail-hero"><Image src={country.image} alt={`${country.name} destination`} fill priority sizes="100vw" className="cover-image"/><div className="detail-hero-shade"/><div className="shell detail-hero-content"><span className="eyebrow eyebrow-light">STUDY IN {country.region.toUpperCase()}</span><h1>Your next chapter<br/><em>in {country.name}.</em></h1><p>{country.tagline} Explore the study options and get personal guidance for your next step.</p><Link className="button button-orange" href="/contact">Talk with an advisor <ArrowUpRight size={16}/></Link></div><span className="detail-country-index">EDVORA / DESTINATIONS / {country.slug.toUpperCase()}</span></section>
    <section className="section shell detail-overview"><div><span className="eyebrow">A PLACE TO MAKE YOUR OWN</span><h2>Study, grow,<br/><em>see what’s possible.</em></h2></div><div className="overview-copy"><p>{country.name} offers its own mix of university experiences, campus communities, and life beyond the classroom. The right fit depends on what you want to study, your goals, and what matters to you day to day.</p><p>Use this page to start exploring. Edvora can help you compare options and understand what to ask next.</p><Link href="/contact" className="text-arrow">Talk through your plans <ArrowUpRight size={16}/></Link></div></section>
    <CountryCitySection cities={cities} universities={universities}/>
    <section className="section service-rail"><div className="shell"><div className="section-heading"><div><span className="eyebrow">HOW EDVORA CAN HELP</span><h2>Guidance for your journey.</h2></div><Link href="/services" className="text-arrow">Our services <ArrowUpRight size={16}/></Link></div><div className="service-grid">{services.map((service, i) => <article key={service.title} className="service-card"><span className="service-card-number">0{i + 1}</span><h3>{service.title}</h3><p>{service.text}</p><Link href="/contact" aria-label={`Ask us about ${service.title}`}><ArrowUpRight size={17}/></Link></article>)}</div></div></section>
    <section className="shell country-cta"><span className="eyebrow">READY WHEN YOU ARE</span><h2>Let’s explore {country.name} together.</h2><Link className="button button-dark" href="/contact">Request a consultation <ArrowUpRight size={16}/></Link></section>
  </>;
}
