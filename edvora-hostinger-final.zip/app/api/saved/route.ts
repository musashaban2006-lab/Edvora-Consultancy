import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function POST(request: Request) {
  const supabase = await createClient(); if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user } } = await supabase.auth.getUser(); if (!user) return NextResponse.json({ error: "Please sign in to save items." }, { status: 401 });
  const body = await request.json(); const { kind, id, action } = body as { kind?: string; id?: string; action?: string };
  if (!id || !["university", "country"].includes(kind ?? "") || !["save", "remove"].includes(action ?? "")) return NextResponse.json({ error: "Invalid saved item." }, { status: 400 });
  const table = kind === "country" ? "countries" : "universities"; const savedTable = kind === "country" ? "saved_countries" : "saved_universities"; const key = kind === "country" ? "country_id" : "university_id";
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
  const { data: item } = await supabase.from(table).select("id").eq(uuid ? "id" : "slug", id).eq("is_published", true).maybeSingle();
  if (!item) return NextResponse.json({ error: "This item is no longer available." }, { status: 404 });
  if (action === "save") { const { error } = await supabase.from(savedTable).upsert({ profile_id: user.id, [key]: item.id }, { onConflict: `profile_id,${key}` }); if (error) return NextResponse.json({ error: error.message }, { status: 400 }); }
  else { const { error } = await supabase.from(savedTable).delete().eq("profile_id", user.id).eq(key, item.id); if (error) return NextResponse.json({ error: error.message }, { status: 400 }); }
  return NextResponse.json({ ok: true, saved: action === "save" });
}
