import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient(); if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user } } = await supabase.auth.getUser(); if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle(); if (profile?.role !== "staff") return NextResponse.json({ error: "Staff access required." }, { status: 403 });
  const body = await request.json().catch(() => null) as { status?: string; staff_notes?: string } | null;
  if (!body || !["new", "contacted", "closed"].includes(body.status ?? "") || (body.staff_notes?.length ?? 0) > 3000) return NextResponse.json({ error: "Invalid enquiry update." }, { status: 400 });
  const { id } = await params;
  const { error } = await supabase.from("consultation_requests").update({ status: body.status, staff_notes: body.staff_notes?.trim() || null, updated_at: new Date().toISOString() }).eq("id", id);
  if (error) return NextResponse.json({ error: "Unable to update this enquiry." }, { status: 500 });
  return NextResponse.json({ ok: true });
}
