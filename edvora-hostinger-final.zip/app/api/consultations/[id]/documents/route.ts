import { NextResponse } from "next/server";
import { createClient as createAdminClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const authClient = supabase.auth as unknown as { getUser: () => Promise<{ data: { user: { id: string } | null } }> };
  const { data: { user } } = await authClient.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "staff") return NextResponse.json({ error: "Staff access only." }, { status: 403 });
  const { id } = await params;
  const admin = process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
    ? createAdminClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } }) : null;
  if (!admin) return NextResponse.json({ error: "Private storage is not configured." }, { status: 503 });
  const { data: rows, error } = await admin.from("consultation_documents").select("id,storage_path,original_filename,content_type,size_bytes,expires_at").eq("consultation_id", id).gt("expires_at", new Date().toISOString()) as { data: { id: string; storage_path: string; original_filename: string; content_type: string; size_bytes: number; expires_at: string }[] | null; error: unknown };
  if (error) return NextResponse.json({ error: "Documents could not be loaded." }, { status: 500 });
  const documents = await Promise.all((rows ?? []).map(async (row) => {
    const { data } = await admin.storage.from("consultation-documents").createSignedUrl(row.storage_path, 60 * 60, { download: row.original_filename });
    return { id: row.id, filename: row.original_filename, content_type: row.content_type, size_bytes: row.size_bytes, expires_at: row.expires_at, url: data?.signedUrl ?? null };
  }));
  return NextResponse.json({ documents });
}
