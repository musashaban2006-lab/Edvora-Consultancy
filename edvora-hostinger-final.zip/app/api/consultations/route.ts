import { NextResponse } from "next/server";
import { createClient as createAdminClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import fs from "fs";
import path from "path";
import { edvoraEmail } from "@/lib/email-templates";

export const runtime = "nodejs";
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const bucket = "consultation-documents";
const maxFile = 10 * 1024 * 1024;
const maxTotal = 20 * 1024 * 1024;
const allowed = new Set(["application/pdf", "image/jpeg", "image/png"]);

function adminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return url && key ? createAdminClient(url, key, { auth: { persistSession: false } }) : null;
}

async function notifyN8n(payload: Record<string, unknown>): Promise<"sent" | "not_configured" | "failed"> {
  const webhookUrl = process.env.N8N_CONSULTATION_WEBHOOK_URL;
  if (!webhookUrl) return "not_configured";
  try {
    const response = await fetch(webhookUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: AbortSignal.timeout(5000), cache: "no-store" });
    if (!response.ok) {
      console.error("Consultation webhook returned a non-success status.", response.status);
      return "failed";
    }
    return "sent";
  } catch {
    console.error("Consultation webhook notification failed.");
    return "failed";
  }
}

export async function POST(request: Request) {
  const form = await request.formData().catch(() => null);
  if (!form) return NextResponse.json({ error: "Please submit the consultation form again." }, { status: 400 });
  const name = String(form.get("name") ?? "").trim();
  const email = String(form.get("email") ?? "").trim().toLowerCase();
  const phone = String(form.get("phone") ?? "").trim();
  const budget = String(form.get("budget") ?? "").trim();
  const countrySlug = String(form.get("country_slug") ?? "");
  const studyLevel = String(form.get("study_level") ?? "");
  const consultationMode = String(form.get("consultation_mode") ?? "");
  const universityInterest = String(form.get("university_interest") ?? "").trim();
  const consent = form.get("consent") === "on" || form.get("consent") === "true";
  const files = form.getAll("documents").filter((item): item is File => item instanceof File && item.size > 0);
  const totalBytes = files.reduce((sum, file) => sum + file.size, 0);
  if (name.length < 2 || name.length > 120 || !emailPattern.test(email) || phone.length < 7 || phone.length > 40 || !budget || budget.length > 80 || !studyLevel || !countrySlug || !["online", "in_person", "no_preference"].includes(consultationMode) || !consent) {
    return NextResponse.json({ error: "Please complete each required field and consent to being contacted." }, { status: 400 });
  }
  if (files.length > 6 || totalBytes > maxTotal || files.some((file) => file.size > maxFile || !allowed.has(file.type))) {
    return NextResponse.json({ error: "Use up to 6 PDF, JPG or PNG files (10 MB each, 20 MB total)." }, { status: 400 });
  }
  const admin = adminClient();
  const supabase = await createClient();
  if (files.length && (!admin || !supabase)) return NextResponse.json({ error: "Private document uploads are not configured yet. Please remove the files or contact us directly." }, { status: 503 });
  const submittedAt = new Date().toISOString();
  let requestId = `local-${Date.now()}`;
  let countryName = countrySlug;

  if (supabase) {
    const authClient = supabase.auth as unknown as { getUser: () => Promise<{ data: { user: { id: string } | null } }> };
    const [{ data: { user } }, { data: country }] = await Promise.all([
      authClient.getUser(),
      supabase.from("countries").select("id,name").eq("slug", countrySlug).eq("is_published", true).maybeSingle(),
    ]);
    if (!country) return NextResponse.json({ error: "Please choose one of the available destinations." }, { status: 400 });
    countryName = country.name;
    // Public students can insert requests, but RLS intentionally prevents them from
    // reading consultation rows. Generate the id here and avoid a SELECT after insert.
    requestId = crypto.randomUUID();
    const consultation = { id: requestId, profile_id: user?.id ?? null, country_id: country.id, name, email, phone, budget, study_level: studyLevel, consultation_mode: consultationMode, consent: true, university_interest: universityInterest || null };
    const { error } = admin
      ? await admin.from("consultation_requests").insert(consultation)
      : await supabase.from("consultation_requests").insert(consultation);
    if (error) {
      if (error) console.error("Supabase consultation insert failed:", { code: error.code, message: error.message, hint: error.hint });
      return NextResponse.json({ error: "We couldn’t save your request just now. Please try again or contact Edvora directly." }, { status: 500 });
    }
  } else if (!files.length) {
    try {
      const filePath = path.join(process.cwd(), "consultation-requests.json");
      const existing = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, "utf-8")) : [];
      existing.push({ id: requestId, name, email, phone, budget, country_slug: countrySlug, study_level: studyLevel, consultation_mode: consultationMode, university_interest: universityInterest, created_at: submittedAt });
      fs.writeFileSync(filePath, JSON.stringify(existing, null, 2));
    } catch { /* Local preview storage is best effort only. */ }
  }

  const documents: { filename: string; content_type: string; size_bytes: number; signed_url: string; expires_at: string }[] = [];
  if (admin && files.length) {
    const uploadedPaths: string[] = [];
    for (const file of files) {
      const ext = file.type === "application/pdf" ? "pdf" : file.type === "image/png" ? "png" : "jpg";
      const storagePath = `${requestId}/${crypto.randomUUID()}.${ext}`;
      const fileBytes = Buffer.from(await file.arrayBuffer());
      const { error: uploadError } = await admin.storage.from(bucket).upload(storagePath, fileBytes, { contentType: file.type, upsert: false });
      if (uploadError) {
        if (uploadedPaths.length) await admin.storage.from(bucket).remove(uploadedPaths);
        return NextResponse.json({ error: "A document could not be uploaded securely. Please try again." }, { status: 500 });
      }
      uploadedPaths.push(storagePath);
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      const { data: signed } = await admin.storage.from(bucket).createSignedUrl(storagePath, 7 * 24 * 60 * 60, { download: file.name.replace(/[\r\n"\\]/g, "_") });
      const { error: metadataError } = await admin.from("consultation_documents").insert({ consultation_id: requestId, storage_path: storagePath, original_filename: file.name.replace(/[\r\n]/g, "_").slice(0, 255), content_type: file.type, size_bytes: file.size, expires_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString() });
      if (metadataError || !signed?.signedUrl) {
        await admin.storage.from(bucket).remove([storagePath]);
        return NextResponse.json({ error: "Document metadata could not be saved securely. Please contact us directly." }, { status: 500 });
      }
      documents.push({ filename: file.name.replace(/[\r\n]/g, "_"), content_type: file.type, size_bytes: file.size, signed_url: signed.signedUrl, expires_at: expiresAt });
    }
  }

  // Keep student files inside the private Supabase bucket and staff dashboard.
  // n8n receives only whether documents were uploaded, never file data or signed URLs.
  const consultationDetails = [
    { label: "Student", value: name },
    { label: "Email", value: email },
    { label: "Phone / WhatsApp", value: phone },
    { label: "Destination", value: countryName },
    { label: "Study level", value: studyLevel },
    { label: "Annual budget", value: budget },
    { label: "Meeting preference", value: consultationMode === "in_person" ? "In person" : consultationMode === "online" ? "Online" : "No preference" },
    { label: "University interest", value: universityInterest || "I haven’t chosen yet" },
    { label: "Documents", value: documents.length ? `${documents.length} uploaded (available securely in the Edvora staff portal)` : "None uploaded" },
    { label: "Submitted", value: submittedAt },
  ];
  const notificationStatus = await notifyN8n({
    source: "edvora-website", request_type: "consultation", consultation_id: requestId, name, email, phone, budget, country_slug: countrySlug, country_name: countryName, study_level: studyLevel, consultation_mode: consultationMode, university_interest: universityInterest || "I haven’t chosen yet", consent: true, submitted_at: submittedAt, documents_uploaded: documents.length > 0, document_count: documents.length,
    student_email_subject: "We received your Edvora consultation request",
    student_email_html: edvoraEmail({ preheader: "Your consultation request has reached our team.", eyebrow: "Consultation request received", heading: `Thank you, ${name}`, intro: "Welcome to Edvora. We’ve received your consultation request and an advisor will review your study plans and follow up with you.", details: consultationDetails.filter(({ label }) => label !== "Documents"), note: "Your request is not yet a confirmed appointment. An Edvora advisor will contact you to discuss the next steps and meeting arrangements.", reference: requestId }),
    advisor_email_subject: `New consultation request — ${name}`,
    advisor_email_html: edvoraEmail({ preheader: `New consultation request from ${name} for ${countryName}.`, eyebrow: "Advisor notification", heading: "New consultation request", intro: "A student submitted a consultation request through the Edvora website. Review the details below and follow up with the student.", details: consultationDetails, note: `Contact the student at ${email} or ${phone}. Uploaded documents remain in the private Supabase document store and staff portal; this notification contains no document links.`, reference: requestId }),
  });
  return NextResponse.json({ ok: true, notificationStatus }, { status: 201 });
}
