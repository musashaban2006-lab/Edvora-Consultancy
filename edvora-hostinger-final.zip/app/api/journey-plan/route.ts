import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const countries = new Set(["uk", "sweden", "turkey", "south-cyprus", "romania", "germany", "italy", "china"]);
const levels = new Set(["Undergraduate", "Postgraduate", "Doctoral", "Language preparation"]);
const destinations = new Set(["germany", "italy", "south-cyprus", "turkey", "uk", "romania", "sweden", "china"]);
const stepIds = new Set(["choose", "course", "budget", "documents", "english", "visa", "advisor"]);

async function signedInClient() {
  const supabase = await createClient();
  if (!supabase) return { supabase: null, user: null };
  const { data: { user } } = await supabase.auth.getUser();
  return { supabase, user };
}

export async function GET() {
  const { supabase, user } = await signedInClient();
  if (!supabase) return NextResponse.json({ authenticated: false });
  if (!user) return NextResponse.json({ authenticated: false });
  const { data, error } = await supabase.from("student_journey_plans").select("plan,updated_at").eq("profile_id", user.id).maybeSingle();
  if (error) return NextResponse.json({ error: "Your saved journey plan could not be loaded." }, { status: 500 });
  return NextResponse.json({ authenticated: true, plan: data?.plan ?? null, updatedAt: data?.updated_at ?? null });
}

export async function PUT(request: Request) {
  const { supabase, user } = await signedInClient();
  if (!supabase || !user) return NextResponse.json({ error: "Sign in to sync your plan." }, { status: 401 });
  const body = await request.json().catch(() => null) as { plan?: Record<string, unknown> } | null;
  const plan = body?.plan;
  if (!plan || typeof plan !== "object" || Array.isArray(plan)) return NextResponse.json({ error: "Invalid journey plan." }, { status: 400 });

  const country = typeof plan.country === "string" ? plan.country : "";
  const level = typeof plan.level === "string" ? plan.level : "";
  const intake = typeof plan.intake === "string" ? plan.intake : "";
  const compared = Array.isArray(plan.compared) ? plan.compared : [];
  const completed = Array.isArray(plan.completed) ? plan.completed : [];
  if ((country && !countries.has(country)) || (level && !levels.has(level)) || (intake && !/^\d{4}-(0[1-9]|1[0-2])$/.test(intake)) || compared.length > 3 || compared.some((item) => typeof item !== "string" || !destinations.has(item)) || completed.some((item) => typeof item !== "string" || !stepIds.has(item))) {
    return NextResponse.json({ error: "Some journey plan choices are invalid." }, { status: 400 });
  }

  const safePlan = { country, level, intake, compared: [...new Set(compared as string[])], completed: [...new Set(completed as string[])] };
  const { error } = await supabase.from("student_journey_plans").upsert({ profile_id: user.id, plan: safePlan, updated_at: new Date().toISOString() }, { onConflict: "profile_id" });
  if (error) return NextResponse.json({ error: "Your journey plan could not be saved." }, { status: 500 });
  return NextResponse.json({ ok: true, plan: safePlan });
}
