import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { edvoraEmail } from "@/lib/email-templates";

export const runtime = "nodejs";
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ error: "Please complete the booking form and try again." }, { status: 400 });
  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim().toLowerCase();
  const phone = String(body.phone ?? "").trim();
  const test = String(body.test ?? "").trim();
  const date = String(body.date ?? "").trim();
  const time = String(body.time ?? "").trim();
  const targetScore = String(body.target_score ?? "").trim().slice(0, 80);
  const allowedTests = new Set(["IELTS", "PTE Academic", "Oxford ELLT"]);
  const appointment = new Date(`${date}T${time}:00+05:00`);
  if (name.length < 2 || name.length > 100 || !emailPattern.test(email) || phone.length < 7 || phone.length > 40 || !allowedTests.has(test) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time) || Number.isNaN(appointment.getTime()) || appointment <= new Date() || body.contact_consent !== "on" && body.contact_consent !== "true") {
    return NextResponse.json({ error: "Check your details, select a future date and time, and agree to be contacted." }, { status: 400 });
  }
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Booking storage is not configured yet. Please contact Edvora directly." }, { status: 503 });
  const { data: { user } } = await supabase.auth.getUser();
  const bookingId = crypto.randomUUID();
  const { error: insertError } = await supabase.from("mock_test_bookings").insert({
    id: bookingId,
    profile_id: user?.id ?? null,
    name,
    email,
    phone,
    test,
    target_score: targetScore || null,
    preferred_date: date,
    preferred_time: time,
    timezone: "Asia/Karachi",
    consent: true,
  });
  if (insertError) {
    console.error("Mock-test booking database insert failed:", { code: insertError.code, message: insertError.message });
    return NextResponse.json({ error: "We couldn’t save your mock-test request. Please try again or contact Edvora." }, { status: 500 });
  }

  const webhookUrl = process.env.N8N_MOCK_TEST_WEBHOOK_URL;

  const payload = {
    source: "edvora-free-mock-test-booking",
    booking_type: "free-mock-test",
    booking_id: bookingId,
    name, email, phone, whatsapp_number: phone, test, target_score: targetScore || null,
    preferred_date: date, preferred_time: time, timezone: "Asia/Karachi", timezone_label: "Pakistan Standard Time (PKT)",
    submitted_at: new Date().toISOString(),
    notification_channels: ["advisor_email", "student_email", "student_whatsapp"],
    student_confirmation: {
      subject: "We received your Edvora mock-test booking request",
      message: `Hi ${name}, we received your request for a free ${test} mock test on ${date} at ${time} PKT. An advisor will confirm availability by email and WhatsApp.`,
    },
    advisor_summary: `Free ${test} mock-test booking request from ${name}; preferred slot ${date} ${time} PKT. Reply to ${email} or WhatsApp ${phone} to confirm.`,
    student_email_subject: "We received your Edvora mock-test request",
    student_email_html: edvoraEmail({ preheader: "Your free mock-test booking request has reached our team.", eyebrow: "Free mock test", heading: `You’re on your way, ${name}`, intro: `Welcome to Edvora. We’ve received your request for a free ${test} mock test and will confirm the session details with you.`, details: [{ label: "Test", value: test }, { label: "Preferred date", value: date }, { label: "Preferred time", value: `${time} PKT` }, ...(targetScore ? [{ label: "Target score", value: targetScore }] : []), { label: "Name", value: name }, { label: "Email", value: email }], note: "Your requested time is pending confirmation. An advisor will contact you by email or WhatsApp to confirm availability.", reference: bookingId }),
    advisor_email_subject: `New free ${test} mock-test request — ${name}`,
    advisor_email_html: edvoraEmail({ preheader: `New free ${test} mock-test request from ${name}.`, eyebrow: "Advisor notification", heading: "New mock-test request", intro: "A student requested a free mock-test session through the Edvora website. Please confirm the preferred slot with them.", details: [{ label: "Name", value: name }, { label: "Email", value: email }, { label: "Phone / WhatsApp", value: phone }, { label: "Test", value: test }, { label: "Preferred date", value: date }, { label: "Preferred time", value: `${time} PKT` }, { label: "Target score", value: targetScore || "Not provided" }, { label: "Submitted", value: new Date().toISOString() }], note: `Reply to ${email} or contact the student on WhatsApp at ${phone}. Confirm availability before treating the booking as scheduled.`, reference: bookingId }),
  };
  let notificationStatus: "sent" | "not_configured" | "failed" = "not_configured";
  try {
    if (!webhookUrl) return NextResponse.json({ ok: true, notificationStatus }, { status: 201 });
    const response = await fetch(webhookUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), cache: "no-store", signal: AbortSignal.timeout(8000) });
    if (!response.ok) {
      console.error("Mock-test webhook returned a non-success status.", response.status);
      notificationStatus = "failed";
    } else notificationStatus = "sent";
  } catch {
    console.error("Mock-test webhook notification failed.");
    notificationStatus = "failed";
  }
  return NextResponse.json({ ok: true, notificationStatus }, { status: 201 });
}
