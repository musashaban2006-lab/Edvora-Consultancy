import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const validStatuses = new Set(["new", "contacted", "closed"]);

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
    return NextResponse.json({ error: "Invalid booking id." }, { status: 400 });
  }
  const body = await request.json().catch(() => null) as { status?: unknown } | null;
  const status = typeof body?.status === "string" ? body.status : "";
  if (!validStatuses.has(status)) return NextResponse.json({ error: "Choose a valid request status." }, { status: 400 });

  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please sign in." }, { status: 401 });
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "staff") return NextResponse.json({ error: "Staff access only." }, { status: 403 });

  const { error } = await supabase.from("mock_test_bookings").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
  if (error) return NextResponse.json({ error: "This request could not be updated." }, { status: 500 });
  return NextResponse.json({ ok: true, status });
}
