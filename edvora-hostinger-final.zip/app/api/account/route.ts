import { NextResponse } from "next/server";
import { createClient as createServerClient } from "@/lib/supabase/server";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

export async function DELETE() {
  const supabase = await createServerClient(); if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user } } = await supabase.auth.getUser(); if (!user) return NextResponse.json({ error: "Please sign in first." }, { status: 401 });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL; const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return NextResponse.json({ error: "Account deletion is not configured yet. Contact Edvora for help." }, { status: 503 });
  const admin = createSupabaseClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  const { error: enquiryError } = await admin.from("consultation_requests").delete().eq("profile_id", user.id);
  if (enquiryError) return NextResponse.json({ error: "We could not remove your account data. Please contact Edvora." }, { status: 500 });
  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) return NextResponse.json({ error: "We could not delete your account. Please contact Edvora." }, { status: 500 });
  return NextResponse.json({ ok: true });
}
