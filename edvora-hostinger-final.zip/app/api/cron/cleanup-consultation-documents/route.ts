import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function GET(request: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret || request.headers.get("authorization") !== `Bearer ${secret}`) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return NextResponse.json({ error: "Private storage is not configured." }, { status: 503 });
  const admin = createClient(url, key, { auth: { persistSession: false } });
  const { data: expired, error } = await admin.from("consultation_documents").select("id,storage_path").lte("expires_at", new Date().toISOString()).limit(500) as { data: { id: string; storage_path: string }[] | null; error: unknown };
  if (error) return NextResponse.json({ error: "Could not find expired documents." }, { status: 500 });
  if (!expired?.length) return NextResponse.json({ deleted: 0 });
  const { error: storageError } = await admin.storage.from("consultation-documents").remove(expired.map((item) => item.storage_path));
  if (storageError) return NextResponse.json({ error: "Expired files could not be deleted." }, { status: 500 });
  const { error: metadataError } = await admin.from("consultation_documents").delete().in("id", expired.map((item) => item.id));
  if (metadataError) return NextResponse.json({ error: "Files were deleted but metadata cleanup failed." }, { status: 500 });
  return NextResponse.json({ deleted: expired.length });
}
