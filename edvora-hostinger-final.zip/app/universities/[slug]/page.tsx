import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, MapPin } from "lucide-react";
import { getUniversities, getUniversity } from "@/lib/content";
import { CountryIntro } from "@/components/page-intro";
import { UniversityLogo } from "@/components/university-logo";
import { getUniversityDomain } from "@/lib/university-domains";
import { PhotoFallback } from "@/components/photo-fallback";

export async function generateStaticParams() {
  return (await getUniversities()).map((university) => ({
    slug: university.slug ?? university.id,
  }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const university = await getUniversity(slug);
  if (!university) return { title: "University profile", robots: { index: false, follow: true } };
  const place = [university.city, university.country].filter(Boolean).join(", ");
  return {
    title: `${university.name}${place ? `, ${place}` : ""} | University profile`,
    description: `${university.description} See location and explore current programmes and entry details with the university.`.slice(0, 160),
    alternates: { canonical: `/universities/${university.slug ?? university.id}` },
    openGraph: { title: `${university.name} | Edvora`, description: university.description, url: `/universities/${university.slug ?? university.id}`, images: [{ url: university.image, alt: university.photoAlt ?? `${university.name} campus` }] },
    twitter: { card: "summary_large_image", title: `${university.name} | Edvora`, description: university.description, images: [university.image] },
  };
}

export default async function UniversityDetail({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const university = await getUniversity(slug);
  if (!university) notFound();
  const officialDomain = getUniversityDomain(university.slug ?? university.id, university.name);
  const officialUrl = officialDomain ? `https://${officialDomain}` : undefined;

  return (
    <>
      <CountryIntro
        kicker={university.country.toUpperCase()}
        title={
          <span className="detail-title-with-logo">
            <span className="detail-title-logo-wrapper">
              <UniversityLogo name={university.name} slug={university.slug ?? university.id} size={54} />
            </span>
            <span>
              {university.name}
              <br />
              <em>could be next.</em>
            </span>
          </span>
        }
        text={university.description}
        image={university.image}
        imageAlt={university.photoAlt ?? (university.imageIsIllustrative ? `Illustrative campus photo; not a photograph of ${university.name}` : `${university.name} campus`)}
      />

      {(university.sample || university.sourceUrl) && (
        <div className="shell content-note">
          {university.sourceUrl ? (
            <>
              Independent directory listing for informational purposes. Edvora does not imply a partnership with this university.{" "}
              <a href={university.sourceUrl} target="_blank" rel="noreferrer">
                View directory source <ArrowUpRight size={14} />
              </a>
            </>
          ) : (
            "University directory entry for informational purposes. Edvora does not imply a partnership with this university."
          )}
        </div>
      )}

      <section className="shell detail-university">
        <div className={`detail-university-photo${university.photoTier && university.photoTier !== "named" ? " photo-placeholder" : ""}`}>
          <PhotoFallback src={university.image} alt={university.photoAlt ?? (university.imageIsIllustrative ? `Illustrative campus photo; not a photograph of ${university.name}` : `${university.name} campus`)} label={university.name.split(/\s+/).map((part: string) => part[0]).slice(0, 3).join("").toUpperCase()} sizes="(max-width: 700px) 100vw, 60vw" className="cover-image" />
          {university.photoTier === "city" && <span className="sample-university-pill">City view · illustrative</span>}
          {university.photoTier === "generic" && <span className="sample-university-pill">Campus placeholder</span>}
          {!university.photoTier && university.imageIsIllustrative && <span className="sample-university-pill">Illustrative campus photo</span>}
        </div>
        {university.photoPageUrl && <small className="photo-attribution detail-photo-attribution">Photo: <a href={university.photoPageUrl} target="_blank" rel="noreferrer">{university.photoArtist}</a>{university.photoLicense && <> · <a href={university.photoLicenseUrl} target="_blank" rel="noreferrer">{university.photoLicense}</a></>}</small>}

        <div className="detail-university-copy">
          <div className="flex items-center gap-3 mb-2">
            <UniversityLogo name={university.name} slug={university.slug ?? university.id} size={42} />
            <span className="eyebrow m-0">A PLACE TO EXPLORE</span>
          </div>

          <h2>
            Consider what
            <br />
            <em>fits your future.</em>
          </h2>

          <p>{university.description} For current programmes, entry requirements, fees, recognition, and campus details, use the university’s official information below.</p>

          <div className="detail-meta">
            <span>
              <MapPin size={15} />
              {university.city ? `${university.city}, ` : ""}
              {university.country}
            </span>
            <span>{university.type}</span>
          </div>

          <div className="university-detail-actions">
            {officialUrl && <a className="button button-orange" href={officialUrl} target="_blank" rel="noreferrer">Official university website <ArrowUpRight size={16} /></a>}
            <Link className="text-arrow" href="/contact">Ask Edvora about your options <ArrowUpRight size={16}/></Link>
          </div>
        </div>
      </section>

      <section className="university-facts-section"><div className="shell"><span className="eyebrow">CHECK BEFORE YOU APPLY</span><h2>Official details for <em>your decision.</em></h2><p className="university-facts-intro">Programme lists, fees, accreditations, and awards vary by course and intake. This profile only shows facts that have been verified from a current official source; check the university directly for the latest information.</p><div className="university-facts-grid">{["Courses and programmes", "Annual tuition fees", "Accreditations and recognition", "Awards and rankings"].map((label) => <article key={label}><h3>{label}</h3><p>See current information on the university’s official website.</p>{officialUrl && <a href={officialUrl} target="_blank" rel="noreferrer">Visit official site <ArrowUpRight size={14}/></a>}</article>)}</div></div></section>

      <section className="shell source-note">
        <span className="eyebrow">KEEP EXPLORING</span>
        <p>
          This is an independent university directory entry, not a claim of partnership. Programme details, intake dates, costs, recognition, and admission requirements can change. Verify them with the university.
        </p>
        <Link className="text-arrow" href="/countries">
          Explore destinations <ArrowUpRight size={16} />
        </Link>
      </section>
    </>
  );
}
