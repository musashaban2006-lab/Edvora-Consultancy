import { permanentRedirect } from "next/navigation";
export default function UniversitiesDirectoryRedirect() { permanentRedirect("/countries"); }
