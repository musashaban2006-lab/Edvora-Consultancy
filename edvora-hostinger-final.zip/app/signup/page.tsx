import type { Metadata } from "next";
import { AuthForm } from "@/components/auth-form";
export const metadata: Metadata = { title: "Create an account", robots: { index: false, follow: true } };
export default async function SignupPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) { const { next } = await searchParams; return <section className="auth-page"><div className="auth-side-photo"><span>Keep the<br/><em>possibilities</em><br/>close.</span></div><AuthForm mode="signup" next={next}/></section>; }
