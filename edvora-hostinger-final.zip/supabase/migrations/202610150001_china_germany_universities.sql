-- Add the China destination and expand the Germany and China directory listings.
-- Names are taken from official directory sources; students should confirm
-- programmes, admissions, and locations directly with each institution.

insert into public.countries
  (name, slug, region, tagline, accent, display_order, is_published)
values
  ('China', 'china', 'Asia', 'Explore study options across China’s leading university cities.', '#e15454', 8, true),
  ('Germany', 'germany', 'Europe', 'Research-led education and exciting career pathways.', '#8467d9', 6, true)
on conflict (slug) do update set
  name = excluded.name,
  region = excluded.region,
  tagline = excluded.tagline,
  accent = excluded.accent,
  display_order = excluded.display_order,
  is_published = true,
  updated_at = now();

insert into public.universities
  (country_id, name, slug, city, type, description, listing_source_url,
   study_levels, is_sample, is_featured, is_published)
select c.id, v.name, v.slug, v.city, 'University',
  'Directory listing. Confirm current courses, admission requirements, and campus location with the university.',
  v.source_url, array['Undergraduate','Postgraduate'], false, false, true
from (values
  ('germany','Technical University of Munich','technical-university-of-munich','Munich','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Ludwig Maximilian University of Munich','ludwig-maximilian-university-of-munich','Munich','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Heidelberg University','heidelberg-university','Heidelberg','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Freie Universität Berlin','freie-universitat-berlin','Berlin','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Humboldt-Universität zu Berlin','humboldt-universitat-zu-berlin','Berlin','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','RWTH Aachen University','rwth-aachen-university','Aachen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Bonn','university-of-bonn','Bonn','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Freiburg','university-of-freiburg','Freiburg im Breisgau','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Göttingen','university-of-gottingen','Göttingen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Tübingen','university-of-tubingen','Tübingen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Hamburg','university-of-hamburg','Hamburg','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Cologne','university-of-cologne','Cologne','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Goethe University Frankfurt','goethe-university-frankfurt','Frankfurt am Main','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Münster','university-of-munster','Münster','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Stuttgart','university-of-stuttgart','Stuttgart','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Leipzig University','leipzig-university','Leipzig','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','TU Dresden','tu-dresden','Dresden','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Karlsruhe Institute of Technology','karlsruhe-institute-of-technology','Karlsruhe','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Friedrich-Alexander University Erlangen-Nürnberg','friedrich-alexander-university-erlangen-nurnberg','Erlangen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Würzburg','university-of-wurzburg','Würzburg','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Johannes Gutenberg University Mainz','johannes-gutenberg-university-mainz','Mainz','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Bremen','university-of-bremen','Bremen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Duisburg-Essen','university-of-duisburg-essen','Essen','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Potsdam','university-of-potsdam','Potsdam','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Friedrich Schiller University Jena','friedrich-schiller-university-jena','Jena','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Bayreuth','university-of-bayreuth','Bayreuth','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Regensburg','university-of-regensburg','Regensburg','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Hohenheim','university-of-hohenheim','Stuttgart','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','Technische Universität Berlin','technische-universitat-berlin','Berlin','https://www.daad.de/en/studying-in-germany/universities/'),
  ('germany','University of Mannheim','university-of-mannheim','Mannheim','https://www.daad.de/en/studying-in-germany/universities/')
) as v(country_slug, name, slug, city, source_url)
join public.countries c on c.slug = v.country_slug
on conflict (slug) do update set
  country_id = excluded.country_id,
  name = excluded.name,
  city = excluded.city,
  type = excluded.type,
  description = excluded.description,
  listing_source_url = excluded.listing_source_url,
  study_levels = excluded.study_levels,
  is_sample = false,
  is_published = true,
  updated_at = now();

insert into public.universities
  (country_id, name, slug, city, type, description, listing_source_url,
   study_levels, is_sample, is_featured, is_published)
select c.id, v.name, v.slug, v.city, 'University',
  'Directory listing. Confirm current courses, admission requirements, and campus location with the university.',
  'https://en.moe.gov.cn/subordinate_universities/',
  array['Undergraduate','Postgraduate'], false, false, true
from (values
  ('Peking University','peking-university','Beijing'),
  ('Tsinghua University','tsinghua-university','Beijing'),
  ('Renmin University of China','renmin-university-of-china','Beijing'),
  ('Beijing Normal University','beijing-normal-university','Beijing'),
  ('China Agricultural University','china-agricultural-university','Beijing'),
  ('Beijing Foreign Studies University','beijing-foreign-studies-university','Beijing'),
  ('University of Science and Technology Beijing','university-of-science-and-technology-beijing','Beijing'),
  ('Beijing Language and Culture University','beijing-language-and-culture-university','Beijing'),
  ('Beijing University of Chemical Technology','beijing-university-of-chemical-technology','Beijing'),
  ('Beijing Jiaotong University','beijing-jiaotong-university','Beijing'),
  ('China University of Geosciences, Beijing','china-university-of-geosciences-beijing','Beijing'),
  ('Beijing University of Posts and Telecommunications','beijing-university-of-posts-and-telecommunications','Beijing'),
  ('China University of Mining and Technology, Beijing','china-university-of-mining-and-technology-beijing','Beijing'),
  ('China University of Petroleum, Beijing','china-university-of-petroleum-beijing','Beijing'),
  ('Beijing Forestry University','beijing-forestry-university','Beijing'),
  ('Communication University of China','communication-university-of-china','Beijing'),
  ('Central University of Finance and Economics','central-university-of-finance-and-economics','Beijing'),
  ('Central Conservatory of Music','central-conservatory-of-music','Beijing'),
  ('China University of Political Science and Law','china-university-of-political-science-and-law','Beijing'),
  ('University of International Business and Economics','university-of-international-business-and-economics','Beijing'),
  ('North China Electric Power University','north-china-electric-power-university','Beijing'),
  ('Tianjin University','tianjin-university','Tianjin'),
  ('Nankai University','nankai-university','Tianjin'),
  ('Dalian University of Technology','dalian-university-of-technology','Dalian'),
  ('Northeastern University','northeastern-university-china','Shenyang'),
  ('Jilin University','jilin-university','Changchun'),
  ('Northeast Normal University','northeast-normal-university','Changchun'),
  ('Northeast Forestry University','northeast-forestry-university','Harbin'),
  ('Fudan University','fudan-university','Shanghai'),
  ('Shanghai Jiao Tong University','shanghai-jiao-tong-university','Shanghai')
) as v(name, slug, city)
join public.countries c on c.slug = 'china'
on conflict (slug) do update set
  country_id = excluded.country_id,
  name = excluded.name,
  city = excluded.city,
  type = excluded.type,
  description = excluded.description,
  listing_source_url = excluded.listing_source_url,
  study_levels = excluded.study_levels,
  is_sample = false,
  is_published = true,
  updated_at = now();

-- Quick verification after applying this migration:
-- select c.name, count(u.id) as university_count
-- from public.countries c
-- left join public.universities u on u.country_id = c.id and u.is_published
-- where c.slug in ('germany', 'china')
-- group by c.name order by c.name;
