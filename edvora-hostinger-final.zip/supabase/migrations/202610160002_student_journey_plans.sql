create table if not exists public.student_journey_plans (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  plan jsonb not null default '{}'::jsonb check (jsonb_typeof(plan) = 'object'),
  updated_at timestamptz not null default now()
);

alter table public.student_journey_plans enable row level security;

drop policy if exists "Students manage their own journey plan" on public.student_journey_plans;
create policy "Students manage their own journey plan" on public.student_journey_plans
  for all to authenticated
  using (profile_id = (select auth.uid()))
  with check (profile_id = (select auth.uid()));

grant select, insert, update, delete on public.student_journey_plans to authenticated;
