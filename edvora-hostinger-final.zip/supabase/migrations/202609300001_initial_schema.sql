create extension if not exists pgcrypto;

create table if not exists public.countries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  region text,
  tagline text,
  description text,
  image_path text,
  accent text,
  display_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.universities (
  id uuid primary key default gen_random_uuid(),
  country_id uuid not null references public.countries(id) on delete restrict,
  name text not null,
  slug text not null unique,
  city text,
  type text,
  description text,
  website_url text,
  listing_source_url text,
  study_levels text[] not null default '{}',
  image_path text,
  is_sample boolean not null default false,
  is_featured boolean not null default false,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null,
  icon text,
  display_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.service_countries (
  service_id uuid not null references public.services(id) on delete cascade,
  country_id uuid not null references public.countries(id) on delete cascade,
  primary key (service_id, country_id)
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'student' check (role in ('student','staff')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete set null,
  country_id uuid references public.countries(id) on delete set null,
  university_id uuid references public.universities(id) on delete set null,
  student_display_name text not null,
  outcome text not null,
  quote text,
  image_path text,
  consent_to_publish boolean not null default false,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.saved_universities (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  university_id uuid not null references public.universities(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (profile_id, university_id)
);

create table if not exists public.consultation_requests (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete set null,
  country_id uuid not null references public.countries(id) on delete restrict,
  name text not null check (char_length(name) between 2 and 120),
  email text not null,
  phone text not null,
  study_level text not null,
  consent boolean not null default false check (consent),
  status text not null default 'new' check (status in ('new','contacted','closed')),
  staff_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists universities_country_idx on public.universities(country_id);
create index if not exists consultation_requests_status_created_idx on public.consultation_requests(status, created_at desc);
create index if not exists consultation_requests_profile_idx on public.consultation_requests(profile_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_edvora_staff()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'staff'
  );
$$;
grant execute on function public.is_edvora_staff() to anon, authenticated;

alter table public.countries enable row level security;
alter table public.universities enable row level security;
alter table public.services enable row level security;
alter table public.service_countries enable row level security;
alter table public.profiles enable row level security;
alter table public.stories enable row level security;
alter table public.saved_universities enable row level security;
alter table public.consultation_requests enable row level security;

create policy "Published countries are public" on public.countries for select to anon, authenticated using (is_published or public.is_edvora_staff());
create policy "Staff manage countries" on public.countries for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Published universities are public" on public.universities for select to anon, authenticated using (is_published or public.is_edvora_staff());
create policy "Staff manage universities" on public.universities for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Published services are public" on public.services for select to anon, authenticated using (is_published or public.is_edvora_staff());
create policy "Staff manage services" on public.services for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Published service links are public" on public.service_countries for select to anon, authenticated using (exists (select 1 from public.services s where s.id = service_id and (s.is_published or public.is_edvora_staff())));
create policy "Staff manage service links" on public.service_countries for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Users see their profile and staff see all" on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_edvora_staff());
create policy "Staff manage profiles" on public.profiles for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Consented published stories are public" on public.stories for select to anon, authenticated using ((is_published and consent_to_publish) or public.is_edvora_staff());
create policy "Staff manage stories" on public.stories for all to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());
create policy "Students manage their saved universities" on public.saved_universities for all to authenticated using (profile_id = (select auth.uid())) with check (profile_id = (select auth.uid()) and exists (select 1 from public.universities u where u.id = university_id and u.is_published));
create policy "Public may submit consultation requests" on public.consultation_requests for insert to anon, authenticated with check (consent and (profile_id is null or profile_id = (select auth.uid())));
create policy "Staff read and update consultation requests" on public.consultation_requests for select to authenticated using (public.is_edvora_staff());
create policy "Staff update consultation requests" on public.consultation_requests for update to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());

grant select on public.countries, public.universities, public.services, public.service_countries, public.stories to anon, authenticated;
grant select on public.profiles to authenticated;
grant select, insert, delete on public.saved_universities to authenticated;
grant insert on public.consultation_requests to anon, authenticated;
grant select, update on public.consultation_requests to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('site-media', 'site-media', true, 5242880, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy "Published website media is publicly readable" on storage.objects for select to anon, authenticated using (bucket_id = 'site-media');
create policy "Only Edvora staff may upload site media" on storage.objects for insert to authenticated with check (bucket_id = 'site-media' and public.is_edvora_staff());
create policy "Only Edvora staff may update site media" on storage.objects for update to authenticated using (bucket_id = 'site-media' and public.is_edvora_staff()) with check (bucket_id = 'site-media' and public.is_edvora_staff());
create policy "Only Edvora staff may delete site media" on storage.objects for delete to authenticated using (bucket_id = 'site-media' and public.is_edvora_staff());
