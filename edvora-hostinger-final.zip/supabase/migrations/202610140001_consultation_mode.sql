alter table public.consultation_requests
  add column if not exists consultation_mode text;

alter table public.consultation_requests
  drop constraint if exists consultation_requests_consultation_mode_check;

alter table public.consultation_requests
  add constraint consultation_requests_consultation_mode_check
  check (consultation_mode is null or consultation_mode in ('online', 'in_person', 'no_preference'));
