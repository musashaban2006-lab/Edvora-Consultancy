create table if not exists public.mock_test_bookings (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles(id) on delete set null,
  name text not null check (char_length(name) between 2 and 100),
  email text not null,
  phone text not null,
  test text not null check (test in ('IELTS', 'PTE Academic', 'Oxford ELLT')),
  target_score text,
  preferred_date date not null,
  preferred_time time not null,
  timezone text not null default 'Asia/Karachi',
  consent boolean not null default false check (consent),
  status text not null default 'new' check (status in ('new', 'contacted', 'closed')),
  staff_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists mock_test_bookings_status_created_idx
  on public.mock_test_bookings(status, created_at desc);
create index if not exists mock_test_bookings_profile_idx
  on public.mock_test_bookings(profile_id);

alter table public.mock_test_bookings enable row level security;

drop policy if exists "Public may request a mock test" on public.mock_test_bookings;
create policy "Public may request a mock test" on public.mock_test_bookings
  for insert to anon, authenticated
  with check (consent and (profile_id is null or profile_id = (select auth.uid())));

drop policy if exists "Staff read mock test bookings" on public.mock_test_bookings;
create policy "Staff read mock test bookings" on public.mock_test_bookings
  for select to authenticated using (public.is_edvora_staff());

drop policy if exists "Staff update mock test bookings" on public.mock_test_bookings;
create policy "Staff update mock test bookings" on public.mock_test_bookings
  for update to authenticated using (public.is_edvora_staff()) with check (public.is_edvora_staff());

grant insert on public.mock_test_bookings to anon, authenticated;
grant select, update on public.mock_test_bookings to authenticated;
