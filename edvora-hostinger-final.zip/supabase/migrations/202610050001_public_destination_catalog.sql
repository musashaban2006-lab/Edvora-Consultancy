-- Publish the agreed seven-country catalog. Keep legacy Finland records so saved
-- references remain valid, but remove them from public browsing.
update public.countries set is_published = false, updated_at = now() where slug = 'finland';
update public.universities set is_published = false, updated_at = now()
where country_id in (select id from public.countries where slug = 'finland');

insert into public.countries (name, slug, region, tagline, image_path, accent, display_order, is_published)
values
  ('United Kingdom','uk','Europe','World-class universities and a global outlook.','/images/countries/uk.jpg','#1677d2',1,true),
  ('Sweden','sweden','Nordics','Innovative learning in a welcoming student community.','/images/countries/sweden.jpg','#34b9cf',2,true),
  ('Turkey','turkey','Europe & Asia','A vibrant meeting point for cultures and ideas.','/images/countries/turkey.jpg','#fa845f',3,true),
  ('South Cyprus','south-cyprus','Europe','Mediterranean living with an international campus feel.','/images/countries/south-cyprus.jpg','#f2b84b',4,true),
  ('Romania','romania','Europe','Explore affordable study options in a welcoming European setting.','/images/countries/romania.jpg','#8467d9',5,true),
  ('Germany','germany','Europe','Research-led education and exciting career pathways.','/images/countries/germany.jpg','#8467d9',6,true),
  ('Italy','italy','Europe','Study surrounded by art, history, and creativity.','/images/countries/italy.jpg','#4eae8b',7,true)
on conflict (slug) do update set
  name=excluded.name, region=excluded.region, tagline=excluded.tagline,
  image_path=excluded.image_path, accent=excluded.accent,
  display_order=excluded.display_order, is_published=true, updated_at=now();

insert into public.universities
  (country_id,name,slug,city,type,description,listing_source_url,study_levels,is_sample,is_featured,is_published,image_path)
select c.id,v.name,v.slug,v.city,'University',
  'Listed in the Edvora Romania directory. Confirm current courses, entry requirements, and availability with the university.',
  'https://www.edu.ro/universitati_stat_civile',array['Undergraduate','Postgraduate'],false,false,true,
  '/images/universities/' || v.slug || '.jpg'
from (values
  ('University of Bucharest','university-of-bucharest','Bucharest'),
  ('Babeș-Bolyai University','babes-bolyai-university','Cluj-Napoca'),
  ('Politehnica University of Bucharest','politehnica-university-of-bucharest','Bucharest'),
  ('Alexandru Ioan Cuza University of Iași','alexandru-ioan-cuza-university-of-iasi','Iași'),
  ('West University of Timișoara','west-university-of-timisoara','Timișoara'),
  ('Transilvania University of Brașov','transilvania-university-of-brasov','Brașov'),
  ('University of Craiova','university-of-craiova','Craiova'),
  ('Technical University of Cluj-Napoca','technical-university-of-cluj-napoca','Cluj-Napoca'),
  ('Gheorghe Asachi Technical University of Iași','gheorghe-asachi-technical-university-of-iasi','Iași'),
  ('Ovidius University of Constanța','ovidius-university-of-constanta','Constanța')
) as v(name,slug,city)
join public.countries c on c.slug='romania'
on conflict (slug) do update set
  country_id=excluded.country_id, name=excluded.name, city=excluded.city,
  description=excluded.description, listing_source_url=excluded.listing_source_url,
  is_published=true, image_path=excluded.image_path, updated_at=now();
