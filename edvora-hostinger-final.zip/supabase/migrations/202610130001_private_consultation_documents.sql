alter table public.consultation_requests
  add column if not exists university_interest text;

create table if not exists public.consultation_documents (
  id uuid primary key default gen_random_uuid(),
  consultation_id uuid not null references public.consultation_requests(id) on delete cascade,
  storage_path text not null unique,
  original_filename text not null,
  content_type text not null check (content_type in ('application/pdf', 'image/jpeg', 'image/png')),
  size_bytes bigint not null check (size_bytes between 1 and 10485760),
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create index if not exists consultation_documents_expiry_idx on public.consultation_documents(expires_at);
create index if not exists consultation_documents_request_idx on public.consultation_documents(consultation_id);
alter table public.consultation_documents enable row level security;
drop policy if exists "Staff may view consultation document metadata" on public.consultation_documents;
create policy "Staff may view consultation document metadata" on public.consultation_documents
  for select to authenticated using (public.is_edvora_staff());
grant select on public.consultation_documents to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('consultation-documents', 'consultation-documents', false, 10485760, array['application/pdf','image/jpeg','image/png'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- No anon/authenticated storage policies are created: uploads, signed reads and deletion
-- are performed only by server routes using the private service role credential.
