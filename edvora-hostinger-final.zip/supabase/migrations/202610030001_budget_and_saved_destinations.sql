alter table public.consultation_requests
  add column if not exists budget text;

update public.consultation_requests
set budget = 'Still exploring'
where budget is null;

alter table public.consultation_requests
  alter column budget set not null;

create table if not exists public.saved_countries (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  country_id uuid not null references public.countries(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (profile_id, country_id)
);

alter table public.saved_countries enable row level security;
drop policy if exists "Students manage their saved countries" on public.saved_countries;
create policy "Students manage their saved countries" on public.saved_countries
  for all to authenticated
  using (profile_id = (select auth.uid()))
  with check (
    profile_id = (select auth.uid()) and
    exists (select 1 from public.countries c where c.id = country_id and c.is_published)
  );

grant select, insert, delete on public.saved_countries to authenticated;
