import type { Metadata } from "next";

export function pageMetadata(title: string, description: string, path: string): Metadata {
  const socialTitle = `${title} | Edvora`;
  const image = "/opengraph-image";
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      type: "website",
      locale: "en_PK",
      siteName: "Edvora",
      title: socialTitle,
      description,
      url: path,
      images: [{ url: image, width: 1200, height: 630, alt: `${title} — Edvora` }],
    },
    twitter: { card: "summary_large_image", title: socialTitle, description, images: [image] },
  };
}
