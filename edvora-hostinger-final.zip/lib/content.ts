import { createClient } from "@/lib/supabase/server";
import { countries as fallbackCountries, universities as fallbackUniversities, stories as fallbackStories } from "@/lib/data";

const mediaUrl = (client: NonNullable<Awaited<ReturnType<typeof createClient>>>, path?: string | null, fallback?: string) => {
  if (path?.startsWith("http")) return path.includes("images.unsplash.com") ? fallback ?? "" : path;
  if (path?.startsWith("/")) return path;
  if (path) return client.storage.from("site-media").getPublicUrl(path).data.publicUrl;
  return fallback ?? "";
};

export async function getCountries() {
  const supabase = await createClient(); if (!supabase) return fallbackCountries;
  const { data, error } = await supabase.from("countries").select("id,name,slug,region,tagline,image_path,accent").eq("is_published", true).order("display_order");
  if (error || !data?.length) return fallbackCountries;
  const merged = new Map(fallbackCountries.map((item) => [item.slug, item]));
  data.filter((item) => fallbackCountries.some((country) => country.slug === item.slug)).forEach((item, i) => {
    const fallback = merged.get(item.slug);
    merged.set(item.slug, { id: item.id, name: item.name, slug: item.slug, region: item.region ?? fallback?.region ?? "Europe", tagline: item.tagline ?? fallback?.tagline ?? "Explore your study options.", image: mediaUrl(supabase, item.image_path, fallback?.image ?? fallbackCountries[i % fallbackCountries.length].image), accent: item.accent ?? fallback?.accent ?? "#d47b5f" });
  });
  return [...merged.values()];
}

export async function getCountry(slug: string) {
  const supabase = await createClient(); if (!supabase) return fallbackCountries.find((item) => item.slug === slug) ?? null;
  const { data } = await supabase.from("countries").select("id,name,slug,region,tagline,image_path,accent").eq("slug", slug).eq("is_published", true).maybeSingle();
  if (!data) return fallbackCountries.find((item) => item.slug === slug) ?? null;
  return { id: data.id, name: data.name, slug: data.slug, region: data.region ?? "Europe", tagline: data.tagline ?? "Explore your study options.", image: mediaUrl(supabase, data.image_path, fallbackCountries[0].image), accent: data.accent ?? "#d47b5f" };
}

export async function getUniversities(countrySlug?: string) {
  const supabase = await createClient(); if (!supabase) return countrySlug ? fallbackUniversities.filter((item) => item.countrySlug === countrySlug) : fallbackUniversities;
  let query = supabase.from("universities").select("id,name,slug,city,description,image_path,type,study_levels,is_sample,listing_source_url,countries(name,slug)").eq("is_published", true).order("name");
  if (countrySlug) {
    const { data: country } = await supabase.from("countries").select("id").eq("slug", countrySlug).maybeSingle();
    if (!country) return fallbackUniversities.filter((item) => item.countrySlug === countrySlug);
    query = query.eq("country_id", country.id);
  }
  const { data, error } = await query;
  // Treat the local source catalog as the baseline and let Supabase enrich or
  // override it. A partially seeded database should never hide catalog entries.
  const catalog = new Map(fallbackUniversities.map((item) => [item.slug ?? item.id, item]));
  if (!error && data?.length) data.forEach((item, i) => {
    const country = item.countries as unknown as { name: string; slug: string } | null;
    if (!country?.slug || !fallbackCountries.some((allowed) => allowed.slug === country.slug)) return;
    const catalogItem = catalog.get(item.slug);
    catalog.set(item.slug, { ...catalogItem, id: item.id, slug: item.slug, name: item.name, city: item.city ?? catalogItem?.city ?? "", description: item.description ?? catalogItem?.description ?? "Explore programmes and study opportunities.", image: catalogItem?.photoTier ? catalogItem.image : mediaUrl(supabase, item.image_path, catalogItem?.image ?? fallbackUniversities[i % fallbackUniversities.length].image), type: item.type ?? catalogItem?.type ?? "University", country: country?.name ?? catalogItem?.country ?? "", countrySlug: country?.slug ?? catalogItem?.countrySlug ?? "", studyLevels: item.study_levels ?? catalogItem?.studyLevels ?? [], sample: item.is_sample ?? catalogItem?.sample ?? false, sourceUrl: item.listing_source_url ?? catalogItem?.sourceUrl });
  });
  const merged = [...catalog.values()];
  return countrySlug ? merged.filter((item) => item.countrySlug === countrySlug) : merged;
}

export async function getUniversity(slug: string) {
  const supabase = await createClient();
  if (!supabase) return fallbackUniversities.find((item) => item.id === slug) ?? null;
  const { data } = await supabase.from("universities").select("id,name,slug,city,description,image_path,type,study_levels,is_sample,listing_source_url,countries(name,slug)").eq("slug", slug).eq("is_published", true).maybeSingle();
  if (!data) return fallbackUniversities.find((item) => item.id === slug) ?? null;
  const country = data.countries as unknown as { name: string; slug: string } | null;
  if (!country?.slug || !fallbackCountries.some((allowed) => allowed.slug === country.slug)) return fallbackUniversities.find((item) => item.id === slug) ?? null;
  const catalogItem = fallbackUniversities.find((item) => (item.slug ?? item.id) === data.slug);
  return { ...catalogItem, id: data.id, slug: data.slug, name: data.name, city: data.city ?? catalogItem?.city ?? "", description: data.description ?? catalogItem?.description ?? "Explore programmes and study opportunities.", image: catalogItem?.photoTier ? catalogItem.image : mediaUrl(supabase, data.image_path, catalogItem?.image ?? fallbackUniversities[0].image), type: data.type ?? catalogItem?.type ?? "University", country: country.name, countrySlug: country.slug, studyLevels: data.study_levels ?? catalogItem?.studyLevels ?? [], sample: data.is_sample ?? catalogItem?.sample ?? false, sourceUrl: data.listing_source_url ?? catalogItem?.sourceUrl };
}

export async function getStories() {
  const supabase = await createClient(); if (!supabase) return fallbackStories;
  const { data, error } = await supabase.from("stories").select("id,student_display_name,outcome,quote,image_path,countries(name)").eq("is_published", true).eq("consent_to_publish", true).order("created_at", { ascending: false });
  if (error || !data?.length) return fallbackStories;
  return data.map((item, i) => ({ id: item.id, name: item.student_display_name, country: (item.countries as unknown as { name: string } | null)?.name ?? "International", outcome: item.outcome ?? "Study journey", quote: item.quote ?? "A new chapter started with a plan.", image: mediaUrl(supabase, item.image_path, fallbackStories[i % fallbackStories.length].image), initials: item.student_display_name.split(/\s+/).map((part: string) => part[0]).slice(0, 2).join("").toUpperCase(), sample: false }));
}

export async function getServices(countrySlug?: string) {
  const { services: fallback } = await import("@/lib/data");
  const supabase = await createClient(); if (!supabase) return fallback;
  const { data, error } = await supabase.from("services").select("id,name,slug,description,icon,service_countries(countries(slug))").eq("is_published", true).order("display_order");
  if (error || !data?.length) return fallback;
  const filtered = data.filter((item) => !countrySlug || (item.service_countries as unknown as { countries: { slug: string } | null }[])?.some((link) => link.countries?.slug === countrySlug));
  return filtered.map((item) => ({ title: item.name, text: item.description, icon: item.icon ?? "globe" }));
}

export async function getSavedItemIds(kind: "university" | "country") {
  const supabase = await createClient();
  if (!supabase) return [] as string[];
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [] as string[];
  if (kind === "country") {
    const { data } = await supabase.from("saved_countries").select("country_id").eq("profile_id", user.id);
    return (data ?? []).map((item: { country_id: string }) => item.country_id);
  }
  const { data } = await supabase.from("saved_universities").select("university_id").eq("profile_id", user.id);
  return (data ?? []).map((item: { university_id: string }) => item.university_id);
}
