export type LanguageTest = {
  slug: string;
  name: string;
  logo: string;
  summary: string;
  format: string;
  scoring: string;
  sections: { title: string; description: string }[];
  officialUrl: string;
  officialLabel: string;
};

export const languageTests: LanguageTest[] = [
  {
    slug: "ielts",
    name: "IELTS",
    logo: "/images/courses/ielts-provided.png",
    summary: "IELTS assesses English for study, work, and other purposes. Choose the test type that matches the requirements of your university or authority.",
    format: "IELTS Academic and General Training assess Listening, Reading, Writing, and Speaking. Listening and Speaking are the same across these two test types; Reading and Writing differ.",
    scoring: "Each skill receives a band score from 0 to 9, reported in whole and half bands. The overall band is the average of the four skill scores, rounded to the nearest half band.",
    sections: [
      { title: "Listening", description: "Listen to recordings in a range of contexts and answer questions about details, main ideas, and speaker meaning." },
      { title: "Reading", description: "Read texts and answer questions. Academic and General Training use different reading materials and tasks." },
      { title: "Writing", description: "Complete two writing tasks. The tasks differ between Academic and General Training." },
      { title: "Speaking", description: "Take part in a recorded, three-part interview with an examiner, including a short talk and follow-up discussion." },
    ],
    officialUrl: "https://ielts.org/take-a-test/test-types",
    officialLabel: "IELTS test types and format",
  },
  {
    slug: "pte-academic",
    name: "PTE Academic",
    logo: "/images/courses/pte.jpg",
    summary: "PTE Academic is Pearson’s computer-based English test for academic and related purposes.",
    format: "The test covers Speaking and Writing, Reading, and Listening. Some tasks assess more than one skill at the same time.",
    scoring: "The overall score and communicative-skill scores are reported on Pearson’s Global Scale of English from 10 to 90.",
    sections: [
      { title: "Speaking and Writing", description: "Respond to spoken and written prompts, including integrated tasks that combine skills." },
      { title: "Reading", description: "Work with academic texts through a variety of computer-delivered question types." },
      { title: "Listening", description: "Listen to recordings and respond to questions or tasks based on the information heard." },
    ],
    officialUrl: "https://www.pearsonpte.com/pte-academic/",
    officialLabel: "PTE Academic format and scoring",
  },
  {
    slug: "pte-general",
    name: "PTE General",
    logo: "/images/courses/pte.jpg",
    summary: "PTE General is now known as Pearson English International Certificate. It assesses general English at six proficiency levels.",
    format: "The qualification assesses all four language skills through a written examination and a separate spoken examination. Confirm the current format for the level you plan to take.",
    scoring: "The six levels align with CEFR levels A1, A2, B1, B2, C1, and C2. The qualification is assessed at the selected level rather than on IELTS-style bands.",
    sections: [
      { title: "Listening", description: "Understand spoken English in a range of everyday and study-related situations." },
      { title: "Reading", description: "Understand written texts and respond to questions about their meaning and details." },
      { title: "Writing", description: "Produce written responses appropriate to the level and task." },
      { title: "Speaking", description: "Complete spoken tasks with an interlocutor as part of the separate speaking examination." },
    ],
    officialUrl: "https://qualifications.pearson.com/en/qualifications/international-certificate/international-certificate/test-levels.html",
    officialLabel: "Pearson English International Certificate levels",
  },
  {
    slug: "duolingo-english-test",
    name: "Duolingo English Test",
    logo: "/images/courses/duolingo.jpg",
    summary: "The Duolingo English Test (DET) is an online English proficiency test that can be taken from home. Check your chosen institution’s requirements before booking.",
    format: "The one-hour test process includes setup and identity verification, a scored assessment, and writing and speaking samples. The assessment is computer-adaptive.",
    scoring: "Overall and individual-skill scores are reported from 10 to 160 in five-point increments. The report also includes integrated subscores for Literacy, Comprehension, Conversation, and Production.",
    sections: [
      { title: "Reading", description: "Tasks assess vocabulary, comprehension, and the ability to understand written English." },
      { title: "Listening", description: "Tasks assess understanding of spoken English and audio information." },
      { title: "Writing", description: "Respond to open-ended prompts and demonstrate written communication." },
      { title: "Speaking", description: "Respond to spoken prompts and demonstrate clear, coherent spoken communication." },
    ],
    officialUrl: "https://englishtest.duolingo.com/test-takers",
    officialLabel: "DET format and test-taker information",
  },
  {
    slug: "oxford-ellt",
    name: "Oxford ELLT",
    logo: "/images/courses/oxford-ellt.jpg",
    summary: "Oxford ELLT is an English language test for people applying to study internationally. Check the current test version and accepting institution before registering.",
    format: "ELLT Global assesses Reading, Listening, Writing, and Speaking. Current published guidance lists a 40-minute Reading test and a 25-minute Listening test; check the official guide for the remaining component details.",
    scoring: "ELLT Global reports skill levels on the OIDI scale from 0 to 12, with an overall level calculated from the four component levels. Use the provider’s current conversion guidance when interpreting results.",
    sections: [
      { title: "Reading", description: "Answer questions based on two reading passages. The provider’s current guide lists 32 multiple-choice-style questions." },
      { title: "Listening", description: "Answer questions based on three recordings. The provider’s current guide lists 24 multiple-choice-style questions." },
      { title: "Writing", description: "Complete a written response assessed against the test’s published criteria." },
      { title: "Speaking", description: "Complete the speaking assessment through the test’s online process." },
    ],
    officialUrl: "https://oxfordellt.com/ellt-global/test-takers/",
    officialLabel: "Oxford ELLT format and scoring",
  },
  {
    slug: "toefl",
    name: "TOEFL iBT",
    logo: "/images/courses/toefl.jpg",
    summary: "TOEFL iBT measures English used in academic settings. Its format and score reporting changed on January 21, 2026.",
    format: "The current test assesses Reading, Listening, Writing, and Speaking. Reading and Listening use a multistage adaptive design.",
    scoring: "For tests taken from January 21, 2026, section and overall scores use a 1–6 scale in half-point increments. During the transition through January 2028, score reports also provide a comparable 0–120 overall estimate.",
    sections: [
      { title: "Reading", description: "Read and respond to academic and other relevant written material. The current section adapts across modules." },
      { title: "Listening", description: "Listen to conversations and academic material, then demonstrate understanding. The current section adapts across modules." },
      { title: "Writing", description: "Show written communication skills through the tasks in the current TOEFL iBT format." },
      { title: "Speaking", description: "Respond to speaking tasks designed to measure communication in academic contexts." },
    ],
    officialUrl: "https://www.ets.org/toefl/test-takers/ibt/scores/understand-scores.html",
    officialLabel: "TOEFL iBT format updates and score scale",
  },
  {
    slug: "languagecert-academic",
    name: "LanguageCert Academic",
    logo: "/images/courses/languagecert-academic.png",
    summary: "LanguageCert Academic is a multilevel English test designed for academic purposes and higher-education applications.",
    format: "The test assesses Listening, Reading, Writing, and Speaking through a written component and a spoken component. Published guidance lists approximately 40 minutes for Listening, 50 minutes for Reading, 50 minutes for Writing, and 14 minutes for Speaking.",
    scoring: "Scores are reported on the LanguageCert Global Scale from 0 to 100, with individual skill scores and a corresponding CEFR level. The test covers B1 to C2 for its academic proficiency range.",
    sections: [
      { title: "Listening", description: "Answer questions based on spoken academic and everyday material." },
      { title: "Reading", description: "Work with written texts through multiple-choice, gap-fill, and matching-style tasks." },
      { title: "Writing", description: "Complete two extended-response tasks." },
      { title: "Speaking", description: "Complete a live speaking component with questions and interactive speaking tasks." },
    ],
    officialUrl: "https://www.languagecert.org/en/about-us/recognition/languagecert-academic-recognition",
    officialLabel: "LanguageCert Academic format and scoring",
  },
];

export function getLanguageTest(slug: string) {
  return languageTests.find((test) => test.slug === slug);
}
