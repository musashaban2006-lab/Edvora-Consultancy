export const universityDomains: Record<string, string> = {
  // UK Universities
  cambridge: "cam.ac.uk",
  oxford: "ox.ac.uk",
  "imperial-college-london": "imperial.ac.uk",
  "university-of-cambridge": "cam.ac.uk",
  "university-of-oxford": "ox.ac.uk",
  "kings-college-london": "kcl.ac.uk",
  ucl: "ucl.ac.uk",
  "university-of-manchester": "manchester.ac.uk",
  "university-of-edinburgh": "ed.ac.uk",
  "university-of-warwick": "warwick.ac.uk",
  "university-of-bristol": "bristol.ac.uk",
  "university-of-glasgow": "gla.ac.uk",
  "university-of-birmingham": "bham.ac.uk",
  "university-of-southampton": "soton.ac.uk",
  "university-of-leeds": "leeds.ac.uk",
  "university-of-sheffield": "sheffield.ac.uk",
  "university-of-nottingham": "nottingham.ac.uk",
  "queen-mary-university-of-london": "qmul.ac.uk",
  "newcastle-university": "ncl.ac.uk",
  "university-of-exeter": "exeter.ac.uk",
  "university-of-york": "york.ac.uk",
  "university-of-bath": "bath.ac.uk",
  "university-of-liverpool": "liverpool.ac.uk",
  "cardiff-university": "cardiff.ac.uk",
  "queen-s-university-belfast": "qub.ac.uk",
  "lancaster-university": "lancaster.ac.uk",
  "university-of-sussex": "sussex.ac.uk",
  "university-of-surrey": "surrey.ac.uk",
  "university-of-strathclyde": "strath.ac.uk",
  "university-of-leicester": "le.ac.uk",
  "university-of-reading": "reading.ac.uk",
  "university-of-dundee": "dundee.ac.uk",
  "coventry-university": "coventry.ac.uk",
  "brunel-university-london": "brunel.ac.uk",
  "university-of-greenwich": "gre.ac.uk",
  "university-of-westminster": "westminster.ac.uk",
  "aston-university": "aston.ac.uk",
  "birmingham-city-university": "bcu.ac.uk",
  "city-st-george-s-university-of-london": "city.ac.uk",
  "durham-university": "durham.ac.uk",
  "university-of-st-andrews": "st-andrews.ac.uk",
  "university-of-aberdeen": "abdn.ac.uk",
  "kingston-university": "kingston.ac.uk",
  "middlesex-university": "mdx.ac.uk",
  "de-montfort-university": "dmu.ac.uk",

  // Sweden
  lund: "lu.se",
  uppsala: "uu.se",
  kth: "kth.se",
  linkoping: "liu.se",
  umea: "umu.se",
  "stockholm-university": "su.se",
  "chalmers-university-of-technology": "chalmers.se",
  "university-of-gothenburg": "gu.se",
  "karolinska-institutet": "ki.se",

  // Cyprus
  "university-of-nicosia": "unic.ac.cy",
  "european-university-cyprus": "euc.ac.cy",
  "cyprus-university-of-technology": "cut.ac.cy",
  "frederick-university": "frederick.ac.cy",
  "neapolis-university-pafos": "nup.ac.cy",
  "open-university-of-cyprus": "ouc.ac.cy",
  "university-of-cyprus": "ucy.ac.cy",
  "uclan-cyprus": "uclancyprus.ac.cy",
  "cyprus-school-molecular-medicine": "cing.ac.cy",

  // Turkey
  "koc-university": "ku.edu.tr",
  "middle-east-technical-university": "metu.edu.tr",
  "sabanci-university": "sabanciuniv.edu",
  "bogazici-university": "boun.edu.tr",
  "istanbul-technical-university": "itu.edu.tr",
  "bilkent-university": "bilkent.edu.tr",
  "hacettepe-university": "hacettepe.edu.tr",
  "istanbul-university": "istanbul.edu.tr",
  "ankara-university": "ankara.edu.tr",
  "bahcesehir-university": "bau.edu.tr",
  "kadir-has-university": "khas.edu.tr",
  "ozyegin-university": "ozyegin.edu.tr",
  "yildiz-technical-university": "yildiz.edu.tr",
  "yeditepe-university": "yeditepe.edu.tr",
  "abdullah-gul-university": "agu.edu.tr",
  "ataturk-university": "atauni.edu.tr",
  "cankaya-university": "cankaya.edu.tr",
  "istanbul-medipol-university": "medipol.edu.tr",
  "anadolu-university": "anadolu.edu.tr",
  "gazi-university": "gazi.edu.tr",
  "ege-university": "ege.edu.tr",

  // Italy
  bologna: "unibo.it",
  "university-of-bologna": "unibo.it",
  "scuola-normale-superiore-di-pisa": "sns.it",
  "sapienza-university-of-rome": "uniroma1.it",
  "politecnico-di-milano": "polimi.it",
  "santanna-school-of-advanced-studies": "santannapisa.it",
  "university-of-padua": "unipd.it",
  "humanitas-university": "hunimed.eu",
  "universita-cattolica-del-sacro-cuore": "unicatt.it",
  "university-of-milan": "unimi.it",
  "polytechnic-university-of-turin": "polito.it",
  "university-of-florence": "unifi.it",
  "university-of-pisa": "unipi.it",
  "university-of-naples-federico-ii": "unina.it",
  "university-of-rome-tor-vergata": "uniroma2.it",
  "university-of-trento": "unitn.it",
  "university-of-siena": "unisi.it",
  "ca-foscari-university-of-venice": "unive.it",

  // Finland
  aalto: "aalto.fi",
  "aalto-university": "aalto.fi",
  helsinki: "helsinki.fi",
  "university-of-helsinki": "helsinki.fi",
  "tampere-university": "tuni.fi",
  "lut-university": "lut.fi",
  "university-of-turku": "utu.fi",
  "university-of-oulu": "oulu.fi",
  "university-of-jyvaskyla": "jyu.fi",
  "university-of-vaasa": "univaasa.fi",
  "hanken-school-of-economics": "hanken.fi",
  "abo-akademi-university": "abo.fi",
  "university-of-eastern-finland": "uef.fi",
  "university-of-lapland": "ulapland.fi",

  // Germany
  tum: "tum.de",
  "technical-university-of-munich": "tum.de",
  "ludwig-maximilians-university-of-munich": "lmu.de",
  "heidelberg-university": "uni-heidelberg.de",
  "humboldt-university-of-berlin": "hu-berlin.de",
  "free-university-of-berlin": "fu-berlin.de",
  "rwth-aachen-university": "rwth-aachen.de",
  berlin: "berlinsbi.com",
  "berlin-school-of-business-and-innovation": "berlinsbi.com",
};

export function getUniversityDomain(slugOrId: string, name?: string): string | undefined {
  if (universityDomains[slugOrId]) return universityDomains[slugOrId];

  const clean = slugOrId.toLowerCase().replace(/[^a-z0-9]/g, "-");
  if (universityDomains[clean]) return universityDomains[clean];

  if (name) {
    const lowerName = name.toLowerCase();
    for (const [key, domain] of Object.entries(universityDomains)) {
      if (lowerName.includes(key.replace(/-/g, " "))) return domain;
    }
    // Smart heuristic inferences based on keywords
    if (lowerName.includes("cambridge")) return "cam.ac.uk";
    if (lowerName.includes("oxford")) return "ox.ac.uk";
    if (lowerName.includes("imperial")) return "imperial.ac.uk";
    if (lowerName.includes("birmingham")) return "bham.ac.uk";
    if (lowerName.includes("manchester")) return "manchester.ac.uk";
    if (lowerName.includes("edinburgh")) return "ed.ac.uk";
    if (lowerName.includes("warwick")) return "warwick.ac.uk";
    if (lowerName.includes("bristol")) return "bristol.ac.uk";
    if (lowerName.includes("glasgow")) return "gla.ac.uk";
    if (lowerName.includes("leeds")) return "leeds.ac.uk";
    if (lowerName.includes("sheffield")) return "sheffield.ac.uk";
    if (lowerName.includes("lund")) return "lu.se";
    if (lowerName.includes("uppsala")) return "uu.se";
    if (lowerName.includes("helsinki")) return "helsinki.fi";
    if (lowerName.includes("bologna")) return "unibo.it";
    if (lowerName.includes("nicosia")) return "unic.ac.cy";
    if (lowerName.includes("sabancı") || lowerName.includes("sabanci")) return "sabanciuniv.edu";
    if (lowerName.includes("koç") || lowerName.includes("koc")) return "ku.edu.tr";
    if (lowerName.includes("bilkent")) return "bilkent.edu.tr";
    if (lowerName.includes("aalto")) return "aalto.fi";
  }

  return undefined;
}
