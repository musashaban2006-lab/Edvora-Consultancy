type EmailDetail = { label: string; value: string };

const escapeHtml = (value: unknown) => String(value ?? "")
  .replace(/&/g, "&amp;")
  .replace(/</g, "&lt;")
  .replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;")
  .replace(/'/g, "&#039;");

const publicSiteUrl = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/$/, "");
const logoUrl = publicSiteUrl.startsWith("https://") ? `${publicSiteUrl}/edvora-logo-exact.jpeg` : "";

function rows(details: EmailDetail[]) {
  return details.map(({ label, value }) => `<tr>
    <td style="padding:12px 14px;border-bottom:1px solid #e4edf5;color:#52677d;font-size:14px;width:40%;">${escapeHtml(label)}</td>
    <td style="padding:12px 14px;border-bottom:1px solid #e4edf5;color:#102d4e;font-size:14px;font-weight:600;">${escapeHtml(value)}</td>
  </tr>`).join("");
}

export function edvoraEmail({
  preheader,
  eyebrow,
  heading,
  intro,
  details,
  note,
  reference,
}: {
  preheader: string;
  eyebrow: string;
  heading: string;
  intro: string;
  details: EmailDetail[];
  note: string;
  reference: string;
}) {
  const brand = logoUrl
    ? `<img src="${escapeHtml(logoUrl)}" width="190" alt="Edvora — Your Global Educational Partner" style="display:block;width:190px;max-width:100%;height:auto;border:0;">`
    : `<div style="font-size:25px;font-weight:800;letter-spacing:-1px;color:#064b86;">edvora</div><div style="font-size:11px;color:#52718d;">Your Global Educational Partner</div>`;
  const siteLink = publicSiteUrl.startsWith("https://")
    ? `<a href="${escapeHtml(publicSiteUrl)}" style="color:#075da4;text-decoration:none;font-weight:700;">Visit Edvora</a>`
    : "Edvora Educational Consultancy";
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(heading)}</title></head>
<body style="margin:0;padding:0;background:#edf4f8;font-family:Arial,Helvetica,sans-serif;color:#17334e;">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">${escapeHtml(preheader)}</div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:linear-gradient(135deg,#e9f4f8,#f4f7fb);padding:32px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border:1px solid #d6e5ef;border-radius:20px;overflow:hidden;box-shadow:0 12px 32px rgba(21,60,91,.12);">
        <tr><td style="padding:25px 30px;background:#f8fbfd;border-bottom:1px solid #e0ebf3;">${brand}</td></tr>
        <tr><td style="padding:30px 30px 12px;">
          <div style="font-size:11px;letter-spacing:1.8px;text-transform:uppercase;color:#087aab;font-weight:700;">${escapeHtml(eyebrow)}</div>
          <h1 style="margin:12px 0 10px;font-size:28px;line-height:1.2;letter-spacing:-.5px;color:#102d4e;">${escapeHtml(heading)}</h1>
          <p style="margin:0;color:#52677d;font-size:15px;line-height:1.7;">${escapeHtml(intro)}</p>
        </td></tr>
        <tr><td style="padding:16px 30px 8px;">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border:1px solid #dce8f0;border-radius:14px;overflow:hidden;background:#f8fbfd;">${rows(details)}</table>
        </td></tr>
        <tr><td style="padding:14px 30px 28px;"><p style="margin:0;padding:15px 16px;border-left:3px solid #0aa5c8;background:#eff8fb;border-radius:8px;color:#435d74;font-size:13px;line-height:1.65;">${escapeHtml(note)}</p></td></tr>
        <tr><td style="padding:18px 30px;background:#f7fafc;border-top:1px solid #e0ebf3;color:#60758a;font-size:12px;line-height:1.7;">
          <strong style="color:#17334e;">Edvora Educational Consultancy</strong><br>Your Global Educational Partner<br>${siteLink}<br>
          <span style="color:#8a9bab;">Reference: ${escapeHtml(reference)}</span>
        </td></tr>
      </table>
      <p style="margin:14px 0 0;color:#8092a3;font-size:11px;">This is an automated message from Edvora. Please do not share sensitive documents by replying to this email.</p>
    </td></tr>
  </table>
</body></html>`;
}
