import commonsPhotoManifest from "@/lib/university-photo-manifest.json";

export type Country = { id: string; name: string; slug: string; region: string; tagline: string; image: string; accent: string };
export type University = { id: string; slug?: string; name: string; country: string; countrySlug: string; city: string; description: string; image: string; imageIsIllustrative?: boolean; photoTier?: "named" | "city" | "generic"; photoAlt?: string; photoArtist?: string; photoPageUrl?: string; photoLicense?: string; photoLicenseUrl?: string; featured?: boolean; type: string; studyLevels?: string[]; sample?: boolean; sourceUrl?: string };
export type Story = { id: string; name: string; country: string; outcome: string; quote: string; image: string; initials: string; sample?: boolean };

const photo = (id: string, _width = 1200) => id.startsWith("photo-") ? "/images/success-stories/visa-approval-01.jpg" : id;

export const countries: Country[] = [
  { id: "uk", name: "United Kingdom", slug: "uk", region: "Europe", tagline: "World-class universities and a global outlook.", image: "/images/countries/uk.jpg", accent: "#1677d2" },
  { id: "sweden", name: "Sweden", slug: "sweden", region: "Nordics", tagline: "Innovative learning in a welcoming student community.", image: "/images/countries/sweden.jpg", accent: "#34b9cf" },
  { id: "turkey", name: "Turkey", slug: "turkey", region: "Europe & Asia", tagline: "A vibrant meeting point for cultures and ideas.", image: "/images/countries/turkey.jpg", accent: "#fa845f" },
  { id: "cyprus", name: "South Cyprus", slug: "south-cyprus", region: "Europe", tagline: "Mediterranean living with an international campus feel.", image: "/images/countries/south-cyprus.jpg", accent: "#f2b84b" },
  { id: "romania", name: "Romania", slug: "romania", region: "Europe", tagline: "Explore affordable study options in a welcoming European setting.", image: "/images/countries/romania.jpg", accent: "#8467d9" },
  { id: "germany", name: "Germany", slug: "germany", region: "Europe", tagline: "Research-led education and exciting career pathways.", image: "/images/countries/germany.jpg", accent: "#8467d9" },
  { id: "italy", name: "Italy", slug: "italy", region: "Europe", tagline: "Study surrounded by art, history, and creativity.", image: "/images/countries/italy.jpg", accent: "#4eae8b" },
  { id: "china", name: "China", slug: "china", region: "East Asia", tagline: "Explore a rich academic culture across dynamic student cities.", image: "/images/countries/china.jpg", accent: "#c94b50" },
];

const source = {
  uk: "https://consultwithbis.com/united-kingdom/",
  sweden: "https://consultwithbis.com/sweden/",
  cyprus: "https://consultwithbis.com/cyprus/",
  turkey: "https://www.timeshighereducation.com/student/best-universities/best-universities-turkey",
  ukMembers: "https://www.universitiesuk.ac.uk/about-us/our-members",
  cyprusOfficial: "https://www.nbri.gov.cy/ri-in-cyprus/",
  italy: "https://www.timeshighereducation.com/student/best-universities/best-universities-italy",
  romania: "https://www.edu.ro/universitati_stat_civile",
  swedenOfficial: "https://uhr.se/en/start/recognition-of-foreign-qualifications/enic-naric-sweden/higher-education-institutions-in-sweden/",
  chinaOfficial: "https://en.moe.gov.cn/subordinate_universities/",
  germanyOfficial: "https://www.hochschulkompass.de/en/study-in-germany.html",
};

const universityPhotos: Record<string, string> = {
  cambridge: "/images/universities/university-of-cambridge.jpg",
  oxford: "/images/universities/university-of-oxford.jpg",
  "imperial-college-london": "/images/universities/imperial-college-london.jpg",
  lund: "/images/universities/lund-university.jpg",
  "university-of-edinburgh": "/images/universities/showcase/edinburgh-university.jpg",
  "university-of-manchester": "/images/universities/university-of-manchester.jpg",
  "istanbul-university": "/images/universities/istanbul-university.jpg",
  "koc-university": "/images/universities/koc-university.jpg",
};
const illustrativeUniversityPhotos = [
  "/images/universities/showcase/birmingham-university-campus.jpg",
  "/images/universities/showcase/illustrative-campus-lakeside.jpg",
  "/images/universities/showcase/illustrative-campus-students.jpg",
];
const illustrativePhotoFor = (id: string) => illustrativeUniversityPhotos[[...id].reduce((sum, letter) => sum + letter.charCodeAt(0), 0) % illustrativeUniversityPhotos.length];
const university = (id: string, name: string, country: string, countrySlug: string, city: string, description: string, _image: string, sourceUrl?: string, featured = false): University => ({ id, slug: id, name, country, countrySlug, city, description, image: universityPhotos[id] ?? illustrativePhotoFor(id), imageIsIllustrative: !universityPhotos[id], sourceUrl, featured, type: "University", studyLevels: ["Undergraduate", "Postgraduate"] });

export const universities: University[] = [
  university("cambridge", "University of Cambridge", "United Kingdom", "uk", "Cambridge", "A globally recognized university with a rich academic tradition and a collegiate student experience.", "photo-1523050854058-8df90110c9f1", source.uk, true),
  university("oxford", "University of Oxford", "United Kingdom", "uk", "Oxford", "A historic university known for its academic breadth, research, and distinctive college communities.", "photo-1562774053-701939374585", source.uk),
  university("imperial-college-london", "Imperial College London", "United Kingdom", "uk", "London", "A London-based university focused on science, engineering, medicine, and business.", "photo-1513635269975-59663e0ac1ad", source.uk),
  university("lund", "Lund University", "Sweden", "sweden", "Lund", "A research-led university with an international student community in southern Sweden.", "photo-1517248135467-4c7edcad34c4", source.sweden, true),
  university("uppsala", "Uppsala University", "Sweden", "sweden", "Uppsala", "One of Scandinavia’s historic universities, with study and research across many fields.", "photo-1523050854058-8df90110c9f1", source.sweden),
  university("kth", "KTH Royal Institute of Technology", "Sweden", "sweden", "Stockholm", "A technology-focused university in Stockholm with engineering and innovation programmes.", "photo-1519389950473-47ba0277781c", source.sweden),
  university("linkoping", "Linköping University", "Sweden", "sweden", "Linköping", "A modern university with interdisciplinary study, research, and industry connections.", "photo-1498243691581-b145c3f54a5a", source.sweden),
  university("umea", "Umeå University", "Sweden", "sweden", "Umeå", "A broad-based university in northern Sweden with a lively, international campus.", "photo-1564981797816-1043664bf78d", source.sweden),
  university("university-of-nicosia", "University of Nicosia", "South Cyprus", "south-cyprus", "Nicosia", "An international university offering programmes across a wide range of disciplines.", "photo-1498307833015-e7b400441eb8", source.cyprus, true),
  university("cyprus-school-molecular-medicine", "Cyprus School of Molecular Medicine", "South Cyprus", "south-cyprus", "Nicosia", "A specialist institution focused on postgraduate study and research in molecular medicine.", "photo-1576091160399-112ba8d25d1d", source.cyprus),
  university("european-university-cyprus", "European University Cyprus", "South Cyprus", "south-cyprus", "Nicosia", "An international university with study options across professional and academic fields.", "photo-1498243691581-b145c3f54a5a", source.cyprus),
  university("koc-university", "Koç University", "Turkey", "turkey", "Istanbul", "A research university in Istanbul with programmes across sciences, humanities, and professional fields.", "photo-1524231757912-21f4fe3a7200", source.turkey, true),
  university("middle-east-technical-university", "Middle East Technical University", "Turkey", "turkey", "Ankara", "A public research university in Ankara with a strong focus on science and engineering.", "photo-1562774053-701939374585", source.turkey),
  university("sabanci-university", "Sabancı University", "Turkey", "turkey", "Istanbul", "An interdisciplinary university offering flexible study across engineering, arts, and social sciences.", "photo-1498243691581-b145c3f54a5a", source.turkey),
  university("bogazici-university", "Boğaziçi University", "Turkey", "turkey", "Istanbul", "A public research university with a broad academic community in Istanbul.", "photo-1513635269975-59663e0ac1ad", source.turkey),
  university("istanbul-technical-university", "Istanbul Technical University", "Turkey", "turkey", "Istanbul", "A technical university with programmes in engineering, architecture, and applied sciences.", "photo-1519389950473-47ba0277781c", source.turkey),
  university("bilkent-university", "Bilkent University", "Turkey", "turkey", "Ankara", "A research-focused university with study across science, engineering, and the humanities.", "photo-1523050854058-8df90110c9f1", source.turkey),
  university("kadir-has-university", "Kadir Has University", "Turkey", "turkey", "Istanbul", "An urban university with programmes in communication, business, engineering, and social sciences.", "photo-1498243691581-b145c3f54a5a", source.turkey),
  university("yildiz-technical-university", "Yıldız Technical University", "Turkey", "turkey", "Istanbul", "A public technical university with a range of engineering and applied study options.", "photo-1519389950473-47ba0277781c", source.turkey),
  university("abdullah-gul-university", "Abdullah Gül University", "Turkey", "turkey", "Kayseri", "A public university with an international outlook and English-medium study options.", "photo-1562774053-701939374585", source.turkey),
  university("ataturk-university", "Atatürk University", "Turkey", "turkey", "Erzurum", "A public university with a wide range of academic departments and research areas.", "photo-1564981797816-1043664bf78d", source.turkey),
  university("bahcesehir-university", "Bahçeşehir University", "Turkey", "turkey", "Istanbul", "An international university with programmes spanning business, engineering, and the arts.", "photo-1524231757912-21f4fe3a7200", source.turkey),
  university("cankaya-university", "Çankaya University", "Turkey", "turkey", "Ankara", "A university in Ankara offering study in engineering, law, business, and the arts.", "photo-1562774053-701939374585", source.turkey),
  university("hacettepe-university", "Hacettepe University", "Turkey", "turkey", "Ankara", "A public research university with programmes in health, science, and other disciplines.", "photo-1576091160399-112ba8d25d1d", source.turkey),
  university("istanbul-medipol-university", "Istanbul Medipol University", "Turkey", "turkey", "Istanbul", "A university with programmes in health sciences and a range of other fields.", "photo-1576091160399-112ba8d25d1d", source.turkey),
  university("ozyegin-university", "Özyeğin University", "Turkey", "turkey", "Istanbul", "An international university with study options across business, engineering, and social sciences.", "photo-1498243691581-b145c3f54a5a", source.turkey),
  { id: "berlin", name: "Berlin School of Business and Innovation", country: "Germany", countrySlug: "germany", city: "Berlin", description: "Business and creative-industry programmes in one of Europe’s most international cities.", image: illustrativePhotoFor("berlin"), imageIsIllustrative: true, type: "Private university", studyLevels: ["Undergraduate", "Postgraduate"], sample: true },
  { id: "bologna", slug: "bologna", name: "University of Bologna", country: "Italy", countrySlug: "italy", city: "Bologna", description: "An internationally connected university in a city with centuries of academic history.", image: illustrativePhotoFor("bologna"), imageIsIllustrative: true, type: "Public university", studyLevels: ["Undergraduate", "Postgraduate", "Doctoral"], sourceUrl: source.italy },
];

// The THE Turkey 2026 table lists more institutions than the featured entries above.
// Keep the complete set available in the directory while linking each record to its source.
const turkeyRankingNames = [
  "Anadolu University", "Bartın University", "Fırat University", "Istanbul Gelişim University", "Izmir Institute of Technology", "Selçuk University", "İstinye University",
  "Akdeniz University", "Ankara University", "Biruni University", "Düzce University", "Ege University", "Erciyes University", "Gazi University", "Gebze Technical University", "İnönü University", "Istanbul Medeniyet University", "Istanbul University", "Istanbul University-Cerrahpaşa", "Necmettin Erbakan University", "Sakarya University", "Süleyman Demirel University", "TOBB University of Economics and Technology", "University of Health Sciences, Türkiye", "Yaşar University",
  "Acıbadem University", "Adana Alparslan Türkeş Science and Technology University", "Adıyaman University", "Afyon Kocatepe University", "Afyonkarahisar Health Sciences University", "Aksaray University", "Alanya Alaaddin Keykubat University", "Altınbaş University", "Ankara Yıldırım Beyazıt University", "Atılım University", "Aydın Adnan Menderes University", "Balıkesir University", "Başkent University", "Beykent University", "Bezmiâlem Vakıf University", "Bilecik Şeyh Edebali University", "Bolu Abant İzzet Baysal University", "Bozok University", "Burdur Mehmet Akif Ersoy University", "Bursa Technical University", "Bursa Uludağ University", "Çukurova University", "Dicle University", "Dokuz Eylül University", "Dumlupınar University", "Erzincan Binali Yıldırım University", "Eskişehir Osmangazi University", "Eskişehir Technical University", "Gaziantep University", "Giresun University", "Harran University", "Hatay Mustafa Kemal University", "Hitit University", "Istanbul Aydın University", "Istanbul Bilgi University", "Istanbul Okan University", "Izmir University of Economics", "Karabük University", "Karadeniz Technical University", "Karamanoğlu Mehmetbey University", "Kastamonu University", "Kırıkkale University", "Kocaeli University", "Konya Technical University", "Kırşehir Ahi Evran University", "Manisa Celal Bayar University", "Marmara University", "Mersin University", "Muğla Sıtkı Koçman University", "Muş Alparslan University", "Niğde Ömer Halisdemir University", "Ondokuz Mayıs University", "Ordu University", "Pamukkale University", "Recep Tayyip Erdoğan University", "Sakarya University of Applied Sciences", "Sinop University", "Sivas Cumhuriyet University", "Tekirdağ Namık Kemal University", "Tokat Gaziosmanpaşa University", "Trakya University", "Uşak University", "Van Yüzüncü Yıl University", "Yeditepe University", "Zonguldak Bülent Ecevit University", "Çanakkale Onsekiz Mart University", "Çankırı Karatekin University", "Üsküdar University", "İzmir Kâtip Çelebi University",
];

const slugify = (value: string) => value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const existingTurkeyNames = new Set(universities.filter((item) => item.countrySlug === "turkey").map((item) => slugify(item.name)));
universities.push(...turkeyRankingNames.filter((name) => !existingTurkeyNames.has(slugify(name))).map((name, index) => university(
  slugify(name), name, "Turkey", "turkey", "Türkiye", "Listed in the Times Higher Education World University Rankings 2026 Turkey table. Check the university’s official site for current courses and entry requirements.",
  ["photo-1562774053-701939374585", "photo-1519389950473-47ba0277781c", "photo-1498243691581-b145c3f54a5a"][index % 3], source.turkey,
)));

// Broad destination catalogs make it possible to browse beyond the handful of featured partners.
const ukNames = ["Abertay University", "Aberystwyth University", "Anglia Ruskin University", "Aston University", "Bangor University", "Bath Spa University", "Birkbeck, University of London", "Birmingham City University", "Bournemouth University", "Brunel University London", "Canterbury Christ Church University", "Cardiff Metropolitan University", "Cardiff University", "City St George’s, University of London", "Coventry University", "Cranfield University", "De Montfort University", "Durham University", "Edge Hill University", "University of Edinburgh", "University of Exeter", "Falmouth University", "University of Glasgow", "Goldsmiths, University of London", "Harper Adams University", "Heriot-Watt University", "University of Hertfordshire", "University of Huddersfield", "University of Hull", "Imperial College London", "Keele University", "King’s College London", "Kingston University", "Lancaster University", "University of Leeds", "Leeds Beckett University", "Leeds Trinity University", "University of Leicester", "University of Lincoln", "University of Liverpool", "Liverpool John Moores University", "London Metropolitan University", "London School of Economics and Political Science", "London South Bank University", "Loughborough University", "University of Manchester", "Manchester Metropolitan University", "Middlesex University", "Newcastle University", "Northumbria University", "University of Nottingham", "Nottingham Trent University", "The Open University", "University of Oxford", "Oxford Brookes University", "University of Plymouth", "University of Portsmouth", "Queen Mary University of London", "Queen’s University Belfast", "University of Reading", "University of Roehampton", "University of Salford", "University of Sheffield", "Sheffield Hallam University", "University of Southampton", "University of St Andrews", "University of Stirling", "University of Strathclyde", "University of Surrey", "University of Sussex", "Swansea University", "Teesside University", "University of the Arts London", "University of Bath", "University of Bedfordshire", "University of Birmingham", "University of Bradford", "University of Brighton", "University of Bristol", "University of Cambridge", "University of Chester", "University of Dundee", "University of East Anglia", "University of East London", "University of Essex", "University of Greenwich", "University of Kent", "University of Warwick", "University of Westminster", "University of Wolverhampton", "University of York", "University of York St John", "University College London", "University of Aberdeen", "University of Gloucestershire", "University of Greater Manchester", "University of Lancashire", "University of Sunderland", "University of Worcester", "Wrexham University", "University of Winchester", "Royal Holloway, University of London", "University of the Highlands and Islands", "University of South Wales", "University of Buckingham", "University of Northampton"];
const italyNames = ["Scuola Normale Superiore di Pisa", "Sapienza University of Rome", "Politecnico di Milano", "Sant’Anna School of Advanced Studies", "University of Padua", "Humanitas University", "Università Cattolica del Sacro Cuore", "Vita-Salute San Raffaele University", "University of Milan", "University of Naples Federico II", "University of Rome Tor Vergata", "University of Brescia", "University of Florence", "University of Pavia", "University of Pisa", "University of Siena", "University of Trento", "University of Verona", "Free University of Bozen-Bolzano", "Marche Polytechnic University", "Polytechnic University of Turin", "University of Genoa", "University of Milan-Bicocca", "University of Turin", "Ca’ Foscari University of Venice", "Campus Bio-Medico University of Rome", "Polytechnic University of Bari", "University of Catania", "University of Ferrara", "University of Messina", "University of Modena and Reggio Emilia", "University of Palermo", "University of Salerno", "University of Trieste", "University of Eastern Piedmont", "Parthenope University of Naples", "University of Bari Aldo Moro", "University of Cagliari", "University of Calabria", "University of Insubria", "University of L’Aquila", "University of Parma", "University of Tuscia", "University of Udine", "Gabriele d’Annunzio University", "University of Foggia", "Roma Tre University", "University of Salento", "Kore University of Enna", "University of Camerino", "University of Campania Luigi Vanvitelli", "University of Sannio", "University of Urbino Carlo Bo"];
const cyprusNames = ["Cyprus University of Technology", "Frederick University", "Neapolis University Pafos", "Open University of Cyprus", "University of Cyprus", "UCLan Cyprus"];
const romaniaNames = ["University of Bucharest", "Babeș-Bolyai University", "Politehnica University of Bucharest", "Alexandru Ioan Cuza University of Iași", "West University of Timișoara", "Transilvania University of Brașov", "University of Craiova", "Technical University of Cluj-Napoca", "Gheorghe Asachi Technical University of Iași", "Ovidius University of Constanța"];
function addCatalog(names: string[], country: string, countrySlug: string, sourceUrl: string, cityBySlug: Record<string, string> = {}) {
  const existing = new Set(universities.filter((item) => item.countrySlug === countrySlug).map((item) => slugify(item.name)));
  const additions = names.filter((name) => { const key = slugify(name); if (existing.has(key)) return false; existing.add(key); return true; });
  universities.push(...additions.map((name, index) => university(slugify(name), name, country, countrySlug, cityBySlug[slugify(name)] ?? "", `Explore programmes, admissions information, and study opportunities at ${name}. Confirm current course availability and entry requirements with the university.`, ["photo-1562774053-701939374585", "photo-1523050854058-8df90110c9f1", "photo-1498243691581-b145c3f54a5a"][index % 3], sourceUrl)));
}

const ukCityGroups: Record<string, string[]> = {
  London: ["Birkbeck, University of London", "City St George’s, University of London", "Goldsmiths, University of London", "Imperial College London", "King’s College London", "Kingston University", "London Metropolitan University", "London School of Economics and Political Science", "London South Bank University", "Middlesex University", "Queen Mary University of London", "University of the Arts London", "University of East London", "University of Greenwich", "University of Westminster", "University of Roehampton", "University College London"],
  Birmingham: ["Aston University", "Birmingham City University", "University of Birmingham"],
  Manchester: ["University of Manchester", "Manchester Metropolitan University", "University of Greater Manchester"],
  Edinburgh: ["University of Edinburgh", "Heriot-Watt University"],
  Glasgow: ["University of Glasgow", "University of Strathclyde"],
  Newcastle: ["Newcastle University", "Northumbria University"],
  Leeds: ["University of Leeds", "Leeds Beckett University", "Leeds Trinity University"],
  Sheffield: ["University of Sheffield", "Sheffield Hallam University"],
  Liverpool: ["University of Liverpool", "Liverpool John Moores University"],
  Cardiff: ["Cardiff University", "Cardiff Metropolitan University", "University of South Wales"],
  Cambridge: ["University of Cambridge", "Anglia Ruskin University"],
  Oxford: ["University of Oxford", "Oxford Brookes University"],
  Bristol: ["University of Bristol"],
  Nottingham: ["University of Nottingham", "Nottingham Trent University"],
  Leicester: ["De Montfort University", "University of Leicester"],
  Coventry: ["Coventry University", "University of Warwick"],
  Bath: ["University of Bath", "Bath Spa University"],
  Dundee: ["Abertay University", "University of Dundee"],
  Belfast: ["Queen’s University Belfast"],
  Swansea: ["Swansea University", "University of Wales Trinity Saint David"],
  York: ["University of York", "University of York St John"],
  Aberdeen: ["University of Aberdeen"],
  Egham: ["Royal Holloway, University of London"],
  Canterbury: ["Canterbury Christ Church University", "University of Kent"],
  Plymouth: ["University of Plymouth"],
  Portsmouth: ["University of Portsmouth"],
  Exeter: ["University of Exeter"],
  Durham: ["Durham University"],
  Lancaster: ["Lancaster University"],
  Loughborough: ["Loughborough University"],
  Salford: ["University of Salford"],
  Reading: ["University of Reading"],
  Southampton: ["University of Southampton"],
  Brighton: ["University of Brighton", "University of Sussex"],
  Lincoln: ["University of Lincoln"],
  Chester: ["University of Chester"],
  Norwich: ["University of East Anglia"],
  Colchester: ["University of Essex"],
  Huddersfield: ["University of Huddersfield"],
  Hull: ["University of Hull"],
  Bradford: ["University of Bradford"],
  Hatfield: ["University of Hertfordshire"],
  Wolverhampton: ["University of Wolverhampton"],
  Stirling: ["University of Stirling"],
  StAndrews: ["University of St Andrews"],
  Ormskirk: ["Edge Hill University"],
  Falmouth: ["Falmouth University"],
  Newport: ["Harper Adams University", "Wrexham University"],
  Luton: ["University of Bedfordshire"],
  HighWycombe: ["University of Buckingham"],
  Northampton: ["University of Northampton"],
  Worcester: ["University of Worcester"],
  Cheltenham: ["University of Gloucestershire"],
  Sunderland: ["University of Sunderland"],
  Winchester: ["University of Winchester"],
  MiltonKeynes: ["The Open University"],
  Inverness: ["University of the Highlands and Islands"],
};
const ukCityBySlug = Object.fromEntries(Object.entries(ukCityGroups).flatMap(([city, names]) => names.map((name) => [slugify(name), city.replace("StAndrews", "St Andrews").replace("HighWycombe", "High Wycombe").replace("MiltonKeynes", "Milton Keynes")]))) as Record<string, string>;
addCatalog(ukNames, "United Kingdom", "uk", source.ukMembers, ukCityBySlug);
for (const item of universities.filter((entry) => entry.countrySlug === "uk")) item.city ||= ukCityBySlug[slugify(item.name)] ?? "";
addCatalog(italyNames, "Italy", "italy", source.italy);
addCatalog(cyprusNames, "South Cyprus", "south-cyprus", source.cyprusOfficial);
addCatalog(romaniaNames, "Romania", "romania", source.romania);

const swedenNames = ["Stockholm University", "Karolinska Institutet", "Karlstad University", "Kristianstad University", "Linnaeus University", "Luleå University of Technology", "Mid Sweden University", "Örebro University", "Swedish University of Agricultural Sciences", "University of Gothenburg", "Malmö University", "Blekinge Institute of Technology", "Dalarna University", "University of Gävle", "Halmstad University", "University of Skövde", "University West", "Mälardalen University", "Södertörn University"];
const swedenCityGroups: Record<string, string[]> = { Stockholm: ["Stockholm University", "Karolinska Institutet"], Uppsala: ["Swedish University of Agricultural Sciences"], Karlstad: ["Karlstad University"], Kristianstad: ["Kristianstad University"], Växjö: ["Linnaeus University"], Luleå: ["Luleå University of Technology"], Sundsvall: ["Mid Sweden University"], Örebro: ["Örebro University"], Gothenburg: ["University of Gothenburg"], Malmö: ["Malmö University"], Karlskrona: ["Blekinge Institute of Technology"], Falun: ["Dalarna University"], Gävle: ["University of Gävle"], Halmstad: ["Halmstad University"], Skövde: ["University of Skövde"], Trollhättan: ["University West"], Västerås: ["Mälardalen University"], Huddinge: ["Södertörn University"] };
const swedenCityBySlug = Object.fromEntries(Object.entries(swedenCityGroups).flatMap(([city, names]) => names.map((name) => [slugify(name), city]))) as Record<string, string>;
addCatalog(swedenNames, "Sweden", "sweden", source.swedenOfficial, swedenCityBySlug);
for (const item of universities.filter((entry) => entry.countrySlug === "sweden")) item.city ||= swedenCityBySlug[slugify(item.name)] ?? "";

const chinaUniversities: Array<[string, string]> = [
  ["Peking University", "Beijing"], ["Tsinghua University", "Beijing"], ["Renmin University of China", "Beijing"], ["Beijing Normal University", "Beijing"], ["Beijing Foreign Studies University", "Beijing"], ["Beijing Jiaotong University", "Beijing"], ["Beijing University of Posts and Telecommunications", "Beijing"], ["Beijing Forestry University", "Beijing"], ["China University of Political Science and Law", "Beijing"], ["University of International Business and Economics", "Beijing"],
  ["Tianjin University", "Tianjin"], ["Nankai University", "Tianjin"], ["Fudan University", "Shanghai"], ["Shanghai Jiao Tong University", "Shanghai"], ["Tongji University", "Shanghai"], ["East China Normal University", "Shanghai"], ["Shanghai University", "Shanghai"], ["Nanjing University", "Nanjing"], ["Southeast University", "Nanjing"], ["Hohai University", "Nanjing"], ["Nanjing Agricultural University", "Nanjing"],
  ["Wuhan University", "Wuhan"], ["Huazhong University of Science and Technology", "Wuhan"], ["Central China Normal University", "Wuhan"], ["Zhejiang University", "Hangzhou"], ["Xiamen University", "Xiamen"], ["Ocean University of China", "Qingdao"], ["Sun Yat-sen University", "Guangzhou"], ["South China University of Technology", "Guangzhou"], ["Sichuan University", "Chengdu"], ["University of Electronic Science and Technology of China", "Chengdu"], ["Chongqing University", "Chongqing"], ["Xi’an Jiaotong University", "Xi’an"], ["Xidian University", "Xi’an"],
  ["Harbin Institute of Technology", "Harbin"], ["Hunan University", "Changsha"], ["Central South University", "Changsha"], ["University of Science and Technology of China", "Hefei"], ["Hefei University of Technology", "Hefei"], ["Jilin University", "Changchun"], ["Lanzhou University", "Lanzhou"], ["Dalian University of Technology", "Dalian"], ["Northeastern University", "Shenyang"], ["Shandong University", "Jinan"],
];
addCatalog(chinaUniversities.map(([name]) => name), "China", "china", source.chinaOfficial, Object.fromEntries(chinaUniversities.map(([name, city]) => [slugify(name), city])));

const germanUniversities: Array<[string, string]> = [
  ["RWTH Aachen University", "Aachen"], ["University of Bonn", "Bonn"], ["University of Cologne", "Cologne"], ["Technical University of Munich", "Munich"], ["Ludwig Maximilian University of Munich", "Munich"], ["Heidelberg University", "Heidelberg"], ["University of Freiburg", "Freiburg"], ["University of Stuttgart", "Stuttgart"], ["University of Tübingen", "Tübingen"], ["University of Hamburg", "Hamburg"], ["Humboldt University of Berlin", "Berlin"], ["Free University of Berlin", "Berlin"], ["Technical University of Berlin", "Berlin"], ["University of Münster", "Münster"], ["University of Göttingen", "Göttingen"], ["Leipzig University", "Leipzig"], ["TU Dresden", "Dresden"], ["University of Potsdam", "Potsdam"], ["University of Bremen", "Bremen"], ["University of Duisburg-Essen", "Essen"], ["Goethe University Frankfurt", "Frankfurt am Main"], ["Johannes Gutenberg University Mainz", "Mainz"], ["University of Würzburg", "Würzburg"], ["Friedrich-Alexander University Erlangen-Nürnberg", "Erlangen"], ["University of Bayreuth", "Bayreuth"], ["University of Regensburg", "Regensburg"], ["Philipps University of Marburg", "Marburg"], ["Friedrich Schiller University Jena", "Jena"], ["TU Darmstadt", "Darmstadt"], ["Karlsruhe Institute of Technology", "Karlsruhe"], ["University of Mannheim", "Mannheim"], ["University of Hohenheim", "Stuttgart"], ["University of Augsburg", "Augsburg"], ["Saarland University", "Saarbrücken"], ["Kiel University", "Kiel"], ["University of Rostock", "Rostock"],
];
addCatalog(germanUniversities.map(([name]) => name), "Germany", "germany", source.germanyOfficial, Object.fromEntries(germanUniversities.map(([name, city]) => [slugify(name), city])));

const normalizePhotoKeyPart = (value: string) => value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().match(/[a-z0-9]+/g)?.filter((token) => token !== "the" && token !== "of").join(" ") ?? "";
const commonsPhotos = commonsPhotoManifest as Record<string, Pick<University, "photoTier" | "photoAlt" | "photoArtist" | "photoPageUrl" | "photoLicense" | "photoLicenseUrl"> & { image: string; tier: "named" | "city" | "generic"; alt: string; artist: string; pageUrl: string; license: string; licenseUrl: string }>;
for (const item of universities) {
  const photo = commonsPhotos[`${normalizePhotoKeyPart(item.country)}::${normalizePhotoKeyPart(item.name)}`];
  if (!photo) continue;
  item.image = photo.image;
  item.photoTier = photo.tier;
  item.photoAlt = photo.alt;
  item.photoArtist = photo.artist;
  item.photoPageUrl = photo.pageUrl;
  item.photoLicense = photo.license;
  item.photoLicenseUrl = photo.licenseUrl;
  item.imageIsIllustrative = photo.tier !== "named";
}

export const stories: Story[] = [
];

export const services = [
  { title: "Find your fit", text: "Explore universities and courses that make sense for your plans, budget, and strengths.", icon: "compass" },
  { title: "Application guidance", text: "Get help understanding requirements, timelines, and the documents your university asks for.", icon: "send" },
  { title: "Visa preparation", text: "Get organized for the student visa process with destination-specific guidance.", icon: "globe" },
];

export const steps = [
  { number: "01", title: "Discover", text: "Tell us what you want to study and where you hope to go." },
  { number: "02", title: "Plan", text: "Explore university options, requirements, and budgets." },
  { number: "03", title: "Apply", text: "Prepare your applications with a clear timeline and support." },
  { number: "04", title: "Arrive", text: "Get ready for your new campus and the next chapter." },
];
