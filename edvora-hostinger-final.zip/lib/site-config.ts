export const edvoraContact = {
  phoneDisplay: "0320 7836683",
  phoneInternational: "+923207836683",
  whatsapp: "923207836683",
  email: "edvorainternationalofficial@gmail.com",
  tagline: "Your global education partner",
};
