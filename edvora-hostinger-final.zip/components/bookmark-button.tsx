"use client";

import { useState } from "react";
import { Bookmark } from "lucide-react";

export function BookmarkButton({ kind, id, initialSaved = false }: { kind: "university" | "country"; id: string; initialSaved?: boolean }) {
  const [saved, setSaved] = useState(initialSaved); const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
  async function toggle() {
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL) { setMessage("Connect Supabase to save items."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/saved", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind, id, action: saved ? "remove" : "save" }) });
      if (response.status === 401) { window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`; return; }
      if (!response.ok) { const result = await response.json(); setMessage(result.error ?? "Unable to update saved items."); return; }
      setSaved(!saved);
      setMessage("");
    } catch { setMessage("Unable to update saved items right now."); }
    finally { setBusy(false); }
  }
  return <span className="bookmark-control"><button type="button" className={saved ? "bookmark saved" : "bookmark"} aria-label={saved ? `Remove ${kind} from saved items` : `Save ${kind}`} title={saved ? "Remove from saved items" : `Save ${kind}`} aria-pressed={saved} onClick={toggle} disabled={busy}><Bookmark size={16} fill={saved ? "currentColor" : "none"}/></button>{message && <span className="bookmark-message" role="status">{message}</span>}</span>;
}
