"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import "./intro-photo-flow.css";

export type IntroFlowPhoto = { src: string; alt: string };
type FlowDirection = "left-to-right" | "right-to-left" | "alternate";

type SlideState = {
  current: number;
  previous: number | null;
  direction: "left" | "right";
  moving: boolean;
};

export function IntroPhotoFlow({
  photos,
  label,
  flow = "alternate",
  className = "",
}: {
  photos: IntroFlowPhoto[];
  label: string;
  flow?: FlowDirection;
  className?: string;
}) {
  const stageRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  const [tabVisible, setTabVisible] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [slide, setSlide] = useState<SlideState>({ current: 0, previous: null, direction: "right", moving: true });

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    if (!("IntersectionObserver" in window)) {
      setInView(true);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { threshold: 0.05 });
    observer.observe(stage);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    const initialTransition = window.setTimeout(() => {
      setSlide((current) => current.previous === null ? { ...current, moving: false } : current);
    }, 1800);
    return () => window.clearTimeout(initialTransition);
  }, []);

  useEffect(() => {
    if (!inView || !tabVisible || reducedMotion || photos.length < 2) return;
    let transitionTimer: ReturnType<typeof setTimeout> | undefined;
    const interval = window.setInterval(() => {
      setSlide((current) => {
        const next = (current.current + 1) % photos.length;
        const direction = flow === "alternate"
          ? (next % 2 === 0 ? "left" : "right")
          : flow === "left-to-right" ? "left" : "right";
        return { current: next, previous: current.current, direction, moving: true };
      });
      if (transitionTimer) clearTimeout(transitionTimer);
      transitionTimer = setTimeout(() => {
        setSlide((current) => ({ ...current, previous: null, moving: false }));
      }, 1800);
    }, 3800);
    return () => {
      window.clearInterval(interval);
      if (transitionTimer) clearTimeout(transitionTimer);
    };
  }, [inView, tabVisible, reducedMotion, photos.length, flow]);

  useEffect(() => {
    const onVisibility = () => setTabVisible(!document.hidden);
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, []);

  const current = photos[slide.current];
  if (!current) return null;

  return (
    <div ref={stageRef} className={`intro-photo-flow ${className}`.trim()} role="img" aria-label={label}>
      {slide.previous !== null && slide.moving && (
        <Image
          key={`previous-${slide.previous}`}
          className={`intro-photo-flow-image intro-photo-flow-outgoing intro-photo-flow-out-${slide.direction === "left" ? "right" : "left"}`}
          src={photos[slide.previous].src}
          alt=""
          fill
          sizes="100vw"
          priority
          aria-hidden="true"
        />
      )}
      <Image
        key={`current-${slide.current}`}
        className={`intro-photo-flow-image${slide.moving ? ` intro-photo-flow-in intro-photo-flow-in-${slide.direction}` : ""}`}
        src={current.src}
        alt=""
        fill
        sizes="100vw"
        priority={slide.current === 0}
        aria-hidden="true"
      />
    </div>
  );
}
