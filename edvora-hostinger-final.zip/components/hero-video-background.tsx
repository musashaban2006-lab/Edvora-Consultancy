export function HeroVideoBackground() {
  return (
    <video className="hero-video-background" autoPlay muted loop playsInline preload="auto" aria-hidden="true">
      <source src="/videos/edvora-hero.mp4" type="video/mp4" />
    </video>
  );
}
