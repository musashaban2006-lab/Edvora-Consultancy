"use client";

import { FormEvent, useEffect, useState } from "react";
import { ArrowUpRight, CalendarDays, Check, LoaderCircle, X } from "lucide-react";

function localToday() {
  const date = new Date();
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return date.toISOString().slice(0, 10);
}

export function MockTestBooking({ className = "button button-orange" }: { className?: string }) {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "warning" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("sending");
    setMessage("");
    const form = event.currentTarget;
    try {
      const response = await fetch("/api/mock-test-bookings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(form))) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Please try again.");
      setStatus(result.notificationStatus === "sent" ? "success" : "warning");
      setMessage(result.notificationStatus === "sent"
        ? "Your request was saved and the notification workflow accepted it. The advisor team will confirm your preferred slot using the contact details you provided."
        : "Your request was saved, but the advisor notification could not be confirmed. Please contact Edvora directly to make sure we see it.");
      form.reset();
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "We couldn’t send your request. Please try again.");
    }
  }

  return <>
    <button type="button" className={className} onClick={() => { setOpen(true); setStatus("idle"); setMessage(""); }}><CalendarDays size={17}/> Book a free mock test <ArrowUpRight size={16}/></button>
    {open && <div className="mock-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false); }}>
      <section className="mock-modal" role="dialog" aria-modal="true" aria-labelledby="mock-modal-title">
        <button type="button" className="mock-modal-close" aria-label="Close booking form" onClick={() => setOpen(false)}><X size={20}/></button>
        <span className="eyebrow">FREE TEST SESSION · 30 MINUTES</span>
        <h2 id="mock-modal-title">Choose a time to <em>get started.</em></h2>
        <p className="mock-modal-lead">Pick your test and a preferred slot. An advisor will confirm availability.</p>
        <form className="mock-booking-form" onSubmit={submit}>
          <label>Full name<input name="name" autoComplete="name" placeholder="Your name" minLength={2} maxLength={100} required/></label>
          <div className="mock-form-row"><label>Email<input name="email" type="email" autoComplete="email" placeholder="you@example.com" required/></label><label>WhatsApp number<input name="phone" type="tel" autoComplete="tel" placeholder="+92 3XX XXXXXXX" minLength={7} maxLength={40} required/></label></div>
          <div className="mock-form-row"><label>Test<select name="test" defaultValue="IELTS" required><option>IELTS</option><option>PTE Academic</option><option>Oxford ELLT</option></select></label><label>Preferred date<input name="date" type="date" min={localToday()} required/></label></div>
          <label>Preferred time (Pakistan time)<select name="time" defaultValue="" required><option value="" disabled>Select a time</option><option value="10:00">10:00 AM</option><option value="12:00">12:00 PM</option><option value="14:00">2:00 PM</option><option value="16:00">4:00 PM</option><option value="18:00">6:00 PM</option></select></label>
          <label>Target score (optional)<input name="target_score" placeholder="e.g. IELTS 7+, PTE 75+, Oxford ELLT 8–9" maxLength={80}/></label>
          <label className="mock-consent"><input name="contact_consent" type="checkbox" required/><span>Edvora may contact me about this booking by email and WhatsApp.</span></label>
          <button className="button button-orange mock-submit" disabled={status === "sending"}>{status === "sending" ? <><LoaderCircle size={16} className="spin"/> Sending request…</> : status === "success" ? <><Check size={17}/> Request sent</> : <>Request this slot <ArrowUpRight size={16}/></>}</button>
          {message && <p className={`mock-message ${status}`} role="status">{message}</p>}
          <small className="mock-timezone-note">Your preferred time is recorded in Pakistan Standard Time (PKT). We’ll confirm the exact slot with you.</small>
        </form>
      </section>
    </div>}
  </>;
}
