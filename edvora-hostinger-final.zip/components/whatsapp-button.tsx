"use client";

import { MessageCircle } from "lucide-react";
import { edvoraContact } from "@/lib/site-config";

export function WhatsAppButton() {
  const phoneNumber = process.env.NEXT_PUBLIC_EDVORA_WHATSAPP || edvoraContact.whatsapp;
  const message = encodeURIComponent(
    "Hello Edvora! I'm interested in studying abroad and would like guidance on universities and student budgets."
  );

  return (
    <aside aria-label="Quick WhatsApp support" className="whatsapp-floating-wrap">
      <a
        href={`https://wa.me/${phoneNumber.replace(/\D/g, "")}?text=${message}`}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float-btn"
        aria-label="Chat with an Edvora Advisor on WhatsApp"
      >
        <span className="whatsapp-pulse" aria-hidden="true" />
        <MessageCircle size={24} className="whatsapp-icon" />
        <span className="whatsapp-tooltip">Chat with Advisor</span>
      </a>
    </aside>
  );
}
