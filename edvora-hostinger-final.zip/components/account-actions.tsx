"use client";

import { useState } from "react";
import { LogOut, Trash2 } from "lucide-react";
import { createClient } from "@/lib/supabase/browser";

export function AccountActions() {
  const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  async function signOut() { const client = createClient(); await client?.auth.signOut(); window.location.href = "/"; }
  async function deleteAccount() {
    if (!window.confirm("Permanently delete your Edvora account, saved items, and consultation requests submitted while signed in? This cannot be undone.")) return;
    setBusy(true); setMessage(""); const response = await fetch("/api/account", { method: "DELETE" }); const data = await response.json();
    if (!response.ok) { setMessage(data.error ?? "Could not delete the account."); setBusy(false); return; }
    await createClient()?.auth.signOut(); window.location.href = "/";
  }
  return <div className="account-actions"><button className="outline-button" onClick={signOut}><LogOut size={15}/> Sign out</button><button className="delete-button" disabled={busy} onClick={deleteAccount}><Trash2 size={15}/> {busy ? "Deleting…" : "Delete account"}</button>{message && <p className="form-message error">{message}</p>}</div>;
}
