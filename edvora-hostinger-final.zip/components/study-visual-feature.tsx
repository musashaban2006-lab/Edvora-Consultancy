import Image from "next/image";
import { FileCheck2 } from "lucide-react";

export function StudyVisualFeature() {
  return (
    <section className="study-visual-section" aria-labelledby="study-visual-heading">
      <div className="shell">
        <div className="study-visual-card">
          <div className="study-visual-photo">
            <Image
              src="/images/universities/showcase/illustrative-campus-students.jpg"
              alt="Two students talking outside a university building"
              fill
              sizes="(max-width: 760px) 100vw, 50vw"
            />
          </div>
          <div className="study-visual-copy">
            <span className="eyebrow">YOUR NEXT CHAPTER</span>
            <h2 id="study-visual-heading">A little planning can make the journey feel clearer.</h2>
            <p>Explore your options, gather your academic records, and talk through the next steps with an Edvora advisor.</p>
            <div className="study-document-art" aria-label="Illustration of an academic document checklist">
              <span className="study-document-cover" aria-hidden="true"><FileCheck2 size={22}/></span>
              <span><strong>Study document checklist</strong><small>Results · transcripts · certificates</small></span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
