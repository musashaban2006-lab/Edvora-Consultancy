"use client";

import { useEffect } from "react";
import "./scroll-reveal.css";

export function ScrollReveal() {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const sections = [...document.querySelectorAll<HTMLElement>("main > section, main section.shell")]
      .filter((section) => !section.classList.contains("home-hero") && !section.hasAttribute("data-edv-no-reveal"));
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add("edv-scroll-visible");
          observer.unobserve(entry.target);
        }
      }
    }, { threshold: 0.08, rootMargin: "0px 0px -36px 0px" });
    sections.forEach((section) => { section.classList.add("edv-scroll-reveal"); observer.observe(section); });
    return () => observer.disconnect();
  }, []);

  return null;
}
