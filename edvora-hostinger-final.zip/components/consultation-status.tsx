"use client";

import { useState } from "react";
import { Check, LoaderCircle } from "lucide-react";
export function ConsultationStatus({ id, initialStatus, initialNotes }: { id: string; initialStatus: string; initialNotes: string | null }) {
  const [status, setStatus] = useState(initialStatus); const [notes, setNotes] = useState(initialNotes ?? ""); const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true); setMessage("");
    const response = await fetch(`/api/consultations/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status, staff_notes: notes }) });
    const result = await response.json(); setBusy(false); setMessage(response.ok ? "Saved" : result.error ?? "Could not save");
  }
  return <div className="dashboard-actions"><select value={status} onChange={(event) => setStatus(event.target.value)} aria-label="Enquiry status"><option value="new">New</option><option value="contacted">Contacted</option><option value="closed">Closed</option></select><input value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Staff note" aria-label="Staff note"/><button onClick={save} disabled={busy}>{busy ? <LoaderCircle className="spin" size={15}/> : <Check size={15}/>} {busy ? "Saving" : "Save"}</button>{message && <small>{message}</small>}</div>;
}
