import Link from "next/link";
import type { University } from "@/lib/data";
import { UniversityLogo } from "@/components/university-logo";
import { PhotoFallback } from "@/components/photo-fallback";
import "./university-showcase.css";

export function UniversityShowcase({ universities }: { universities: University[] }) {
  const selected = universities.filter((university) => university.featured || ["uk", "sweden", "turkey", "south-cyprus", "romania", "germany", "italy"].includes(university.countrySlug));
  const rows = [selected.filter((_, index) => index % 3 === 0), selected.filter((_, index) => index % 3 === 1), selected.filter((_, index) => index % 3 === 2)];
  return <section className="uni-showcase-section" aria-labelledby="uni-showcase-title">
    <div className="shell uni-showcase-heading"><span className="eyebrow">CAMPUS SPOTLIGHT</span><h2 id="uni-showcase-title">Explore places to <em>learn.</em></h2><p>See institutions across Edvora’s study destinations. Listings are informational and do not imply a university partnership.</p></div>
    <div className="uni-showcase-rows" aria-label="Moving university and city photo rows">
      {rows.map((row, rowIndex) => row.length ? <div className={`uni-showcase-track uni-showcase-track-${rowIndex + 1}`} key={rowIndex}><div className="uni-showcase-run">{[...row, ...row].map((university, index) => <div className="uni-showcase-tile" key={`${university.id}-${index}`}><Link className={`uni-showcase-card${university.photoTier && university.photoTier !== "named" ? " photo-placeholder" : ""}`} href={`/universities/${university.slug ?? university.id}`}>
        <PhotoFallback src={university.image} alt={university.photoAlt ?? (university.imageIsIllustrative ? `Illustrative campus photo; not a photograph of ${university.name}` : `${university.name} campus`)} label={university.name.split(/\s+/).map((part) => part[0]).slice(0, 3).join("").toUpperCase()} className="uni-showcase-photo" sizes="(max-width: 760px) 75vw, 340px" />
        <span className="uni-showcase-overlay"><UniversityLogo name={university.name} slug={university.slug ?? university.id} size={32}/><span><strong>{university.name}</strong><small>{university.country}{university.photoTier === "city" ? " · City view" : university.photoTier === "generic" ? " · Campus placeholder" : ""}</small></span></span>
      </Link>{university.photoPageUrl && <small className="photo-attribution uni-showcase-credit">Photo: <a href={university.photoPageUrl} target="_blank" rel="noreferrer">{university.photoArtist}</a>{university.photoLicense && <> · <a href={university.photoLicenseUrl} target="_blank" rel="noreferrer">{university.photoLicense}</a></>}</small>}</div>)}</div></div> : null)}
    </div>
  </section>;
}
