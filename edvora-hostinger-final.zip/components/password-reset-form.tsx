"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowUpRight, LoaderCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/browser";
export function PasswordResetForm() {
  const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false); const router = useRouter();
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const password = String(new FormData(event.currentTarget).get("password")); const client = createClient();
    if (!client) { setMessage("Connect Supabase to update your password."); return; }
    setBusy(true); const { error } = await client.auth.updateUser({ password }); setBusy(false);
    if (error) { setMessage(error.message); return; }
    setMessage("Your password has been updated."); setTimeout(() => router.push("/login"), 1000);
  }
  return <form className="auth-form" onSubmit={submit}><label>New password<input name="password" type="password" minLength={8} autoComplete="new-password" required placeholder="At least 8 characters"/></label>{message && <p className="form-message">{message}</p>}<button className="button button-orange form-submit" disabled={busy}>{busy ? <><LoaderCircle className="spin" size={16}/> Updating…</> : <>Set new password <ArrowUpRight size={16}/></>}</button></form>;
}
