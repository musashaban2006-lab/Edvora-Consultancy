"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, ArrowUpRight, Bookmark, Facebook, Instagram } from "lucide-react";
import Image from "next/image";
import { edvoraContact } from "@/lib/site-config";

const links = [
  ["Home", "/"],
  ["Destinations", "/countries"],
  ["My journey", "/journey"],
  ["Budget Guide", "/budget"],
  ["Courses", "/courses"],
  ["Testimonials", "/stories"],
  ["About", "/about"],
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="top-note">
        <span className="tiny-dot" /> Your next chapter starts with a good conversation.{" "}
        <Link href="/contact">
          Talk to an advisor <ArrowUpRight size={13} />
        </Link>
      </div>
      <div className="nav-wrap">
        <Link className="brand" href="/" aria-label="Edvora home">
          <Image src="/edvora-logo-exact.jpeg" alt="Edvora — Your Global Educational Partner" width={300} height={169} priority />
        </Link>
        <nav className={open ? "main-nav nav-open" : "main-nav"} aria-label="Main navigation">
          {links.map(([label, href]) => (
            <Link onClick={() => setOpen(false)} key={href} href={href}>
              {label}
            </Link>
          ))}
          <Link className="mobile-auth" href="/login">
            Sign in
          </Link>
        </nav>
        <div className="nav-actions">
          <Link className="nav-login" href="/saved">
            <Bookmark size={15} /> Saved
          </Link>
          <Link className="button button-dark nav-cta" href="/contact">
            Book a consultation <ArrowUpRight size={16} />
          </Link>
        </div>
        <button
          className="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-main">
        <div className="footer-brand">
          <Link className="brand brand-light" href="/">
            <Image src="/edvora-logo-exact.jpeg" alt="Edvora — Your Global Educational Partner" width={300} height={169} />
          </Link>
          <p>A thoughtful first step toward your global education journey.</p>
          <Link className="footer-contact" href="/contact">
            Let’s talk about your plans <ArrowUpRight size={16} />
          </Link>
        </div>
        <div>
          <h3>Explore</h3>
          <Link href="/about">About Edvora</Link>
          <Link href="/countries">Study destinations</Link>
          <Link href="/budget">Student budget guide</Link>
          <Link href="/journey">My journey</Link>
          <Link href="/stories">Testimonials</Link>
        </div>
        <div>
          <h3>How we help</h3>
          <Link href="/courses">English test courses</Link>
          <Link href="/services">Application guidance</Link>
          <Link href="/services">Visa preparation</Link>
          <Link href="/contact">Book a consultation</Link>
        </div>
        <div>
          <h3>Get in touch</h3>
          <a href={`tel:${edvoraContact.phoneInternational}`}>{edvoraContact.phoneDisplay}</a>
          <a href={`mailto:${edvoraContact.email}`}>{edvoraContact.email}</a>
          <Link href="/contact">Contact Edvora</Link>
          <Link href="/saved">Saved items</Link>
          <Link href="/login">Student sign in</Link>
          <Link href="/signup">Create an account</Link>
          <Link href="/dashboard">Staff portal</Link>
          <div className="footer-socials" aria-label="Edvora social media">
            <a href="https://www.instagram.com/edvorainternational/" target="_blank" rel="noopener noreferrer" aria-label="Edvora on Instagram"><Instagram size={16} /> Instagram</a>
            <a href="https://www.facebook.com/share/1Dga3B21bt/" target="_blank" rel="noopener noreferrer" aria-label="Edvora on Facebook"><Facebook size={16} /> Facebook</a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Edvora. All rights reserved.</span>
        <span>Admissions and visa decisions are made by the relevant institutions and authorities.</span>
        <a href="https://commons.wikimedia.org/" target="_blank" rel="noreferrer">Photos via Wikimedia Commons</a>
        <a href="https://www.pexels.com/" target="_blank" rel="noreferrer">Some illustrative photos via Pexels</a>
        <Link href="/privacy">Privacy</Link>
      </div>
    </footer>
  );
}
