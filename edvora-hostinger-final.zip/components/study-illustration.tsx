export function StudyIllustration({ className = "" }: { className?: string }) {
  return <svg className={`study-illustration ${className}`} viewBox="0 0 180 150" fill="none" aria-hidden="true">
    <circle cx="100" cy="73" r="48" stroke="currentColor" strokeWidth="1.5" opacity=".16" />
    <ellipse cx="100" cy="73" rx="21" ry="48" stroke="currentColor" strokeWidth="1.5" opacity=".16" />
    <path d="M53 73h94M61 51c22 10 56 10 78 0M61 95c22-10 56-10 78 0" stroke="currentColor" strokeWidth="1.5" opacity=".16" />
    <path d="M28 110c13-19 29-27 50-29l14 25c-22 1-39 8-51 21z" fill="currentColor" opacity=".1" />
    <path d="m39 115 14-18 14 20M52 97l27-16 10 24-22 12" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" opacity=".58" />
    <path d="M20 41c24-25 51-32 78-22" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 5" opacity=".35" />
    <path d="m94 14 6 4-7 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" opacity=".55" />
    <circle cx="145" cy="28" r="5" fill="#24bad2" opacity=".8" />
  </svg>;
}
