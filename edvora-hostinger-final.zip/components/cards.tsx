import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, MapPin, ArrowRight } from "lucide-react";
import type { Country, University, Story } from "@/lib/data";
import { BookmarkButton } from "@/components/bookmark-button";
import { UniversityLogo } from "@/components/university-logo";
import { PhotoFallback } from "@/components/photo-fallback";

export function CountryCard({ country, index = 0, saved = false }: { country: Country; index?: number; saved?: boolean }) {
  return <article className={`country-card country-card-${index % 3}`} style={{ "--card-accent": country.accent } as React.CSSProperties}>
    <PhotoFallback src={country.image} alt={`${country.name} study destination`} label={country.name} sizes="(max-width: 700px) 90vw, 30vw" className="cover-image" />
    <Link className="country-card-main" href={`/countries/${country.slug}`} aria-label={`Explore universities and study information for ${country.name}`}><span className="country-index">0{index + 1}</span><span className="country-region">{country.region}</span><span className="country-card-bottom"><span><strong>{country.name}</strong><small>{country.tagline}</small></span><span className="round-arrow"><ArrowUpRight size={18}/></span></span></Link>
    <span className="country-save"><BookmarkButton kind="country" id={country.slug} initialSaved={saved}/></span>
  </article>;
}

export function UniversityCard({ university, saved = false }: { university: University; saved?: boolean }) {
  const imageAlt = university.photoAlt ?? (university.imageIsIllustrative ? `Illustrative campus photo; not a photograph of ${university.name}` : `${university.name} campus`);
  const photoBadge = university.photoTier === "city" ? "City view · illustrative" : university.photoTier === "generic" ? "Campus placeholder" : university.imageIsIllustrative ? "Illustrative photo" : university.sourceUrl ? "Source listing" : university.sample ? "Illustrative example" : null;
  return <article className="university-card">
    <Link className={`university-image${university.photoTier && university.photoTier !== "named" ? " photo-placeholder" : ""}`} href={`/universities/${university.slug ?? university.id}`}><PhotoFallback src={university.image} alt={imageAlt} label={university.name.split(/\s+/).map((part) => part[0]).slice(0, 3).join("").toUpperCase()} sizes="(max-width: 700px) 90vw, 30vw" className="cover-image"/>{photoBadge && <span className="sample-university-pill">{photoBadge}</span>}<span className="image-arrow"><ArrowUpRight size={17}/></span></Link>
    {university.photoPageUrl && <small className="photo-attribution">Photo: <a href={university.photoPageUrl} target="_blank" rel="noreferrer">{university.photoArtist}</a>{university.photoLicense && <> · <a href={university.photoLicenseUrl} target="_blank" rel="noreferrer">{university.photoLicense}</a></>}</small>}
    <div className="university-meta"><span>{university.type}</span>{university.city && <span><MapPin size={12}/>{university.city}</span>}</div>
    <div className="university-card-title-row">
      <UniversityLogo name={university.name} slug={university.slug ?? university.id} size={36} />
      <h3><Link href={`/universities/${university.slug ?? university.id}`}>{university.name}</Link></h3>
    </div>
    <p>{university.description}</p>
    <div className="card-foot"><Link href={`/countries/${university.countrySlug}`}>{university.country}</Link><BookmarkButton kind="university" id={university.slug ?? university.id} initialSaved={saved}/></div>
  </article>;
}

export function StoryCard({ story }: { story: Story }) {
  return <article className="story-card"><div className="story-photo"><Image src={story.image} alt={`Student story: ${story.name}`} fill sizes="(max-width: 700px) 90vw, 30vw" className="cover-image"/><span className="story-play">✳</span></div><div className="story-body"><span className="eyebrow">{story.country} <span>·</span> {story.outcome}</span><blockquote>“{story.quote}”</blockquote><div className="story-person"><span className="avatar">{story.initials}</span><span><strong>{story.name}</strong><small>{story.sample ? "Sample story" : "Edvora student"}</small></span><ArrowUpRight size={16}/></div></div></article>;
}

export function SectionHeading({ kicker, title, text, href, linkText }: { kicker: string; title: string; text?: string; href?: string; linkText?: string }) {
  return <div className="section-heading"><div><span className="eyebrow">{kicker}</span><h2>{title}</h2>{text && <p>{text}</p>}</div>{href && <Link className="text-arrow section-link" href={href}>{linkText ?? "Explore all"}<ArrowRight size={16}/></Link>}</div>;
}
