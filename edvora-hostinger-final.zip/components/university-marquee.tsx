import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { University } from "@/lib/data";
import { UniversityLogo } from "@/components/university-logo";

export function UniversityMarquee({ universities, leftToRightOnly = false }: { universities: University[]; leftToRightOnly?: boolean }) {
  const destinations = ["uk", "sweden", "turkey", "south-cyprus", "romania", "germany", "italy", "china"];

  // Select top institutions across all destinations
  const list = destinations.flatMap((slug) =>
    universities.filter((item) => item.countrySlug === slug).slice(0, 4)
  );

  // Split into 3 balanced rows
  const row1 = list.filter((_, i) => i % 3 === 0);
  const row2 = list.filter((_, i) => i % 3 === 1);
  const row3 = list.filter((_, i) => i % 3 === 2);
  const rows = [row1, row2, row3];

  return (
    <section className={`university-marquee-section${leftToRightOnly ? " university-marquee-left-only" : ""}`}>
      <div className="shell marquee-heading">
        <div>
          <div className="inline-flex items-center gap-2 mb-2">
            <span className="eyebrow m-0">GLOBAL DESTINATION DIRECTORY</span>
            <span className="marquee-live-indicator">
              <span className="live-dot" />
              Interactive Directory
            </span>
          </div>
          <h2>
            Find your place <em>to grow.</em>
          </h2>
          <p>
            Explore universities across the top destinations Edvora students choose. Hover over any institution to pause.
          </p>
        </div>
        <Link className="text-arrow" href="/countries">
          Explore destinations <ArrowUpRight size={16} />
        </Link>
      </div>

      <div
        className="marquee-rows"
        aria-label="Floating university names and logos across 3 animated rows"
      >
        {rows.map((row, i) => {
          if (!row.length) return null;
          // Duplicate items 3 times for a continuous, uninterrupted infinite loop
          const loopItems = [...row, ...row, ...row];
          const directionLabel = i === 1 ? "Moving Right to Left" : "Moving Left to Right";

          return (
            <div
              className={`marquee-track marquee-track-${i + 1}`}
              key={i}
              title={`Row ${i + 1} (${directionLabel}) - Hover to pause`}
            >
              <div className="marquee-run">
                {loopItems.map((item, index) => {
                  return (
                    <Link
                      className="marquee-chip"
                      href={`/universities/${item.slug ?? item.id}`}
                      key={`${item.id}-${index}`}
                    >
                      <UniversityLogo name={item.name} slug={item.slug ?? item.id} size={36} />
                      <div className="marquee-content">
                        <span className="marquee-name">{item.name}</span>
                        <span className="marquee-country-tag">{item.country}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
