"use client";

import Image from "next/image";
import { useState } from "react";

export function UniversityLogo({
  name,
  slug,
  size = 38,
}: {
  name: string;
  slug: string;
  size?: number;
}) {
  const [failed, setFailed] = useState(false);
  const cleanName = name.replace(/^(University of |University |The |Technical University of |Polytechnic University of )/i, "");
  const words = cleanName.trim().split(/\s+/);
  const initials = (words.length > 1 ? words[0][0] + words[1][0] : cleanName.slice(0, 2)).toUpperCase();

  if (failed) {
    return <span className="university-logo university-logo-fallback" style={{ width: size, height: size }} aria-label={`${name} logo placeholder`} title={`${name} logo`}>{initials}</span>;
  }

  return <span className="university-logo" style={{ width: size, height: size }} title={`${name} logo`}>
    <Image src={`/images/university-logos/${slug}.png`} alt={`${name} logo`} width={Math.round(size * 0.72)} height={Math.round(size * 0.72)} unoptimized onError={() => setFailed(true)} />
  </span>;
}
