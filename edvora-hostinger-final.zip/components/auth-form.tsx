"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, LoaderCircle, MailCheck } from "lucide-react";
import { createClient } from "@/lib/supabase/browser";

export function AuthForm({ mode, next = "/saved" }: { mode: "login" | "signup"; next?: string }) {
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState(""); const [success, setSuccess] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage(""); const supabase = createClient();
    if (!supabase) { setMessage("Account sign-in will be available after Supabase is connected. See the setup guide."); setBusy(false); return; }
    const form = event.currentTarget; const formData = new FormData(form); const email = String(formData.get("email")); const password = String(formData.get("password")); const displayName = String(formData.get("display_name") ?? "");
    const result = mode === "signup"
      ? await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName }, emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}` } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) { setMessage(result.error.message); return; }
    if (mode === "signup") { setSuccess(true); setMessage("Check your email to verify your address and finish creating your account."); }
    else window.location.href = next.startsWith("/") ? next : "/saved";
  }
  return <div className="auth-card"><span className="eyebrow">{mode === "login" ? "WELCOME BACK" : "YOUR NEXT CHAPTER"}</span><h1>{mode === "login" ? <>Good to see<br/><em>you again.</em></> : <>Save what<br/><em>inspires you.</em></>}</h1><p>{mode === "login" ? "Sign in to see your saved universities." : "Create an account to keep track of the universities you’re exploring."}</p>
    {success ? <div className="auth-success"><MailCheck size={25}/><p>{message}</p><Link href="/login" className="text-arrow">Back to sign in <ArrowUpRight size={15}/></Link></div> : <form className="auth-form" onSubmit={submit}>{mode === "signup" && <label>Your name<input name="display_name" autoComplete="name" required minLength={2} placeholder="Your name"/></label>}<label>Email address<input name="email" type="email" autoComplete="email" required placeholder="you@example.com"/></label><label>Password<input name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={8} required placeholder="At least 8 characters"/></label>{message && <p className="form-message error">{message}</p>}<button className="button button-orange form-submit" disabled={busy}>{busy ? <><LoaderCircle className="spin" size={16}/> Please wait…</> : mode === "login" ? <>Sign in <ArrowUpRight size={16}/></> : <>Create account <ArrowUpRight size={16}/></>}</button>{mode === "login" && <button className="text-button" type="button" onClick={async () => { const formElement = document.querySelector<HTMLFormElement>(".auth-form"); const emailValue = formElement ? new FormData(formElement).get("email") : null; const supabaseClient = createClient(); if (!emailValue || !supabaseClient) { setMessage("Enter your email address first, and make sure Supabase is connected."); return; } const { error } = await supabaseClient.auth.resetPasswordForEmail(String(emailValue), { redirectTo: `${window.location.origin}/auth/callback?next=/reset-password` }); setMessage(error?.message ?? "If that email has an account, a password reset link is on its way."); }}>Forgot password?</button>}</form>}
    {!success && <div className="auth-switch">{mode === "login" ? <>New to Edvora? <Link href="/signup">Create an account</Link></> : <>Already have an account? <Link href="/login">Sign in</Link></>}</div>}
  </div>;
}
