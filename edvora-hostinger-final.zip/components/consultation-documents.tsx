"use client";

import { useState } from "react";
import { Download, LoaderCircle } from "lucide-react";

type Document = { id: string; filename: string; size_bytes: number; url: string | null };

export function ConsultationDocuments({ consultationId }: { consultationId: string }) {
  const [documents, setDocuments] = useState<Document[] | null>(null);
  const [loading, setLoading] = useState(false);
  async function load() {
    setLoading(true);
    try {
      const response = await fetch(`/api/consultations/${consultationId}/documents`, { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Could not load files.");
      setDocuments(result.documents);
    } finally { setLoading(false); }
  }
  return <div className="enquiry-documents"><button type="button" className="text-arrow" onClick={load} disabled={loading}>{loading ? <LoaderCircle size={14} className="spin"/> : <Download size={14}/>} {documents ? "Refresh secure links" : "View academic documents"}</button>{documents?.map((document) => <a key={document.id} href={document.url ?? undefined} target="_blank" rel="noreferrer">{document.filename} · {(document.size_bytes / 1024 / 1024).toFixed(1)} MB <Download size={13}/></a>)}</div>;
}
