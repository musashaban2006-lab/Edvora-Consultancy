import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, MapPin } from "lucide-react";
import type { University } from "@/lib/data";
import type { CountryCity } from "@/lib/country-cities";
import { normalizeCity } from "@/lib/country-cities";

export function CountryCitySection({ cities, universities }: { cities: CountryCity[]; universities: University[] }) {
  return (
    <section className="section shell country-city-section">
      <div className="section-heading">
        <div><span className="eyebrow">CITIES TO EXPLORE</span><h2>Find a place that <em>fits.</em></h2><p>Browse the cities represented in this directory and see university listings in each location.</p></div>
      </div>
      <div className="country-city-grid">
        {cities.map((city) => {
          const matches = universities.filter((university) => normalizeCity(university.city) === normalizeCity(city.name));
          return (
            <article className="country-city-card" key={city.name}>
              <div className="country-city-photo"><Image src={city.image} alt={city.imageAlt ?? `${city.name} city view`} fill sizes="(max-width: 700px) 90vw, 32vw" className="cover-image" /></div>
              <div className="country-city-body"><span className="city-label"><MapPin size={14} /> CITY / {city.name.toUpperCase()}</span><p>{city.description}</p>
                {matches.length ? <ul>{matches.map((university) => <li key={university.id}><Link href={`/universities/${university.slug ?? university.id}`}>{university.name}<ArrowUpRight size={14}/></Link></li>)}</ul> : <p className="city-empty">No university directory listings currently show this city.</p>}
              </div>
            </article>
          );
        })}
      </div>
      <p className="country-city-disclaimer">Directory entries are informational. Confirm course availability, campus location, fees, and admission details with the university.</p>
    </section>
  );
}
