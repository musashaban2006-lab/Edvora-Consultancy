"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import "./edv-3d-country-carousel.css";

const destinations = [
  { name: "UK", images: ["/images/countries/uk.jpg", "/images/countries/cities/london.jpg"] },
  { name: "Sweden", images: ["/images/countries/sweden.jpg"] },
  { name: "Turkey", images: ["/images/countries/turkey.jpg", "/images/countries/cities/istanbul-blue-mosque.jpg"] },
  { name: "South Cyprus", images: ["/images/countries/south-cyprus.jpg", "/images/countries/cities/mediterranean-harbor.jpg"] },
  { name: "Romania", images: [] },
  { name: "Germany", images: ["/images/countries/germany.jpg", "/images/countries/cities/frankfurt.jpg"] },
  { name: "Italy", images: ["/images/countries/italy.jpg", "/images/countries/cities/venice.jpg"] },
  { name: "Finland", images: ["/images/countries/finland.jpg", "/images/countries/cities/lapland-aurora.jpg"] },
  { name: "China", images: ["/images/countries/china.jpg", "/images/countries/cities/great-wall.jpg"] },
];

export function EdvoraHeroCarousel() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [scrollTurn, setScrollTurn] = useState(0);
  const [photoTurn, setPhotoTurn] = useState(0);
  const pointerStart = useRef<number | null>(null);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (paused || reducedMotion) return;
    const timer = window.setInterval(() => setActive((index) => (index + 1) % destinations.length), 5200);
    return () => window.clearInterval(timer);
  }, [paused, reducedMotion]);

  useEffect(() => {
    if (reducedMotion) return;
    const timer = window.setInterval(() => setPhotoTurn((index) => index + 1), 6800);
    return () => window.clearInterval(timer);
  }, [reducedMotion]);

  useEffect(() => {
    let frame = 0;
    const handleScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => setScrollTurn(Math.round(window.scrollY / 700)));
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => { cancelAnimationFrame(frame); window.removeEventListener("scroll", handleScroll); };
  }, []);

  const cards = useMemo(() => destinations.map((item, index) => {
    const offset = ((index - active + destinations.length + Math.floor(destinations.length / 2)) % destinations.length) - Math.floor(destinations.length / 2);
    const depth = Math.max(190, 390 - Math.abs(offset) * 10);
    const scale = Math.max(0.62, 1 - Math.abs(offset) * 0.085);
    return { ...item, index, offset, depth, scale };
  }), [active]);

  const move = (delta: number) => setActive((index) => (index + delta + destinations.length) % destinations.length);

  return (
    <div
      className={`edv-3d-carousel${reducedMotion ? " edv-3d-static" : ""}`}
      role="region"
      aria-roledescription="carousel"
      aria-label="Edvora study destinations"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={(event) => { pointerStart.current = event.touches[0]?.clientX ?? null; }}
      onTouchEnd={(event) => {
        const start = pointerStart.current;
        const end = event.changedTouches[0]?.clientX;
        if (start !== null && end !== undefined && Math.abs(end - start) > 42) move(end < start ? 1 : -1);
        pointerStart.current = null;
      }}
    >
      <div className="edv-3d-scene" style={{ "--edv-3d-scroll-turn": scrollTurn } as React.CSSProperties}>
        {cards.map((card) => (
          <article
            className={`edv-3d-card${card.offset === 0 ? " edv-3d-card-front" : ""}`}
            key={card.name}
            aria-hidden={Math.abs(card.offset) > 2}
            style={{
              "--edv-3d-index": card.index,
              "--edv-3d-depth": `${card.depth}px`,
              "--edv-3d-scale": card.scale,
              "--edv-3d-angle": `${card.offset * 18}deg`,
              "--edv-3d-opacity": Math.max(0.35, 1 - Math.abs(card.offset) * 0.18),
              zIndex: destinations.length - Math.abs(card.offset),
            } as React.CSSProperties}
            onMouseMove={(event) => {
              if (reducedMotion || window.matchMedia("(hover: none)").matches) return;
              const rect = event.currentTarget.getBoundingClientRect();
              event.currentTarget.style.setProperty("--edv-3d-tilt-x", `${((event.clientY - rect.top) / rect.height - 0.5) * -7}deg`);
              event.currentTarget.style.setProperty("--edv-3d-tilt-y", `${((event.clientX - rect.left) / rect.width - 0.5) * 7}deg`);
            }}
            onMouseLeave={(event) => {
              event.currentTarget.style.setProperty("--edv-3d-tilt-x", "0deg");
              event.currentTarget.style.setProperty("--edv-3d-tilt-y", "0deg");
            }}
          >
            <div className="edv-3d-card-image">
              {card.images.length > 0 && <img key={card.images[photoTurn % card.images.length]} src={card.images[photoTurn % card.images.length]} alt={`${card.name} study destination`} loading="lazy"
                onLoad={(event) => event.currentTarget.parentElement?.classList.add("edv-3d-image-loaded")}
                onError={(event) => {
                  event.currentTarget.remove();
                  event.currentTarget.parentElement?.classList.remove("edv-3d-image-loaded");
                }} />}
              <span className="edv-3d-image-fallback" aria-hidden="true">{card.name}</span>
            </div>
            <span className="edv-3d-country-label">{card.name}</span>
          </article>
        ))}
      </div>
      <div className="edv-3d-controls" aria-label="Choose destination carousel position">
        <button type="button" onClick={() => move(-1)} aria-label="Previous country">←</button>
        <span>{String(active + 1).padStart(2, "0")} <i>/</i> {String(destinations.length).padStart(2, "0")}</span>
        <button type="button" onClick={() => move(1)} aria-label="Next country">→</button>
      </div>
    </div>
  );
}
