import { ArrowUpRight } from "lucide-react";

const stats = [["06", "study destinations"], ["01:01", "personal guidance"], ["YOUR", "journey, your way"]];

export function TrustStrip() {
  return <div className="trust-strip shell"><div className="trust-strip-label"><span className="eyebrow">A MORE PERSONAL WAY FORWARD</span><ArrowUpRight size={18}/></div>{stats.map(([number, label]) => <div className="trust-stat" key={label}><strong>{number}</strong><span>{label}</span></div>)}</div>;
}
