"use client";

import { useState } from "react";

export function MockBookingStatus({ id, initialStatus }: { id: string; initialStatus: string }) {
  const [status, setStatus] = useState(initialStatus);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  async function update(nextStatus: string) {
    setSaving(true);
    setError("");
    try {
      const response = await fetch(`/api/mock-test-bookings/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: nextStatus }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Could not update status.");
      setStatus(result.status);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Could not update status."); }
    finally { setSaving(false); }
  }
  return <div className="mock-booking-status"><label htmlFor={`mock-status-${id}`}>Follow-up status</label><select id={`mock-status-${id}`} value={status} onChange={(event) => void update(event.target.value)} disabled={saving}><option value="new">New</option><option value="contacted">Contacted</option><option value="closed">Closed</option></select>{error && <small role="alert">{error}</small>}</div>;
}
