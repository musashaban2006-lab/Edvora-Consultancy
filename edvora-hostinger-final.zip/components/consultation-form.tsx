"use client";

import { FormEvent, useMemo, useState } from "react";
import { ArrowUpRight, Check, LoaderCircle } from "lucide-react";
import { countries } from "@/lib/data";

type UniversityOption = { slug: string; name: string; countrySlug: string; city: string };
export function ConsultationForm({ universities, uploadsEnabled }: { universities: UniversityOption[]; uploadsEnabled: boolean }) {
  const [state, setState] = useState<"idle" | "loading" | "success" | "warning" | "error">("idle");
  const [message, setMessage] = useState("");
  const [destination, setDestination] = useState("");
  const matchingUniversities = useMemo(() => universities.filter((item) => item.countrySlug === destination), [universities, destination]);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setState("loading"); setMessage("");
    const form = event.currentTarget;
    try {
      const data = new FormData(form);
      const response = await fetch("/api/consultations", { method: "POST", body: data });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Please try again.");
      setState(result.notificationStatus === "sent" ? "success" : "warning");
      setMessage(result.notificationStatus === "sent"
        ? "Thanks — we’ve received your request and the notification workflow accepted it. The advisor team will follow up using the contact details you provided."
        : "Your request was saved, but the advisor notification could not be confirmed. Please contact Edvora directly to make sure we see it.");
      form.reset();
    } catch (error) { setState("error"); setMessage(error instanceof Error ? error.message : "Something went wrong. Please try again."); }
  }
  return <form className="consult-form" onSubmit={submit}>
    <div className="form-row"><label>Full name<input name="name" placeholder="e.g. Ayesha Khan" autoComplete="name" required minLength={2}/></label><label>Email address<input name="email" type="email" placeholder="you@example.com" autoComplete="email" required/></label></div>
    <div className="form-row"><label>Phone number<input name="phone" placeholder="+92 3XX XXXXXXX" autoComplete="tel" required minLength={7}/></label><label>Approx. annual budget (PKR)<select name="budget" defaultValue="" required><option value="" disabled>Select a budget range</option><option>Under PKR 1 million</option><option>PKR 1–2 million</option><option>PKR 2–4 million</option><option>Over PKR 4 million</option><option>Still exploring</option></select></label></div>
    <div className="form-row"><label>Preferred destination<select name="country_slug" value={destination} onChange={(event) => setDestination(event.target.value)} required><option value="" disabled>Choose a destination</option>{countries.map((country) => <option value={country.slug} key={country.slug}>{country.name}</option>)}</select></label><label>Study level<select name="study_level" defaultValue="" required><option value="" disabled>Select a level</option><option>Undergraduate</option><option>Postgraduate</option><option>Doctoral</option><option>Other</option></select></label></div>
    <div className="form-row consultation-mode-row"><label>Consultation preference<select name="consultation_mode" defaultValue="" required><option value="" disabled>Choose how you’d like to meet</option><option value="online">Online consultation</option><option value="in_person">In-person consultation (subject to availability)</option><option value="no_preference">No preference</option></select><small>We’ll confirm the meeting details when an advisor follows up.</small></label></div>
    <div className="form-row"><label>University of interest (optional)<select name="university_interest" defaultValue=""><option value="">I haven’t chosen yet</option><option value="Other">Other</option>{matchingUniversities.map((item) => <option value={item.name} key={item.slug}>{item.name}{item.city ? ` · ${item.city}` : ""}</option>)}</select></label><label>Academic documents (optional)<input name="documents" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" disabled={!uploadsEnabled} aria-describedby="upload-help"/><small id="upload-help">{uploadsEnabled ? "Result cards, transcripts or certificates. PDF, JPG or PNG; up to 6 files, 10 MB each (20 MB total)." : "Uploads are paused until the private storage key and bucket are configured on the server."}</small></label></div>
    {uploadsEnabled && <p className="form-privacy">Uploaded academic documents are visible to Edvora advisors for this enquiry and are deleted after 90 days.</p>}
    <label className="form-consent"><input name="consent" type="checkbox" required/><span>I agree that Edvora may contact me about my study plans. If I upload academic documents, Edvora advisors may access them for this enquiry; they will be deleted after 90 days. See the <a href="/privacy">privacy notice</a>.</span></label>
    <button className="button button-orange form-submit" disabled={state === "loading"}>{state === "loading" ? <><LoaderCircle className="spin" size={16}/> Sending…</> : state === "success" ? <><Check size={17}/> Request received</> : <>Send consultation request <ArrowUpRight size={17}/></>}</button>
    {message && <p className={`form-message ${state}`}>{message}</p>}
    <p className="form-privacy">Your information is only used to respond to your enquiry.</p>
  </form>;
}
