import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export function HomePassportFeature() {
  return (
    <section className="home-passport-feature" aria-labelledby="passport-feature-heading">
      <div className="shell home-passport-inner">
        <div className="home-passport-copy">
          <span className="eyebrow eyebrow-light">YOUR NEXT CHAPTER</span>
          <h2 id="passport-feature-heading">Dream beyond borders.<br/><em>Start with one step.</em></h2>
          <p>Every global story begins somewhere. Tell us what you hope to study, and we’ll help you map a thoughtful path forward.</p>
          <Link className="button button-white" href="/contact">Plan your next step <ArrowUpRight size={17}/></Link>
        </div>
        <div className="home-passport-art">
          <Image src="/images/study-abroad-passport.svg" alt="Illustration of an Edvora study-abroad booklet and a planning checklist" fill sizes="(max-width: 760px) 100vw, 52vw"/>
        </div>
      </div>
    </section>
  );
}
