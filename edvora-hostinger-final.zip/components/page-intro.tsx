import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import { IntroPhotoFlow, type IntroFlowPhoto } from "@/components/intro-photo-flow";
export function CountryIntro({ kicker, title, text, action = true, image, imageAlt, photoFlow, decoration = true }: { kicker: string; title: React.ReactNode; text: string; action?: boolean; image?: string; imageAlt?: string; photoFlow?: { photos: IntroFlowPhoto[]; label: string; flow?: "left-to-right" | "right-to-left" | "alternate"; theme?: "universities" | "destinations" }; decoration?: boolean }) {
  return <section className={`page-intro${photoFlow ? ` has-photo-flow page-intro--${photoFlow.theme ?? "universities"}-flow` : ""}`}>
    {photoFlow && <IntroPhotoFlow photos={photoFlow.photos} label={photoFlow.label} flow={photoFlow.flow} className="intro-photo-flow--orb"/>}
    <div className="shell page-intro-inner"><div><span className="eyebrow">{kicker}</span><h1>{title}</h1><p>{text}</p>{action && <Link className="button button-dark" href="/journey">Plan your journey <ArrowUpRight size={16}/></Link>}</div>
      {photoFlow ? null : image ? <span className="intro-image"><Image src={image} alt={imageAlt ?? ""} fill sizes="(max-width: 760px) 92px, 152px" className="cover-image"/></span> : decoration ? <span className="intro-seal">EDVORA<br/><small>GLOBAL EDUCATION</small><b>✳</b></span> : null}
    </div><div className="page-intro-bottom"><span>EDVORA / YOUR WORLD STARTS HERE</span><span>01 — 06</span></div></section>;
}
