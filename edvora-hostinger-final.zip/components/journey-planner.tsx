"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowDownToLine, ArrowUpRight, Check, CircleHelp, ClipboardCheck, ExternalLink, Globe2, MessageCircle, RotateCcw, Share2 } from "lucide-react";
import { countries } from "@/lib/data";
import { budgetData } from "@/components/student-budget-calculator";

type JourneyPlan = { country: string; level: string; intake: string; compared: string[]; completed: string[] };
const STORE_KEY = "edvora-study-journey-v1";
const countrySources: Record<string, { label: string; url: string }> = {
  uk: { label: "UK Student visa guidance", url: "https://www.gov.uk/student-visa" },
  germany: { label: "Study in Germany: official requirements", url: "https://www.make-it-in-germany.com/en/study-vocational-training/studies-in-germany/requirements" },
  italy: { label: "Universitaly: international student procedures", url: "https://www.universitaly.it/first-steps" },
  "south-cyprus": { label: "Cyprus student entry and residence", url: "https://www.gov.cy/mip-md/en/documents/students/" },
  turkey: { label: "Türkiye residence permits", url: "https://en.goc.gov.tr/residence-permit-types" },
  romania: { label: "Study in Romania: admission procedures", url: "https://studyinromania.gov.ro/procedures" },
  sweden: { label: "Swedish Migration Agency: higher education", url: "https://www.migrationsverket.se/en/you-want-to-apply/study/higher-education.html" },
  china: { label: "Chinese Embassy in Pakistan: study visa information", url: "https://pk.china-embassy.gov.cn/eng/lsfw/va/202504/t20250428_11606284.htm" },
};
const steps = [
  { id: "choose", title: "Choose a destination and study level", detail: "Shortlist a country and decide whether you are planning for undergraduate, postgraduate, or doctoral study.", href: "/countries", label: "Explore destinations" },
  { id: "course", title: "Check course and university requirements", detail: "Confirm entry qualifications, deadlines, tuition, and accepted English tests on the university’s own website.", href: "/universities", label: "Explore universities" },
  { id: "budget", title: "Build a realistic budget", detail: "Add tuition, accommodation, living costs, insurance, travel, and application charges. Keep visa proof-of-funds separate from actual living costs.", href: "/budget", label: "Open budget guide" },
  { id: "documents", title: "Gather your academic documents", detail: "Start with transcripts, certificates, passport, CV or statement if required, and certified translations where requested. Do not send originals unless an authority asks for them.", href: "/contact", label: "Ask an advisor" },
  { id: "english", title: "Plan your English test", detail: "Check the exact test and score accepted by your chosen course, then choose a preparation plan that fits your target date.", href: "/courses", label: "See test preparation" },
  { id: "visa", title: "Review the official student visa steps", detail: "Use your destination’s current government guidance. Requirements depend on your course, sponsor, location, and personal circumstances.", href: "", label: "Open official guidance" },
  { id: "advisor", title: "Talk your plan through with an advisor", detail: "Bring your shortlist, timeline, and questions. An advisor can help you organize next steps; final decisions belong to universities and authorities.", href: "/contact", label: "Book a consultation" },
];

const emptyPlan: JourneyPlan = { country: "", level: "", intake: "", compared: [], completed: [] };
const validLevels = new Set(["Undergraduate", "Postgraduate", "Doctoral", "Language preparation"]);
const validSteps = new Set(steps.map((step) => step.id));
function normalizePlan(value: unknown): JourneyPlan {
  if (!value || typeof value !== "object") return emptyPlan;
  const plan = value as Partial<JourneyPlan>;
  return {
    country: typeof plan.country === "string" && countries.some((item) => item.slug === plan.country) ? plan.country : "",
    level: typeof plan.level === "string" && validLevels.has(plan.level) ? plan.level : "",
    intake: typeof plan.intake === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(plan.intake) ? plan.intake : "",
    compared: Array.isArray(plan.compared) ? [...new Set(plan.compared.filter((id): id is string => typeof id === "string" && budgetData.some((item) => item.id === id)))].slice(0, 3) : [],
    completed: Array.isArray(plan.completed) ? [...new Set(plan.completed.filter((id): id is string => typeof id === "string" && validSteps.has(id)))].slice(0, steps.length) : [],
  };
}

export function JourneyPlanner() {
  const [plan, setPlan] = useState<JourneyPlan>(emptyPlan);
  const [ready, setReady] = useState(false);
  const [storageMode, setStorageMode] = useState<"loading" | "account" | "device">("loading");
  const [notice, setNotice] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const selectedBudget = useMemo(() => budgetData.find((item) => item.id === plan.country), [plan.country]);
  const comparison = useMemo(() => plan.compared.map((id) => budgetData.find((item) => item.id === id)).filter((item): item is (typeof budgetData)[number] => Boolean(item)), [plan.compared]);
  const percent = Math.round((plan.completed.length / steps.length) * 100);

  useEffect(() => {
    let cancelled = false;
    const loadLocal = () => {
      try {
        const saved = localStorage.getItem(STORE_KEY);
        if (!saved) return emptyPlan;
        return normalizePlan(JSON.parse(saved));
      } catch {
        setNotice("This browser could not load a saved plan. You can still use the planner.");
        return emptyPlan;
      }
    };
    void (async () => {
      try {
        const response = await fetch("/api/journey-plan", { cache: "no-store" });
        const result = await response.json();
        if (!cancelled && response.ok && result.authenticated) {
          if (result.plan) setPlan(normalizePlan(result.plan));
          else setPlan(emptyPlan);
          setStorageMode("account");
        } else if (!cancelled) {
          setPlan(loadLocal());
          setStorageMode("device");
          if (!response.ok) setNotice("Account sync is unavailable until its Supabase migration is applied. This plan is saved on this device for now.");
        }
      } catch {
        if (!cancelled) { setPlan(loadLocal()); setStorageMode("device"); }
      } finally { if (!cancelled) setReady(true); }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(STORE_KEY, JSON.stringify(plan)); }
    catch { setNotice("Your browser could not save this plan. Try freeing storage space or use Share / print to keep a copy."); }
    if (storageMode !== "account") return;
    const timer = window.setTimeout(() => {
      void fetch("/api/journey-plan", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ plan }) })
        .then(async (response) => { if (!response.ok) throw new Error("Your Edvora account could not sync this plan. Your local copy is still available."); })
        .catch((error: unknown) => setNotice(error instanceof Error ? error.message : "Your Edvora account could not sync this plan."));
    }, 500);
    return () => window.clearTimeout(timer);
  }, [plan, ready, storageMode]);

  function toggleStep(id: string) {
    setPlan((current) => ({ ...current, completed: current.completed.includes(id) ? current.completed.filter((item) => item !== id) : [...current.completed, id] }));
  }

  function toggleCompare(id: string) {
    setPlan((current) => {
      const compared = current.compared.includes(id) ? current.compared.filter((item) => item !== id) : current.compared.length < 3 ? [...current.compared, id] : current.compared;
      return { ...current, compared };
    });
    if (!plan.compared.includes(id) && plan.compared.length >= 3) setNotice("Compare up to three destinations at a time.");
    else setNotice("");
  }

  async function sharePlan() {
    const country = (countries.find((item) => item.slug === plan.country)?.name ?? "Not chosen yet").replace("South Cyprus", "Cyprus");
    const text = `My Edvora study abroad plan\nDestination: ${country}\nStudy level: ${plan.level || "Not chosen yet"}\nTarget intake: ${plan.intake || "Not chosen yet"}\nChecklist: ${plan.completed.length} of ${steps.length} steps complete\n${window.location.origin}/journey`;
    try {
      if (navigator.share) await navigator.share({ title: "My Edvora study plan", text });
      else { await navigator.clipboard.writeText(text); setNotice("A summary of your plan was copied. Your full checklist stays private to your account or this device."); }
    } catch (error) { if (error instanceof Error && error.name !== "AbortError") setNotice("Could not share right now. Use Print / save PDF to keep a copy."); }
  }

  function answerQuestion(value: string) {
    setQuestion(value);
    const text = value === "documents"
      ? "Start with your passport, academic transcripts and certificates. Your university or visa authority may request additional items, translations, or certified copies. Check the current official checklist before submitting documents."
      : value === "budget"
        ? "Start with the university’s exact tuition and a city-specific living estimate. Visa proof-of-funds is a separate requirement and may not match your real monthly costs. Compare official country guidance in the table below."
        : value === "visa"
          ? "Visa requirements vary by destination and personal circumstances. Use the official government link in your checklist, then ask an advisor if you want help understanding the steps."
          : "The right English test and score depend on the exact university and course. Confirm accepted tests and minimum section scores with the institution, then plan preparation around your application deadline.";
    setAnswer(text);
  }

  const countrySource = plan.country ? countrySources[plan.country] : undefined;

  return <>
    <section className="journey-planner-hero">
      <div className="shell journey-planner-heading">
        <span className="eyebrow">YOUR STUDY ABROAD PLAN</span>
        <h1>One clear next step.<br/><em>A plan that’s yours.</em></h1>
        <p>Build a practical checklist, compare official budget guidance, and keep your progress on this device. You can update it as your plans become clearer.</p>
        <div className="journey-plan-actions"><button className="button button-dark" type="button" onClick={sharePlan}><Share2 size={16}/> Share plan</button><button className="button button-white" type="button" onClick={() => window.print()}><ArrowDownToLine size={16}/> Print / save PDF</button><button className="journey-reset" type="button" onClick={() => { setPlan(emptyPlan); setNotice("Your plan has been cleared from this browser."); }}><RotateCcw size={15}/> Start again</button></div>
        {notice && <p className="journey-notice" role="status">{notice}</p>}
      </div>
    </section>

    <section className="shell journey-planner-layout">
      <div className="journey-planner-main">
        <section className="journey-card journey-profile-card" aria-labelledby="your-plan-title">
          <div className="journey-card-heading"><div><span className="eyebrow">YOUR STARTING POINT</span><h2 id="your-plan-title">Make this plan personal.</h2></div><Globe2 size={26}/></div>
          <div className="journey-profile-fields">
            <label>Destination<select value={plan.country} disabled={!ready} onChange={(event) => setPlan((current) => ({ ...current, country: event.target.value }))}><option value="">Still exploring</option>{countries.map((country) => <option key={country.slug} value={country.slug}>{country.name.replace("South Cyprus", "Cyprus")}</option>)}</select></label>
            <label>Study level<select value={plan.level} disabled={!ready} onChange={(event) => setPlan((current) => ({ ...current, level: event.target.value }))}><option value="">Still exploring</option><option>Undergraduate</option><option>Postgraduate</option><option>Doctoral</option><option>Language preparation</option></select></label>
            <label>Target intake <input type="month" value={plan.intake} disabled={!ready} onChange={(event) => setPlan((current) => ({ ...current, intake: event.target.value }))}/></label>
          </div>
          <p className="journey-save-note">{storageMode === "loading" ? "Loading your saved plan…" : storageMode === "account" ? "Your plan syncs to your Edvora account and stays available in this browser too." : <>Your plan is saved only in this browser. <Link href="/login?next=%2Fjourney">Sign in</Link> to sync it to your account.</>} Don’t add passport numbers, bank details, or other sensitive information here.</p>
        </section>

        <section className="journey-card journey-checklist-card" aria-labelledby="checklist-title">
          <div className="journey-card-heading"><div><span className="eyebrow">YOUR NEXT STEPS</span><h2 id="checklist-title">A checklist you can work through.</h2></div><ClipboardCheck size={26}/></div>
          <div className="journey-progress" aria-label={`${percent}% complete`}><span><i style={{ width: `${percent}%` }}/></span><strong>{plan.completed.length} of {steps.length} complete</strong></div>
          <div className="journey-checklist">{steps.map((step, index) => {
            const done = plan.completed.includes(step.id);
            const href = step.id === "visa" ? countrySource?.url ?? "/countries" : step.href;
            const isExternal = step.id === "visa" && Boolean(countrySource);
            return <article className={`journey-step-card${done ? " is-done" : ""}`} key={step.id}>
              <button className="journey-step-check" type="button" aria-label={`${done ? "Mark incomplete" : "Mark complete"}: ${step.title}`} aria-pressed={done} onClick={() => toggleStep(step.id)}>{done && <Check size={16}/>}</button>
              <div className="journey-step-content"><span className="journey-step-index">STEP {String(index + 1).padStart(2, "0")}</span><h3>{step.title}</h3><p>{step.detail}</p><Link href={href} target={isExternal ? "_blank" : undefined} rel={isExternal ? "noreferrer" : undefined}>{step.id === "visa" && !countrySource ? "Choose a destination first" : step.label} {isExternal ? <ExternalLink size={13}/> : <ArrowUpRight size={14}/>}</Link></div>
            </article>;
          })}</div>
        </section>

        <section className="journey-card journey-compare-card" aria-labelledby="compare-title">
          <div className="journey-card-heading"><div><span className="eyebrow">COMPARE DESTINATIONS</span><h2 id="compare-title">Put the key budget details side by side.</h2></div><span className="journey-compare-limit">Choose up to 3</span></div>
          <div className="journey-compare-options">{budgetData.map((item) => <label key={item.id}><input type="checkbox" checked={plan.compared.includes(item.id)} onChange={() => toggleCompare(item.id)} disabled={!ready || (!plan.compared.includes(item.id) && plan.compared.length >= 3)}/><span>{item.flag} {item.country}</span></label>)}</div>
          {comparison.length ? <div className="journey-compare-table-wrap"><table className="journey-compare-table"><thead><tr><th scope="col">Budget item</th>{comparison.map((item) => <th scope="col" key={item.id}>{item.flag} {item.country}</th>)}</tr></thead><tbody><tr><th scope="row">Tuition</th>{comparison.map((item) => <td key={item.id}>{item.tuitionLocal}</td>)}</tr><tr><th scope="row">Monthly living / funds guide</th>{comparison.map((item) => <td key={item.id}>{item.livingMonthlyGuide}</td>)}</tr><tr><th scope="row">Financial evidence</th>{comparison.map((item) => <td key={item.id}>{item.financialEvidence}</td>)}</tr><tr><th scope="row">Visa fee</th>{comparison.map((item) => <td key={item.id}>{item.visaFees}</td>)}</tr><tr><th scope="row">Official sources</th>{comparison.map((item) => <td key={item.id}><div className="journey-source-list">{item.sources.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.label} <ExternalLink size={12}/></a>)}</div></td>)}</tr></tbody></table></div> : <p className="journey-compare-empty">Choose destinations above to compare the currently published guide. Amounts and rules can change; confirm them with the linked official sources.</p>}
          <p className="journey-compare-footnote">These figures are planning clues, not a complete personal budget or a promise of visa eligibility. See the <Link href="/budget">full budget guide</Link> and verify current requirements before applying.</p>
        </section>
      </div>

      <aside className="journey-planner-aside">
        <section className="journey-help-card" aria-labelledby="journey-help-title">
          <span className="journey-help-icon"><CircleHelp size={20}/></span><span className="eyebrow">QUICK GUIDANCE</span><h2 id="journey-help-title">Need a quick answer?</h2><p>This guide answers common planning questions and points you to official information.</p>
          <div className="journey-faq-buttons"><button type="button" onClick={() => answerQuestion("documents")}>Which documents should I prepare?</button><button type="button" onClick={() => answerQuestion("budget")}>How do I estimate my budget?</button><button type="button" onClick={() => answerQuestion("visa")}>Where do I check visa rules?</button><button type="button" onClick={() => answerQuestion("english")}>Which English test should I take?</button></div>
          {question && <div className="journey-faq-answer" role="status"><strong>{question === "documents" ? "Documents" : question === "budget" ? "Budget" : question === "visa" ? "Visa information" : "English test"}</strong><p>{answer}</p>{question === "budget" && <Link href="/budget">Open the budget guide <ArrowUpRight size={13}/></Link>}{question === "english" && <Link href="/courses">Explore test preparation <ArrowUpRight size={13}/></Link>}{question === "visa" && countrySource && <a href={countrySource.url} target="_blank" rel="noreferrer">{countrySource.label} <ExternalLink size={12}/></a>}</div>}
          <p className="journey-faq-disclaimer">This is a fixed FAQ guide, not a live AI chatbot. It does not assess eligibility or replace advice from an authority or university.</p>
          <Link className="button button-white journey-advisor-link" href="/contact"><MessageCircle size={15}/> Ask an advisor <ArrowUpRight size={14}/></Link>
        </section>
        <section className="journey-budget-mini"><span className="eyebrow">{selectedBudget ? `${selectedBudget.flag} ${selectedBudget.country.toUpperCase()}` : "STILL EXPLORING?"}</span><h2>{selectedBudget ? "Your chosen destination." : "Compare before you decide."}</h2><p>{selectedBudget ? selectedBudget.firstYearSummary : "Compare tuition, living guidance, and official financial evidence across destinations."}</p><Link href="/budget">Review official budget guidance <ArrowUpRight size={14}/></Link></section>
      </aside>
    </section>
  </>;
}
