"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Briefcase,
  Building2,
  CheckCircle2,
  ChevronRight,
  CreditCard,
  PiggyBank,
  ShieldCheck,
  Wallet,
} from "lucide-react";

export type DestinationBudget = {
  id: string;
  country: string;
  flag: string;
  hasOfficialFundsAmount: boolean;
  tuitionLocal: string;
  tuitionNote: string;
  livingMonthlyGuide: string;
  livingGuideNote: string;
  visaFees: string;
  visaDetails: string[];
  financialEvidence: string;
  financialEvidenceNote: string;
  workRights: string;
  firstYearSummary: string;
  sources: { label: string; url: string }[];
};

export const budgetData: DestinationBudget[] = [
  {
    id: "germany",
    country: "Germany",
    flag: "🇩🇪",
    hasOfficialFundsAmount: true,
    tuitionLocal: "Varies by university and state",
    tuitionNote: "Many public universities do not charge general tuition, but semester contributions and state or programme exceptions apply. Check the exact course fee with the university.",
    livingMonthlyGuide: "€992 / month (2026 visa funds)",
    livingGuideNote: "This is the official proof-of-funds benchmark, not a guarantee of actual living costs.",
    visaFees: "Check the German mission’s current fee list",
    visaDetails: [
      "A blocked account generally needs €11,904 for one year in 2026; scholarship or a formal declaration of commitment may also qualify.",
      "Visa, insurance, semester contribution, and blocked-account provider charges are separate and vary.",
    ],
    financialEvidence: "€11,904 for 12 months (2026)",
    financialEvidenceNote: "The official site lists a blocked account, scholarship, or declaration of commitment as possible evidence. Requirements can vary by case.",
    workRights: "Up to 140 full days or 280 half days per year, or 20 hours per week.",
    firstYearSummary: "Plan for the official living-funds amount plus the specific tuition and semester charges for your course.",
    sources: [
      { label: "Official study funding and tuition guidance", url: "https://www.make-it-in-germany.com/en/study-vocational-training/studies-in-germany/requirements" },
      { label: "Study visa and work rules", url: "https://www.make-it-in-germany.com/en/visa-residence/types/studying" },
    ],
  },
  {
    id: "italy",
    country: "Italy",
    flag: "🇮🇹",
    hasOfficialFundsAmount: true,
    tuitionLocal: "Set by university, programme, and eligibility",
    tuitionNote: "Italian universities set their own fees. Public-university fees may depend on declared family income and course; scholarships or fee exemptions are not automatic.",
    livingMonthlyGuide: "€783.06 / month (2026–27 study checklist)",
    livingGuideNote: "Use the current study-visa checklist for the embassy or consulate handling your application.",
    visaFees: "Confirm the current study-visa fee with the Italian mission",
    visaDetails: [
      "The current 2026–27 checklist states minimum subsistence funds of €783.06 per month.",
      "Tuition, accommodation, insurance, visa, and residence-permit costs are additional; check the applicable consular checklist.",
    ],
    financialEvidence: "At least €783.06 per month (2026–27 checklist)",
    financialEvidenceNote: "Evidence form and any sponsor or bank-document rules depend on the consulate’s current checklist. Do not treat this monthly minimum as the total study budget.",
    workRights: "Check current permit conditions with the Italian authorities; do not rely on expected part-time income to meet visa funds.",
    firstYearSummary: "Add your university’s stated tuition and accommodation costs to the financial evidence required for your visa period.",
    sources: [
      { label: "2026–27 study-visa checklist", url: "https://ambbaku.esteri.it/wp-content/uploads/2026/06/CHECKLIST-FOR-SCHENGEN-VISA-APPLICATIONS-FOR-STUDY.pdf" },
      { label: "Official tuition-fee guidance", url: "https://studyinitaly.esteri.it/static/ProcedureIscrizione" },
    ],
  },
  {
    id: "south-cyprus",
    country: "Cyprus",
    flag: "🇨🇾",
    hasOfficialFundsAmount: false,
    tuitionLocal: "Set by university and programme",
    tuitionNote: "There is no single tuition rate for all international students. Check the exact programme fee and any scholarship conditions directly with the recognised university.",
    livingMonthlyGuide: "No single monthly amount listed on the student-permit page",
    livingGuideNote: "The Migration Department says students must show financial ability; required evidence may be updated by official decisions.",
    visaFees: "Entry/residence application €70; first registration may add €70",
    visaDetails: [
      "The published student-permit fees include €70 for an entry and residence permit, €55 for residence-permit issuance/renewal, and €70 for first registration; which fees apply depends on the application.",
      "Budget separately for tuition, accommodation, health cover, translations, and any required financial evidence.",
    ],
    financialEvidence: "No universal amount stated on the current student page",
    financialEvidenceNote: "Official guidance says evidence must show ability to cover study and living expenses. Confirm the current amount and documents with your university and the Migration Department.",
    workRights: "Eligible students may work up to 20 hours weekly during classes and 38 during class breaks, in permitted sectors and with an approved contract.",
    firstYearSummary: "Add the specific tuition, accommodation, and permit costs confirmed by the university and authorities.",
    sources: [
      { label: "Student entry, residence, and fees", url: "https://www.gov.cy/mip-md/en/documents/students/" },
      { label: "Student work conditions", url: "https://www.gov.cy/mip-md/en/documents/economic-activities-by-students/" },
    ],
  },
  {
    id: "turkey",
    country: "Türkiye",
    flag: "🇹🇷",
    hasOfficialFundsAmount: false,
    tuitionLocal: "Set by university, programme, and language of instruction",
    tuitionNote: "Fees differ across public and foundation universities, programmes, and student categories. Use the university’s current international-student fee schedule.",
    livingMonthlyGuide: "No common official monthly estimate found",
    livingGuideNote: "Build a city-specific budget from accommodation and university estimates; the student-residence page does not publish one standard amount.",
    visaFees: "Visa and residence charges vary; confirm before applying",
    visaDetails: [
      "Student residence applicants must meet the current legal conditions and submit supporting documents; confirm any financial evidence with the university and Turkish mission.",
      "Do not assume a single visa fee, insurance price, or bank-balance threshold for every applicant.",
    ],
    financialEvidence: "No single amount listed in the general student-permit guidance",
    financialEvidenceNote: "Check the exact documents requested for your programme and application. An international student must obtain a work permit before working; associate and bachelor’s students may apply after their first year.",
    workRights: "A work permit is required. Associate and bachelor’s students may apply after completing the first year; rules differ by level.",
    firstYearSummary: "Use the university’s fee offer and city-specific housing estimate; verify all permit and insurance charges with official authorities.",
    sources: [
      { label: "Student residence-permit and work rules", url: "https://en.goc.gov.tr/residence-permit-types" },
      { label: "Official work-permit guidance", url: "https://en.goc.gov.tr/work-permit" },
    ],
  },
  {
    id: "uk",
    country: "United Kingdom",
    flag: "🇬🇧",
    hasOfficialFundsAmount: true,
    tuitionLocal: "Use the amount on your CAS (Confirmation of Acceptance for Studies)",
    tuitionNote: "Course fees depend on the institution and programme. For visa evidence, GOV.UK says to use the course fees shown on your CAS for one academic year, up to nine months.",
    livingMonthlyGuide: "£1,529 / month in London; £1,171 outside London",
    livingGuideNote: "Student-visa maintenance amounts apply for up to nine months; they are financial-evidence rules, not a full local cost-of-living estimate.",
    visaFees: "Student visa application: £558 from 8 April 2026",
    visaDetails: [
      "Show the course fee on your CAS plus up to nine months of maintenance funds: £1,529 per month in London or £1,171 outside London.",
      "Required funds generally must be held for 28 consecutive days; healthcare surcharge and any required TB test are additional and depend on the case.",
    ],
    financialEvidence: "Course fees on CAS + up to 9 months of maintenance funds",
    financialEvidenceNote: "Funds generally need to be held for 28 consecutive days. Some applicants are exempt from providing evidence; read the current GOV.UK rules for your circumstances.",
    workRights: "Work permission depends on the course, sponsor, and visa conditions. Check the work conditions on your Student visa; do not budget on assumed earnings.",
    firstYearSummary: "Use the CAS course fee plus the official maintenance amount for your study location; add visa, healthcare, travel, and personal costs.",
    sources: [
      { label: "Student-visa money requirements", url: "https://www.gov.uk/student-visa/money" },
      { label: "Student-visa fees and conditions", url: "https://www.gov.uk/student-visa" },
    ],
  },
  {
    id: "romania",
    country: "Romania",
    flag: "🇷🇴",
    hasOfficialFundsAmount: true,
    tuitionLocal: "€400–€9,000 / year (official broad range)",
    tuitionNote: "The official Study in Romania portal says fees depend on study field and EU/non-EU status; use its programme search for the actual fee.",
    livingMonthlyGuide: "Approximately €600 / month (official student estimate)",
    livingGuideNote: "The portal lists city and housing choices that can move costs substantially; this is an estimate, not a visa threshold.",
    visaFees: "Confirm the current long-stay visa fee with the Romanian mission",
    visaDetails: [
      "The official student procedure page lists proof of financial means of at least €2,000.",
      "Tuition, accommodation, insurance, visa, and travel costs are additional.",
    ],
    financialEvidence: "At least €2,000 (official student procedure guidance)",
    financialEvidenceNote: "This is the amount stated on the official admission/visa procedure guide. Confirm the current checklist with the Romanian mission before applying.",
    workRights: "Check current student work conditions with the Romanian immigration authority; do not count on wages to meet the visa requirement.",
    firstYearSummary: "Combine the chosen programme’s fee, city-specific living costs, and the current visa and insurance requirements.",
    sources: [
      { label: "Tuition and living-cost guidance", url: "https://studyinromania.gov.ro/faq-costs" },
      { label: "Admission and visa procedure, including financial evidence", url: "https://studyinromania.gov.ro/procedures" },
    ],
  },
  {
    id: "sweden",
    country: "Sweden",
    flag: "🇸🇪",
    hasOfficialFundsAmount: true,
    tuitionLocal: "Check the programme’s current fee in the admissions portal",
    tuitionNote: "Tuition varies by programme and university. The university must confirm that the tuition fee has been paid before the residence-permit application is complete.",
    livingMonthlyGuide: "SEK 10,656 / month for 2026 applications",
    livingGuideNote: "This is the Migration Agency’s maintenance requirement and must cover the full permit period; family members increase the amount.",
    visaFees: "Residence-permit application: SEK 1,500 for adults",
    visaDetails: [
      "For studies under one year, comprehensive health insurance is required unless qualifying coverage is provided by the institution.",
      "Since 11 June 2026, most first- and second-cycle students may work up to 15 hours per week during terms; different rules apply in summer.",
    ],
    financialEvidence: "SEK 10,656 per month for the full permit period (2026)",
    financialEvidenceNote: "Personal bank assets, scholarships, grants/loans, sponsors, or employment income may qualify under the Agency’s rules. Free food or housing can change the calculation.",
    workRights: "For permits granted under rules from 11 June 2026, the general starting point is a 15-hour weekly limit during term; summer work is treated differently.",
    firstYearSummary: "Add the exact programme tuition to the maintenance amount for the full residence-permit period, plus permit and insurance costs.",
    sources: [
      { label: "Residence permit: funds, fees, insurance", url: "https://www.migrationsverket.se/en/you-want-to-apply/study/higher-education.html" },
      { label: "2026 student work-rule changes", url: "https://www.migrationsverket.se/nyheter/news-archive/2026-05-25-new-rules-for-residence-permits-for-studies-in-higher-education.html" },
    ],
  },
];

export function StudentBudgetCalculator() {
  const [selectedCountry, setSelectedCountry] = useState<string>("germany");
  const [budgetFilter, setBudgetFilter] = useState<"all" | "official-funds">("all");
  const filteredList = budgetData.filter((item) => budgetFilter === "all" || item.hasOfficialFundsAmount);
  const current = filteredList.find((item) => item.id === selectedCountry) || filteredList[0] || budgetData[0];

  return (
    <section className="student-budget-section" id="budget-guide">
      <div className="shell">
        <div className="budget-section-header">
          <div>
            <span className="eyebrow">TRANSPARENT STUDENT BUDGET & PAID EXPENSES</span>
            <h2>
              Know what it costs.
              <br />
              <em>Plan with confidence.</em>
            </h2>
            <p>
              Compare official visa-funds rules with tuition and living costs. Amounts are shown in local currencies because PKR conversions change; confirm the latest figures with the linked government or university source.
            </p>
          </div>

          <div className="budget-filter-tabs">
            <button
              onClick={() => setBudgetFilter("all")}
              className={`budget-tab ${budgetFilter === "all" ? "active" : ""}`}
            >
              All Destinations
            </button>
            <button
              onClick={() => setBudgetFilter("official-funds")}
              className={`budget-tab ${budgetFilter === "official-funds" ? "active" : ""}`}
            >
              Official funds amount listed
            </button>
          </div>
        </div>

        {/* Country selector chips */}
        <div className="budget-country-selector">
          {filteredList.map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedCountry(item.id)}
              className={`budget-country-btn ${item.id === current.id ? "active" : ""}`}
            >
              <span className="flag-icon">{item.flag}</span>
              <span className="name">{item.country}</span>
              <span className={`tier-badge ${item.hasOfficialFundsAmount ? "affordable" : "moderate"}`}>{item.hasOfficialFundsAmount ? "Funds listed" : "Varies"}</span>
            </button>
          ))}
        </div>

        {/* Main Budget Dashboard Card */}
        <div className="budget-dashboard-card">
          <div className="budget-card-top">
            <div className="budget-card-title">
              <span className="flag-large">{current.flag}</span>
              <div>
                <h3>{current.country} Student Financial Blueprint</h3>
                <p>
                  First-year planning: <strong>{current.firstYearSummary}</strong>
                </p>
              </div>
            </div>
            <span className={`budget-pill-large ${current.hasOfficialFundsAmount ? "affordable" : "moderate"}`}>
              {current.hasOfficialFundsAmount ? "Official funds listed" : "Case-specific funds"}
            </span>
          </div>

          <div className="budget-metrics-grid">
            {/* 1. Tuition Fee */}
            <div className="budget-metric-box">
              <div className="metric-header">
                <Building2 className="text-[#0983ad]" size={20} />
                <span>Annual University Tuition</span>
              </div>
              <strong className="metric-value">{current.tuitionLocal}</strong>
              <small className="metric-sub">Course and institution specific</small>
              <p className="metric-desc">{current.tuitionNote}</p>
            </div>

            {/* 2. Living Cost */}
            <div className="budget-metric-box">
              <div className="metric-header">
                <Wallet className="text-[#e2762a]" size={20} />
                <span>Living Expenses (Room & Food)</span>
              </div>
              <strong className="metric-value">{current.livingMonthlyGuide}</strong>
              <small className="metric-sub">Official requirement or published estimate</small>
              <p className="metric-desc">{current.livingGuideNote}</p>
            </div>

            {/* 3. Bank Statement */}
            <div className="budget-metric-box">
              <div className="metric-header">
                <PiggyBank className="text-[#207c4b]" size={20} />
                <span>Visa financial evidence</span>
              </div>
              <strong className="metric-value">{current.financialEvidence}</strong>
              <small className="metric-sub">May be bank funds, scholarship, or sponsor evidence</small>
              <p className="metric-desc">{current.financialEvidenceNote}</p>
            </div>

            {/* 4. Student Work Rights */}
            <div className="budget-metric-box highlight-box">
              <div className="metric-header">
                <Briefcase className="text-[#0c4077]" size={20} />
                <span>Work while studying</span>
              </div>
              <strong className="metric-value">Permit conditions apply</strong>
              <small className="metric-sub">No earnings included in this budget</small>
              <p className="metric-desc">{current.workRights}</p>
            </div>
          </div>

          {/* Paid items breakdown section */}
          <div className="budget-breakdown-details">
            <div className="breakdown-left">
                <h4>
                <CreditCard size={18} className="text-[#0c4077]" />
                Visa fees and other costs to confirm
              </h4>
              <ul className="breakdown-list">
                {[current.visaFees, ...current.visaDetails].map((detail, idx) => (
                  <li key={idx}>
                    <CheckCircle2 size={16} className="text-[#207c4b] shrink-0" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="breakdown-right">
              <div className="advisor-callout">
                <div className="callout-badge">
                  <ShieldCheck size={16} /> Check sources before paying
                </div>
                <h5>Need help structuring your bank statement?</h5>
                <p>
                  Edvora advisors evaluate your financial documents, explain sponsor requirements, and help choose the destination that fits your family budget.
                </p>
                <Link className="button button-orange mt-3" href="/contact">
                  Request Free Financial Assessment <ChevronRight size={16} />
                </Link>
              </div>
            </div>
          </div>
          <div className="budget-official-sources"><strong>Official sources:</strong>{current.sources.map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.url}>{source.label}</a>)}</div>
        </div>

        {/* Quick Comparative Table for quick scanning */}
        <div className="budget-table-wrap">
          <div className="table-header">
            <h4>Quick Side-by-Side Budget Comparison for Pakistani Students</h4>
            <p>All values stay in local currencies; PKR totals depend on exchange rates and each student’s circumstances.</p>
          </div>
          <div className="table-responsive">
            <table className="budget-table">
              <thead>
                <tr>
                  <th>Destination</th>
                  <th>Annual tuition guidance</th>
                  <th>Living-cost guidance</th>
                  <th>Visa financial evidence</th>
                  <th>Work conditions</th>
                </tr>
              </thead>
              <tbody>
                {budgetData.map((b) => (
                  <tr key={b.id} className={b.id === current.id ? "selected-row" : ""}>
                    <td>
                      <button
                        onClick={() => setSelectedCountry(b.id)}
                        className="table-country-link"
                      >
                        <span className="flag">{b.flag}</span>
                        <strong>{b.country}</strong>
                      </button>
                    </td>
                    <td>{b.tuitionLocal}</td>
                    <td>{b.livingMonthlyGuide}</td>
                    <td>{b.financialEvidence}</td>
                    <td>{b.workRights}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
