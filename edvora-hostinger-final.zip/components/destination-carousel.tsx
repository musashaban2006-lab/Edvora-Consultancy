"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import type { Country } from "@/lib/data";
import { PhotoFallback } from "@/components/photo-fallback";

const cityPhotos: Record<string, string[]> = {
  uk: ["London", "Edinburgh", "Birmingham", "Manchester"],
  "south-cyprus": ["Nicosia", "Limassol", "Paphos"],
  sweden: ["Stockholm", "Gothenburg", "Lund"],
  turkey: ["Istanbul", "Ankara", "Izmir"],
  romania: ["Bucharest", "Cluj-Napoca", "Timisoara"],
  germany: ["Berlin", "Munich", "Hamburg"],
  italy: ["Rome", "Milan", "Florence"],
};

const slugPart = (value: string) => value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

export function DestinationCarousel({ countries }: { countries: Country[] }) {
  const [activeCountry, setActiveCountry] = useState(0);
  const [activeCity, setActiveCity] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);
  const country = countries[activeCountry];
  const places = country ? cityPhotos[country.slug] ?? [country.name] : [];
  const city = places[activeCity % places.length];
  const image = country && city ? `/images/countries/cities/${country.slug}-${slugPart(city)}.jpg` : "";

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (reducedMotion || places.length < 2) return;
    const timer = window.setInterval(() => setActiveCity((current) => (current + 1) % places.length), 4200);
    return () => window.clearInterval(timer);
  }, [activeCountry, places.length, reducedMotion]);

  if (!country || !city) return null;
  const moveCity = (delta: number) => setActiveCity((current) => (current + delta + places.length) % places.length);
  const selectCountry = (index: number) => { setActiveCountry(index); setActiveCity(0); };

  return <section className="destination-carousel-wrap" aria-label="Study destinations and cities">
    <div className="shell destination-country-tabs" role="tablist" aria-label="Choose a destination">
      {countries.map((item, index) => <button type="button" role="tab" aria-selected={index === activeCountry} className={index === activeCountry ? "destination-country-tab active" : "destination-country-tab"} key={item.slug} onClick={() => selectCountry(index)}>{item.name}</button>)}
    </div>
    <div className="destination-carousel shell" aria-live="polite">
      <div className="destination-carousel-image"><PhotoFallback key={`${country.slug}-${city}`} src={image} alt={`${city}, ${country.name}`} label={`${city} · ${country.name}`} sizes="(max-width: 760px) 90vw, 55vw" className="cover-image destination-slide-image" /></div>
      <div className="destination-carousel-copy"><span className="eyebrow">{country.name.toUpperCase()} · CITY {String(activeCity + 1).padStart(2, "0")} / {String(places.length).padStart(2, "0")}</span><h2 key={city} className="destination-city-title">{city}</h2><p>{country.tagline}</p><Link className="text-arrow" href={`/countries/${country.slug}`}>Explore {country.name} <ArrowUpRight size={16}/></Link><div className="destination-controls"><button type="button" onClick={() => moveCity(-1)} aria-label="Previous city"><ArrowLeft size={17}/></button><button type="button" onClick={() => moveCity(1)} aria-label="Next city"><ArrowRight size={17}/></button><span>{places.map((item, index) => <button type="button" className={index === activeCity ? "destination-dot active" : "destination-dot"} key={item} onClick={() => setActiveCity(index)} aria-label={`Show ${item}`}/>)}</span></div><div className="destination-city-labels">{places.map((item, index) => <button className={index === activeCity ? "active" : ""} key={item} type="button" onClick={() => setActiveCity(index)}>{item}</button>)}</div></div>
    </div>
  </section>;
}
