"use client";

import Image from "next/image";
import { useState } from "react";

export function PhotoFallback({
  src,
  alt,
  label,
  className,
  sizes = "(max-width: 760px) 90vw, 35vw",
}: {
  src: string;
  alt: string;
  label: string;
  className?: string;
  sizes?: string;
}) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <span className={`photo-fallback ${className ?? ""}`} role="img" aria-label={alt}>
        <span className="photo-fallback-mark" aria-hidden="true">✦</span>
        <span>{label}</span>
      </span>
    );
  }

  return <Image src={src} alt={alt} fill sizes={sizes} className={className} onError={() => setFailed(true)} />;
}
