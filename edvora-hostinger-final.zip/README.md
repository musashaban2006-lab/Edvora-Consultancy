# Edvora

Edvora is a Next.js App Router website backed by Supabase. It includes home, about, destination, university, service, and student testimonial pages; student accounts and saved universities and destinations; a staff enquiry dashboard; and a consultation form.

## Run locally

1. Install Node.js 20.9 or newer and npm (or pnpm).
2. Copy `.env.example` to `.env.local` and add the Supabase project URL and publishable key.
3. From this folder, run `npm install` and `npm run dev` (or `pnpm dev`).
4. Open `http://localhost:3002`.

The public site can render its preview content without Supabase credentials. Authentication, saved items, enquiry submission, and the staff dashboard require the database setup below.

Consultation submissions are saved to Supabase when configured (or to the local preview fallback) and then forwarded server-side to Zapier when `ZAPIER_CONSULTATION_WEBHOOK_URL` is set. Add this variable to `.env.local` for local use and to the hosting provider's server environment for deployment. Do not use a `NEXT_PUBLIC_` prefix. The webhook is optional; a webhook outage does not prevent the saved consultation from succeeding.

## Supabase setup

1. Create a Supabase project.
2. Apply the SQL migrations in `supabase/migrations` in filename order, including `202610130001_private_consultation_documents.sql`, `202610140001_consultation_mode.sql`, `202610150001_china_germany_universities.sql`, and the two new files `202610160001_mock_test_bookings.sql` and `202610160002_student_journey_plans.sql`, using the Supabase CLI or SQL editor. On an existing project, apply only migrations that have not already been run.
3. Run `supabase/seed.sql` to add the seven destinations, university directory listings, and service descriptions. Confirm listings and details before launch.
4. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in `.env.local` and in the Vercel environment settings.
5. Set Supabase Auth’s site URL to the deployed Edvora URL and add `/auth/callback` as a redirect URL. Add `http://localhost:3002/auth/callback` for local development.
6. Create a staff account through the site, then promote it from the Supabase SQL editor with `update public.profiles set role = 'staff' where id = '<auth-user-uuid>';`.
7. Add `SUPABASE_SERVICE_ROLE_KEY` only to the server environment to enable staff-only private document uploads and links. Never prefix it with `NEXT_PUBLIC_`.
8. Set `CRON_SECRET` in the hosting environment. Vercel runs the configured daily cleanup route; other hosts must schedule `GET /api/cron/cleanup-consultation-documents` with `Authorization: Bearer $CRON_SECRET`.
9. Set `NEXT_PUBLIC_SITE_URL` to the final public HTTPS domain in the hosting environment. This supplies canonical metadata, social sharing links, `robots.txt`, and `sitemap.xml`.
10. Upload approved photos to the `site-media` Storage bucket. Set each content row’s `image_path` to its object path. The bucket accepts JPEG, PNG, WebP, and AVIF files up to 5 MB; public reads are intended only for photos approved for publication.

## Before launch

- Confirm university names and details with Edvora before launch. Source-list links on university profiles preserve the pages used to assemble the directory.
- Replace sample student stories with student-approved accounts and images; the sample stories are marked as illustrative.
- Supply Edvora’s phone, WhatsApp number, privacy contact, and final privacy wording. The current privacy page is clearly marked as a draft.
- Upload the supplied logo (`public/edvora-logo-trim.png` is the website-ready transparent version; `public/edvora-logo.png` preserves the supplied image).
- Replace the temporary Unsplash imagery with licensed Edvora-selected photos uploaded to Supabase Storage.

## Staff and media security

RLS policies make published catalogue content publicly readable, allow students to manage their own saved universities and destinations, and restrict consultation enquiry access and site-media uploads to staff. Staff roles are assigned in Supabase, not through public signup. The `site-media` bucket is public because published site imagery must render without sign-in; upload, update, and delete operations require staff access.

Consultation documents are optional PDF/JPG/PNG files (maximum 6 files, 10 MB per file, 20 MB total). They are stored in a separate private `consultation-documents` bucket, linked to the enquiry, and scheduled for deletion after 90 days. Staff can issue a one-hour download link from the staff dashboard. Zapier receives only a document count; student files stay in Supabase and should be reviewed through the staff dashboard.

Free mock-test requests are saved to `mock_test_bookings` and shown in the staff dashboard after `202610160001_mock_test_bookings.sql` is applied. Set `ZAPIER_MOCK_TEST_WEBHOOK_URL` to a second Zapier Catch Hook URL for mock-test notifications. The journey planner syncs to `student_journey_plans` for signed-in students after `202610160002_student_journey_plans.sql`; guest progress stays in their browser. Request forms report when Zapier accepted a notification request, but Edvora must verify the configured email and WhatsApp steps actually deliver messages. My Journey does not send automatic advisor notifications; it is private planning data and stays with the student unless they choose to share it.
